import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { FloatingElements } from "@/components/floating-elements";
import { CalendarTask } from "@/components/calendar-task";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Rocket, ArrowLeft, Calendar as CalendarIcon, CheckCircle, Clock, Target } from "lucide-react";

export default function ExecutionCalendar() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [calendarView, setCalendarView] = useState<"list" | "calendar">("list");

  // Auth check
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  // Load business plan
  const { data: businessPlan, isLoading: planLoading, error: planError } = useQuery({
    queryKey: [`/api/business-plans/${id}`],
    enabled: !!id && id !== "undefined" && !isNaN(parseInt(id || "")),
    retry: false,
  });

  // Load calendar tasks
  const { data: tasks = [], isLoading: tasksLoading, error: tasksError } = useQuery({
    queryKey: [`/api/business-plans/${id}/calendar`],
    enabled: !!id && id !== "undefined" && !isNaN(parseInt(id || "")) && !!businessPlan,
    retry: false,
  });

  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, isCompleted, userNotes }: { taskId: number, isCompleted: boolean, userNotes?: string }) => {
      const response = await apiRequest("PATCH", `/api/calendar-tasks/${taskId}`, {
        isCompleted,
        userNotes,
      });
      return response;
    },
    onSuccess: (data) => {
      // Update the task in the cache immediately
      queryClient.setQueryData([`/api/business-plans/${id}/calendar`], (oldData: any) => {
        if (!oldData) return oldData;
        return oldData.map((task: any) => 
          task.id === data.id ? data : task
        );
      });
      
      // Also invalidate to refetch from server
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${id}/calendar`] });
      
      toast({
        title: "Task Updated! ✅",
        description: "Your progress has been saved.",
      });
    },
    onError: (error) => {
      console.error("Task update error:", error);
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleTaskUpdate = (taskId: number, isCompleted: boolean, userNotes?: string) => {
    updateTaskMutation.mutate({ taskId, isCompleted, userNotes });
  };

  // Calculate stats - make sure it's reactive to task changes
  const completedTasks = tasks.filter((task: any) => task.isCompleted === true).length;
  const totalTasks = tasks.length;
  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  // Get tasks for selected date
  const selectedDateString = selectedDate.toISOString().split('T')[0];
  const tasksForSelectedDate = tasks.filter((task: any) => 
    task.taskDate === selectedDateString
  );

  // Get upcoming tasks (next 7 days)
  const today = new Date();
  const nextWeek = new Date(today);
  nextWeek.setDate(today.getDate() + 7);
  
  const upcomingTasks = tasks.filter((task: any) => {
    const taskDate = new Date(task.taskDate);
    return taskDate >= today && taskDate <= nextWeek && !task.isCompleted;
  }).slice(0, 5);

  // Get dates with tasks for calendar highlighting
  const datesWithTasks = tasks.map((task: any) => new Date(task.taskDate));

  if (authLoading || planLoading || tasksLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-coral mx-auto mb-4"></div>
          <p className="text-gray-600">Loading execution calendar...</p>
        </div>
      </div>
    );
  }

  if (planError || !businessPlan) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-100 rounded-full mx-auto mb-4 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            {planError ? "Unable to Load Business Plan" : "Business Plan Not Found"}
          </h2>
          <p className="text-gray-600 mb-6">
            {planError 
              ? "There was an issue loading the business plan. Please try again." 
              : "The business plan you're looking for doesn't exist or may have been deleted."
            }
          </p>
          <div className="space-y-3">
            <Button onClick={() => setLocation("/business-plans")} className="bg-primary text-white rounded-full w-full">
              View All Business Plans
            </Button>
            <Button onClick={() => setLocation("/")} variant="outline" className="rounded-full w-full">
              Back to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen relative overflow-x-hidden">
      <FloatingElements />
      
      {/* Header */}
      <header className="relative z-10 bg-white/90 backdrop-blur-sm border-b-2 border-sky/20 mb-8">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-coral to-teal rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-sm">AH</span>
                </div>
                <span className="font-handwritten text-2xl font-bold gradient-text">Atomic Hustler</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex space-x-2">
                <Button
                  variant={calendarView === "list" ? "default" : "outline"}
                  onClick={() => setCalendarView("list")}
                  className="rounded-full"
                >
                  📋 List View
                </Button>
                <Button
                  variant={calendarView === "calendar" ? "default" : "outline"}
                  onClick={() => setCalendarView("calendar")}
                  className="rounded-full"
                >
                  📅 Calendar View
                </Button>
              </div>
              <Button 
                onClick={() => setLocation(`/business-plan/${id}`)}
                variant="outline"
                className="border-coral text-coral hover:bg-coral hover:text-white rounded-full"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Plan
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="relative z-10 container mx-auto px-6 py-12">
        {/* Progress Overview */}
        <div className="mb-12 text-center">
          <h2 className="font-handwritten text-4xl font-bold gradient-text mb-4">
            Your {businessPlan.daysPlanned}-Day Execution Journey! 🚀
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Follow your personalized roadmap to launch your side hustle successfully
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">📊</div>
                <div className="text-2xl font-bold text-sky">{progressPercentage}%</div>
                <div className="text-sm text-gray-600">Overall Progress</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">✅</div>
                <div className="text-2xl font-bold text-mint">{completedTasks}</div>
                <div className="text-sm text-gray-600">Tasks Completed</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">📝</div>
                <div className="text-2xl font-bold text-coral">{totalTasks}</div>
                <div className="text-sm text-gray-600">Total Tasks</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">⏰</div>
                <div className="text-2xl font-bold text-plum">{upcomingTasks.length}</div>
                <div className="text-sm text-gray-600">Upcoming Tasks</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Main Content */}
        {calendarView === "list" ? (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Task List */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="font-handwritten text-2xl text-teal flex items-center">
                    📋 All Tasks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {tasks.length === 0 ? (
                    <div className="text-center py-8">
                      <CalendarIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No tasks found for this business plan</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {tasks.map((task: any) => (
                        <CalendarTask
                          key={task.id}
                          task={task}
                          onUpdate={handleTaskUpdate}
                          disabled={businessPlan.isLocked}
                        />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Upcoming Tasks */}
              <Card>
                <CardHeader>
                  <CardTitle className="font-handwritten text-xl text-sky flex items-center">
                    🎯 Upcoming Tasks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {upcomingTasks.length === 0 ? (
                    <div className="text-center py-4">
                      <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">All caught up! 🎉</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {upcomingTasks.map((task: any) => (
                        <div key={task.id} className="border border-gray-200 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <Badge className="bg-sky/10 text-sky text-xs">
                              Day {task.dayNumber}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              {new Date(task.taskDate).toLocaleDateString()}
                            </span>
                          </div>
                          <h4 className="font-medium text-sm text-gray-800 mb-1">{task.title}</h4>
                          <p className="text-xs text-gray-600 line-clamp-2">{task.description}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Progress Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="font-handwritten text-xl text-mint flex items-center">
                    📈 Your Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Completion Rate</span>
                        <span className="font-bold">{progressPercentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-gradient-to-r from-mint to-teal h-3 rounded-full transition-all duration-300"
                          style={{ width: `${progressPercentage}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="bg-green-50 rounded-lg p-3">
                        <div className="text-lg font-bold text-green-700">{completedTasks}</div>
                        <div className="text-xs text-green-600">Completed</div>
                      </div>
                      <div className="bg-orange-50 rounded-lg p-3">
                        <div className="text-lg font-bold text-orange-700">{totalTasks - completedTasks}</div>
                        <div className="text-xs text-orange-600">Remaining</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="font-handwritten text-xl text-plum flex items-center">
                    ⚡ Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={() => setLocation(`/business-plan/${id}`)}
                    variant="outline" 
                    className="w-full border-plum text-plum hover:bg-plum hover:text-white rounded-full"
                  >
                    📋 View Business Plan
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full border-coral text-coral hover:bg-coral hover:text-white rounded-full"
                  >
                    📥 Export Progress
                  </Button>
                  <Button 
                    onClick={() => setLocation("/")}
                    variant="outline" 
                    className="w-full border-sky text-sky hover:bg-sky hover:text-white rounded-full"
                  >
                    🏠 Dashboard
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          /* Calendar View */
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Calendar */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="font-handwritten text-2xl text-sky flex items-center">
                    📅 Calendar View
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    className="rounded-md border"
                    modifiers={{
                      hasTask: datesWithTasks,
                    }}
                    modifiersStyles={{
                      hasTask: { 
                        backgroundColor: 'hsl(var(--coral))', 
                        color: 'white',
                        fontWeight: 'bold'
                      },
                    }}
                  />
                  <p className="text-xs text-gray-500 mt-4">
                    💡 Dates with tasks are highlighted in color
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Selected Date Tasks */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="font-handwritten text-xl text-teal flex items-center">
                    📝 Tasks for {selectedDate.toLocaleDateString()}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {tasksForSelectedDate.length === 0 ? (
                    <div className="text-center py-8">
                      <Clock className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <p className="text-gray-600 text-sm">No tasks scheduled for this date</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {tasksForSelectedDate.map((task: any) => (
                        <CalendarTask
                          key={task.id}
                          task={task}
                          onUpdate={handleTaskUpdate}
                          disabled={businessPlan.isLocked}
                          compact={true}
                        />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
