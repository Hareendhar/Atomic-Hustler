import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  Lightbulb,
  Users,
  DollarSign,
  Clock,
  TrendingUp,
  ChevronDown,
  Zap
} from "lucide-react";

interface BusinessIdea {
  id: number;
  title: string;
  description: string;
  targetMarket: string;
  profitPotential: string;
  startupCost: string;
  difficulty: 'Low' | 'Medium' | 'High';
  timeToLaunch: string;
  isSelected?: boolean;
}

interface BusinessIdeaSelectProps {
  value?: number | null;
  onChange: (ideaId: number | null) => void;
  placeholder?: string;
  showDetails?: boolean;
  className?: string;
}

const difficultyColors = {
  Low: "bg-green-100 text-green-800 border-green-200",
  Medium: "bg-yellow-100 text-yellow-800 border-yellow-200", 
  High: "bg-red-100 text-red-800 border-red-200"
};

export function BusinessIdeaSelect({
  value,
  onChange,
  placeholder = "Select a business idea...",
  showDetails = true,
  className
}: BusinessIdeaSelectProps) {
  const [isOpen, setIsOpen] = useState(false);

  // Get user profile to check completion status
  const { data: profile } = useQuery({
    queryKey: ["/api/profile"],
    retry: 1,
  });

  // Get business ideas
  const { data: businessIdeas = [], isLoading } = useQuery<BusinessIdea[]>({
    queryKey: ["/api/business-ideas"],
    retry: 1,
  });

  const selectedIdea = businessIdeas.find((idea: BusinessIdea) => idea.id === value);

  if (isLoading) {
    return (
      <div className={cn("animate-pulse", className)}>
        <div className="h-10 bg-muted rounded-md"></div>
      </div>
    );
  }

  if (!businessIdeas.length) {
    return (
      <Card className={cn("border-dashed", className)}>
        <CardContent className="p-6 text-center">
          <Lightbulb className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <h3 className="font-semibold mb-2">No Business Ideas Yet</h3>
          <p className="text-sm text-muted-foreground mb-4">
            {!profile?.isCompleted 
              ? "Complete your profile first to generate personalized ideas."
              : "Generate business ideas first to create plans."
            }
          </p>
          {!profile?.isCompleted ? (
            <div className="space-y-3">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3">
                <p className="text-amber-800 text-xs font-medium">
                  Complete your profile to unlock idea generation
                </p>
              </div>
              <Button variant="outline" size="sm" asChild>
                <a href="/profile-setup">Complete Profile</a>
              </Button>
            </div>
          ) : (
            <Button variant="outline" size="sm" asChild>
              <a href="/ideas">Generate Ideas</a>
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={cn("space-y-4", className)}>
      {/* Dropdown Selector */}
      <Select
        value={value?.toString() || ""}
        onValueChange={(val) => onChange(val ? parseInt(val) : null)}
      >
        <SelectTrigger className="h-12">
          <div className="flex items-center gap-3 flex-1">
            {selectedIdea ? (
              <>
                <Zap className="w-4 h-4 text-primary" />
                <div className="text-left">
                  <div className="font-medium">{selectedIdea.title}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {selectedIdea.description}
                  </div>
                </div>
              </>
            ) : (
              <>
                <Lightbulb className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">{placeholder}</span>
              </>
            )}
          </div>
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        </SelectTrigger>
        <SelectContent>
          {businessIdeas.map((idea: BusinessIdea) => (
            <SelectItem key={idea.id} value={idea.id.toString()}>
              <div className="flex items-center gap-2 py-1">
                <Zap className="w-3 h-3 text-primary" />
                <div>
                  <div className="font-medium">{idea.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {idea.difficulty} • {idea.timeToLaunch}
                  </div>
                </div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Detailed Card View */}
      <AnimatePresence>
        {selectedIdea && showDetails && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <Card className="overflow-hidden bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-lg mb-1">{selectedIdea.title}</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {selectedIdea.description}
                    </p>
                  </div>
                  <Badge 
                    className={cn(
                      "ml-3 font-medium border",
                      difficultyColors[selectedIdea.difficulty]
                    )}
                  >
                    {selectedIdea.difficulty}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="bg-background/50 rounded-lg p-3 border"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Users className="w-3 h-3 text-primary" />
                      <span className="font-medium text-xs">Target Market</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {selectedIdea.targetMarket}
                    </p>
                  </motion.div>

                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-background/50 rounded-lg p-3 border"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <TrendingUp className="w-3 h-3 text-green-600" />
                      <span className="font-medium text-xs">Profit Potential</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {selectedIdea.profitPotential}
                    </p>
                  </motion.div>

                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="bg-background/50 rounded-lg p-3 border"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <DollarSign className="w-3 h-3 text-blue-600" />
                      <span className="font-medium text-xs">Startup Cost</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {selectedIdea.startupCost}
                    </p>
                  </motion.div>

                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="bg-background/50 rounded-lg p-3 border"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-3 h-3 text-purple-600" />
                      <span className="font-medium text-xs">Time to Launch</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {selectedIdea.timeToLaunch}
                    </p>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}