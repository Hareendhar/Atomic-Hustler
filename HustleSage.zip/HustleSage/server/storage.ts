import {
  users,
  userProfiles,
  businessIdeas,
  businessPlans,
  calendarTasks,
  chatMessages,
  financialPlans,
  marketingPlans,
  contacts,

  type User,
  type UpsertUser,
  type UserProfile,
  type InsertUserProfile,
  type BusinessIdea,
  type InsertBusinessIdea,
  type BusinessPlan,
  type InsertBusinessPlan,
  type CalendarTask,
  type InsertCalendarTask,
  type ChatMessage,
  type InsertChatMessage,
  type Contact,
  type InsertContact,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Profile operations
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile>;

  // Business ideas operations
  getUserBusinessIdeas(userId: string): Promise<BusinessIdea[]>;
  createBusinessIdeas(ideas: InsertBusinessIdea[]): Promise<BusinessIdea[]>;
  getBusinessIdea(id: number): Promise<BusinessIdea | undefined>;
  updateBusinessIdea(id: number, idea: Partial<InsertBusinessIdea>): Promise<BusinessIdea>;

  // Business plan operations
  getUserBusinessPlans(userId: string): Promise<BusinessPlan[]>;
  createBusinessPlan(plan: InsertBusinessPlan): Promise<BusinessPlan>;
  getBusinessPlan(id: number): Promise<BusinessPlan | undefined>;
  updateBusinessPlan(id: number, plan: Partial<InsertBusinessPlan>): Promise<BusinessPlan>;
  lockBusinessPlan(id: number): Promise<BusinessPlan>;

  // Calendar task operations
  getCalendarTasks(businessPlanId: number): Promise<CalendarTask[]>;
  createCalendarTask(task: InsertCalendarTask): Promise<CalendarTask>;
  updateCalendarTask(id: number, task: Partial<CalendarTask>): Promise<CalendarTask | null>;

  // Chat operations
  getChatMessages(userId: string, businessPlanId?: number, ideaIndex?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Idea-specific chat operations
  getIdeaChatMessages(userId: string, ideaId: number): Promise<any[]>;
  createIdeaChatMessage(message: any): Promise<any>;

   // Financial plan operations
  getFinancialPlan(businessPlanId: number): Promise<any | undefined>;
  createFinancialPlan(plan: any): Promise<any>;
  updateFinancialPlan(businessPlanId: number, data: any): Promise<any>;

    // Marketing plan operations
  getMarketingPlan(businessPlanId: number): Promise<any | undefined>;
  createMarketingPlan(plan: any): Promise<any>;
  updateMarketingPlan(businessPlanId: number, plan: any): Promise<any>;

    // Sales notebook operations
  getContacts(businessPlanId: number): Promise<any[]>;
  createContact(contactData: any): Promise<any>;
  updateContact(contactId: number, contactData: any): Promise<any>;
  getSalesStats(businessPlanId: number): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Profile operations
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId));
    return profile;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const [newProfile] = await db
      .insert(userProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateUserProfile(userId: string, profileData: Partial<InsertUserProfile>): Promise<UserProfile> {
    const [profile] = await db
      .update(userProfiles)
      .set({ ...profileData, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return profile;
  }

  // Business ideas operations
  async getUserBusinessIdeas(userId: string): Promise<BusinessIdea[]> {
    return await db
      .select()
      .from(businessIdeas)
      .where(eq(businessIdeas.userId, userId))
      .orderBy(desc(businessIdeas.createdAt));
  }

  async createBusinessIdeas(ideas: InsertBusinessIdea[]): Promise<BusinessIdea[]> {
    const newIdeas = await db
      .insert(businessIdeas)
      .values(ideas)
      .returning();
    return newIdeas;
  }

  async getBusinessIdea(id: number): Promise<BusinessIdea | undefined> {
    const [idea] = await db
      .select()
      .from(businessIdeas)
      .where(eq(businessIdeas.id, id));
    return idea;
  }

  async updateBusinessIdea(id: number, ideaData: Partial<InsertBusinessIdea>): Promise<BusinessIdea> {
    const [idea] = await db
      .update(businessIdeas)
      .set({ ...ideaData, updatedAt: new Date() })
      .where(eq(businessIdeas.id, id))
      .returning();
    return idea;
  }

  // Business plan operations
  async getUserBusinessPlans(userId: string): Promise<BusinessPlan[]> {
    return await db
      .select()
      .from(businessPlans)
      .where(eq(businessPlans.userId, userId))
      .orderBy(desc(businessPlans.createdAt));
  }

  async hasLockedBusinessPlan(userId: string): Promise<boolean> {
    const [plan] = await db
      .select()
      .from(businessPlans)
      .where(and(eq(businessPlans.userId, userId), eq(businessPlans.isLocked, true)))
      .limit(1);
    return !!plan;
  }

  async createBusinessPlan(plan: InsertBusinessPlan): Promise<BusinessPlan> {
    const [newPlan] = await db
      .insert(businessPlans)
      .values(plan)
      .returning();
    return newPlan;
  }

  async getBusinessPlan(id: number): Promise<BusinessPlan | undefined> {
    const [plan] = await db
      .select()
      .from(businessPlans)
      .where(eq(businessPlans.id, id));
    return plan;
  }

  async updateBusinessPlan(id: number, planData: Partial<InsertBusinessPlan>): Promise<BusinessPlan> {
    const [plan] = await db
      .update(businessPlans)
      .set({ ...planData, updatedAt: new Date() })
      .where(eq(businessPlans.id, id))
      .returning();
    return plan;
  }

  async lockBusinessPlan(id: number): Promise<BusinessPlan> {
    const [plan] = await db
      .update(businessPlans)
      .set({ 
        isLocked: true, 
        lockedAt: new Date(),
        status: "locked",
        updatedAt: new Date() 
      })
      .where(eq(businessPlans.id, id))
      .returning();
    return plan;
  }

  // Calendar task operations
  async getCalendarTasks(businessPlanId: number): Promise<CalendarTask[]> {
    return await db
      .select()
      .from(calendarTasks)
      .where(eq(calendarTasks.businessPlanId, businessPlanId))
      .orderBy(calendarTasks.dayNumber);
  }

  async createCalendarTask(task: InsertCalendarTask): Promise<CalendarTask> {
    const [newTask] = await db
      .insert(calendarTasks)
      .values(task)
      .returning();
    return newTask;
  }

  async updateCalendarTask(taskId: number, updates: Partial<CalendarTask>): Promise<CalendarTask | null> {
    console.log(`Storage: Updating task ${taskId} with:`, updates);

    const updatedTask = await db.update(calendarTasks)
      .set({
        ...updates,
        isCompleted: updates.isCompleted !== undefined ? Boolean(updates.isCompleted) : undefined,
        updatedAt: new Date()
      })
      .where(eq(calendarTasks.id, taskId))
      .returning();

    console.log("Storage: Updated task result:", updatedTask[0]);
    return updatedTask[0] || null;
  }

  // Chat operations
  async getChatMessages(userId: string, businessPlanId?: number, ideaIndex?: number): Promise<ChatMessage[]> {
    let conditions = [eq(chatMessages.userId, userId)];

    if (businessPlanId !== undefined) {
      conditions.push(eq(chatMessages.businessPlanId, businessPlanId));
    }

    if (ideaIndex !== undefined) {
      conditions.push(eq(chatMessages.ideaIndex, ideaIndex));
    }

    return await db
      .select()
      .from(chatMessages)
      .where(and(...conditions))
      .orderBy(chatMessages.createdAt);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return newMessage;
  }

  // Idea-specific chat operations
  async getIdeaChatMessages(userId: string, ideaId: number): Promise<any[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(and(
        eq(chatMessages.userId, userId),
        eq(chatMessages.ideaId, ideaId)
      ))
      .orderBy(chatMessages.createdAt);
  }

  async createIdeaChatMessage(message: any): Promise<any> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return newMessage;
  }

    // Financial plan operations
  async getFinancialPlan(businessPlanId: number) {
    console.log("Querying financial plan for business plan ID:", businessPlanId);
    try {
      const result = await db
        .select()
        .from(financialPlans)
        .where(eq(financialPlans.businessPlanId, businessPlanId))
        .limit(1);

      console.log("Financial plan query result:", result.length > 0);
      console.log("Financial plan data sample:", result[0] ? Object.keys(result[0]).slice(0, 5) : 'No data');
      return result[0] || null;
    } catch (error) {
      console.error("Error querying financial plan:", error);
      return null;
    }
  }

  async createFinancialPlan(data: any): Promise<any> {
    const [plan] = await db
      .insert(financialPlans)
      .values(data)
      .returning();
    return plan;
  }

  async updateFinancialPlan(businessPlanId: number, data: any): Promise<any> {
    const [plan] = await db
      .update(financialPlans)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(financialPlans.businessPlanId, businessPlanId))
      .returning();
    return plan;
  }

  // Marketing Plan functions
  async getMarketingPlan(businessPlanId: number) {
    console.log("Querying marketing plan for business plan ID:", businessPlanId);
    try {
      const [marketingPlan] = await db
        .select()
        .from(marketingPlans)
        .where(eq(marketingPlans.businessPlanId, businessPlanId))
        .limit(1);

      const hasData = marketingPlan && Object.values(marketingPlan).some(value => 
        value !== null && value !== undefined && value !== ''
      );

      console.log("Marketing plan query result:", !!marketingPlan);
      if (marketingPlan && hasData) {
        console.log("Marketing plan data sample:", {
          id: marketingPlan.id,
          brandVoiceLength: marketingPlan.brandVoiceMessaging?.length || 0,
          contentIdeasLength: marketingPlan.contentPlanIdeas?.length || 0,
          hasData: true
        });
      }

      return marketingPlan || null;
    } catch (error) {
      console.error("Error fetching marketing plan:", error);
      throw error;
    }
  }

  async createMarketingPlan(data: any): Promise<any> {
    const [plan] = await db
      .insert(marketingPlans)
      .values(data)
      .returning();
    return plan;
  }

  async updateMarketingPlan(businessPlanId: number, data: any): Promise<any> {
    const [plan] = await db
      .update(marketingPlans)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(marketingPlans.businessPlanId, businessPlanId))
      .returning();
    return plan;
  }

  async getContacts(businessPlanId: number): Promise<any[]> {
    const result = await db
      .select()
      .from(contacts)
      .where(eq(contacts.businessPlanId, businessPlanId))
      .orderBy(desc(contacts.lastActivity));
    return result;
  }

  async createContact(contactData: any): Promise<any> {
    const [result] = await db
      .insert(contacts)
      .values({
        ...contactData,
        lastActivity: new Date(),
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return result;
  }

  async updateContact(contactId: number, contactData: any): Promise<any> {
    const [result] = await db
      .update(contacts)
      .set({ 
        ...contactData, 
        lastActivity: new Date(),
        updatedAt: new Date() 
      })
      .where(eq(contacts.id, contactId))
      .returning();
    return result;
  }

  async getSalesStats(businessPlanId: number): Promise<any> {
    const allContacts = await db
      .select()
      .from(contacts)
      .where(eq(contacts.businessPlanId, businessPlanId));

    const totalContacts = allContacts.length;
    const wonContacts = allContacts.filter(c => c.status === 'Won').length;
    const conversionRate = totalContacts > 0 ? Math.round((wonContacts / totalContacts) * 100) : 0;

    return {
      totalContacts,
      wonContacts,
      conversionRate,
      milestones: {
        firstCustomer: wonContacts >= 1,
        tenCustomers: wonContacts >= 10,
        firstRevenue: wonContacts >= 1
      }
    };
  }
}

export const storage = new DatabaseStorage();