import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { 
  Lightbulb, 
  Users, 
  DollarSign, 
  Clock, 
  TrendingUp, 
  Star,
  ChevronLeft,
  ChevronRight,
  Zap
} from "lucide-react";

interface BusinessIdea {
  id: number;
  title: string;
  description: string;
  targetMarket: string;
  profitPotential: string;
  startupCost: string;
  difficulty: 'Low' | 'Medium' | 'High';
  timeToLaunch: string;
  isSelected?: boolean;
}

interface InteractiveIdeaSelectorProps {
  ideas: BusinessIdea[];
  selectedIdea?: BusinessIdea | null;
  onIdeaSelect: (idea: BusinessIdea) => void;
  onCreatePlan?: (ideaId: number) => void;
  isLoading?: boolean;
  className?: string;
}

const difficultyColors = {
  Low: "bg-green-100 text-green-800 border-green-200",
  Medium: "bg-yellow-100 text-yellow-800 border-yellow-200", 
  High: "bg-red-100 text-red-800 border-red-200"
};

const difficultyIcons = {
  Low: "🟢",
  Medium: "🟡",
  High: "🔴"
};

export function InteractiveIdeaSelector({
  ideas,
  selectedIdea,
  onIdeaSelect,
  onCreatePlan,
  isLoading = false,
  className
}: InteractiveIdeaSelectorProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (selectedIdea) {
      const index = ideas.findIndex(idea => idea.id === selectedIdea.id);
      if (index !== -1) {
        setCurrentIndex(index);
      }
    }
  }, [selectedIdea, ideas]);

  const handlePrevious = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : ideas.length - 1));
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handleNext = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prev) => (prev < ideas.length - 1 ? prev + 1 : 0));
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handleCardClick = (idea: BusinessIdea, index: number) => {
    if (isAnimating || index === currentIndex) return;
    setIsAnimating(true);
    setCurrentIndex(index);
    onIdeaSelect(idea);
    setTimeout(() => setIsAnimating(false), 300);
  };

  if (!ideas.length) {
    return (
      <div className={cn("text-center py-12", className)}>
        <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-8 max-w-md mx-auto">
          <Lightbulb className="w-16 h-16 text-primary mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No Ideas Generated Yet</h3>
          <p className="text-muted-foreground mb-4">
            Start by generating personalized business ideas based on your profile.
          </p>
        </div>
      </div>
    );
  }

  const currentIdea = ideas[currentIndex];

  return (
    <div className={cn("space-y-6", className)}>
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
          Your Personalized Business Ideas
        </h2>
        <p className="text-muted-foreground">
          {ideas.length} AI-generated ideas tailored specifically for you
        </p>
      </div>

      {/* Main Idea Display */}
      <div className="relative">
        {/* Navigation Buttons */}
        <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
          <Button
            variant="outline"
            size="icon"
            onClick={handlePrevious}
            disabled={isAnimating || ideas.length <= 1}
            className="bg-background/80 backdrop-blur-sm hover:bg-background"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
        
        <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
          <Button
            variant="outline"
            size="icon"
            onClick={handleNext}
            disabled={isAnimating || ideas.length <= 1}
            className="bg-background/80 backdrop-blur-sm hover:bg-background"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Main Card Container */}
        <div className="mx-12 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -100, scale: 0.9 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
            >
              <Card className="relative border-2 bg-gradient-to-br from-background to-background/50 hover:shadow-xl transition-all duration-300">
                {/* Selection Indicator */}
                {selectedIdea?.id === currentIdea.id && (
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-2 -right-2 bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center z-10"
                  >
                    <Star className="w-4 h-4 fill-current" />
                  </motion.div>
                )}

                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-2xl mb-2 flex items-center gap-2">
                        <Zap className="w-6 h-6 text-primary" />
                        {currentIdea.title}
                      </CardTitle>
                      <p className="text-muted-foreground leading-relaxed">
                        {currentIdea.description}
                      </p>
                    </div>
                    <Badge 
                      className={cn(
                        "ml-4 font-medium border",
                        difficultyColors[currentIdea.difficulty]
                      )}
                    >
                      {difficultyIcons[currentIdea.difficulty]} {currentIdea.difficulty}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* Key Metrics Grid */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="bg-primary/5 rounded-lg p-4 border border-primary/10"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <Users className="w-5 h-5 text-primary" />
                        <h4 className="font-semibold">Target Market</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {currentIdea.targetMarket}
                      </p>
                    </motion.div>

                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="bg-green-50 rounded-lg p-4 border border-green-100"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                        <h4 className="font-semibold">Profit Potential</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {currentIdea.profitPotential}
                      </p>
                    </motion.div>

                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="bg-blue-50 rounded-lg p-4 border border-blue-100"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <DollarSign className="w-5 h-5 text-blue-600" />
                        <h4 className="font-semibold">Startup Cost</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {currentIdea.startupCost}
                      </p>
                    </motion.div>

                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      className="bg-purple-50 rounded-lg p-4 border border-purple-100"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <Clock className="w-5 h-5 text-purple-600" />
                        <h4 className="font-semibold">Time to Launch</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {currentIdea.timeToLaunch}
                      </p>
                    </motion.div>
                  </div>

                  {/* Action Buttons */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="flex gap-3 pt-4"
                  >
                    <Button
                      onClick={() => onIdeaSelect(currentIdea)}
                      variant={selectedIdea?.id === currentIdea.id ? "default" : "outline"}
                      className="flex-1"
                      disabled={isLoading}
                    >
                      {selectedIdea?.id === currentIdea.id ? "Selected" : "Select This Idea"}
                    </Button>
                    
                    {onCreatePlan && selectedIdea?.id === currentIdea.id && (
                      <Button
                        onClick={() => onCreatePlan(currentIdea.id)}
                        disabled={isLoading}
                        className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                      >
                        Create Business Plan
                      </Button>
                    )}
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Idea Thumbnails */}
      {ideas.length > 1 && (
        <div className="flex justify-center gap-2 pt-4">
          {ideas.map((idea, index) => (
            <motion.button
              key={idea.id}
              onClick={() => handleCardClick(idea, index)}
              className={cn(
                "w-3 h-3 rounded-full transition-all duration-300",
                index === currentIndex 
                  ? "bg-primary scale-125" 
                  : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
              )}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            />
          ))}
        </div>
      )}

      {/* Quick Stats */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="text-center text-sm text-muted-foreground"
      >
        Showing idea {currentIndex + 1} of {ideas.length} • 
        <span className="text-primary font-medium"> Personalized for your profile</span>
      </motion.div>
    </div>
  );
}