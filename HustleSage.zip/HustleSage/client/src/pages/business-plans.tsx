import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation, useParams } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Calendar,
  TrendingUp,
  Plus,
  Eye,
  Loader2,
  AlertCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import type { BusinessPlan, BusinessIdea } from "@shared/schema";

export default function BusinessPlans() {
  const { id } = useParams<{ id?: string }>();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  // Get business plans
  const { data: businessPlans = [], isLoading, error } = useQuery<BusinessPlan[]>({
    queryKey: ["/api/business-plans"],
    retry: 1,
  });

  // Get business ideas to check if user has any
  const { data: ideas = [] } = useQuery<BusinessIdea[]>({
    queryKey: ["/api/business-ideas"],
    retry: 1,
  });

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" />
            <p className="text-muted-foreground">Loading business plans...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto text-center">
          <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Unable to Load Business Plans</h2>
          <p className="text-muted-foreground mb-6">
            There was an issue loading your business plans. Please try again.
          </p>
          <Button onClick={() => window.location.reload()}>
            Refresh Page
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Business Plans</h1>
            <p className="text-muted-foreground">
              Manage your comprehensive business plans and execution strategies
            </p>
          </div>
          <div className="flex gap-4">
            {ideas.length === 0 ? (
              <Link href="/ideas">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Generate Ideas First
                </Button>
              </Link>
            ) : (
              <Link href="/business-plan/new">
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create New Plan
                </Button>
              </Link>
            )}
          </div>
        </div>

        {businessPlans.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No Business Plans Yet</h3>
              <p className="text-muted-foreground mb-6">
                {ideas.length === 0
                  ? "Start by generating business ideas, then create comprehensive plans for your favorites."
                  : "Create your first comprehensive business plan from your generated ideas."
                }
              </p>
              {ideas.length === 0 ? (
                <Link href="/ideas">
                  <Button size="lg">
                    <Plus className="w-4 h-4 mr-2" />
                    Generate Ideas First
                  </Button>
                </Link>
              ) : (
                <Link href="/business-plan/new">
                  <Button size="lg">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Plan
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {businessPlans.map((plan: BusinessPlan) => (
              <Card key={plan.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg line-clamp-2">{plan.title}</CardTitle>
                    <div className="flex flex-col gap-2 ml-4">
                      <Badge variant={plan.isLocked ? "destructive" : "secondary"}>
                        {plan.isLocked ? "Locked" : plan.status}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {plan.daysPlanned} Days
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-sm text-muted-foreground">
                      <p>Created: {plan.createdAt ? new Date(plan.createdAt).toLocaleDateString() : 'N/A'}</p>
                      <p>Updated: {plan.updatedAt ? new Date(plan.updatedAt).toLocaleDateString() : 'N/A'}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant={plan.status === 'locked' ? 'default' : 'secondary'}>
                        {plan.status}
                      </Badge>
                      <div className="flex gap-1">
                        <Button
                          onClick={() => setLocation(`/business-plan/${plan.id}`)}
                          size="sm"
                        >
                          View Plan
                        </Button>
                        <Button
                          onClick={() => setLocation(`/financial-plan/${plan.id}`)}
                          variant="outline"
                          size="sm"
                        >
                          Financial
                        </Button>
                        <Button
                          onClick={() => setLocation(`/execution-calendar/${plan.id}`)}
                          variant="outline"
                          size="sm"
                        >
                          Calendar
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}