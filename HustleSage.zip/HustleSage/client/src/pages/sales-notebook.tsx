import { useState, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Plus, 
  Users, 
  CheckCircle, 
  Phone, 
  MessageSquare, 
  FileText, 
  Package, 
  Search,
  Calendar,
  ExternalLink,
  Trophy,
  Target
} from "lucide-react";

interface Contact {
  id?: number;
  businessPlanId: number;
  customerName: string;
  contactInfo: string;
  channelSource: string;
  status: string;
  nextAction: string;
  nextActionDate: string;
  notes: string;
  lastActivity: string;
  createdAt?: string;
  updatedAt?: string;
}

interface SalesStats {
  totalContacts: number;
  wonContacts: number;
  conversionRate: number;
  milestones: {
    firstCustomer: boolean;
    tenCustomers: boolean;
    firstRevenue: boolean;
  };
}

const channelOptions = [
  "Referral",
  "Instagram DM", 
  "WhatsApp Group",
  "Walk-in",
  "Event",
  "Other"
];

const statusOptions = [
  "New",
  "Contacted", 
  "Interested",
  "Negotiating",
  "Won",
  "Lost"
];

const nextActionOptions = [
  "Call",
  "WhatsApp",
  "Send Invoice", 
  "Deliver Sample",
  "No Next Action"
];

const statusColors = {
  "New": "bg-blue-100 text-blue-800",
  "Contacted": "bg-yellow-100 text-yellow-800", 
  "Interested": "bg-green-100 text-green-800",
  "Negotiating": "bg-orange-100 text-orange-800",
  "Won": "bg-emerald-100 text-emerald-800",
  "Lost": "bg-red-100 text-red-800"
};

export default function SalesNotebook() {
  const params = useParams();
  const businessPlanId = params.id;
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [channelFilter, setChannelFilter] = useState("all");
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newContact, setNewContact] = useState<Partial<Contact>>({});

  // Fetch contacts
  const { data: contacts = [], isLoading } = useQuery<Contact[]>({
    queryKey: [`/api/business-plans/${businessPlanId}/contacts`],
    enabled: !!businessPlanId && businessPlanId !== "undefined",
  });

  // Fetch stats
  const { data: stats } = useQuery<SalesStats>({
    queryKey: [`/api/business-plans/${businessPlanId}/sales-stats`],
    enabled: !!businessPlanId && businessPlanId !== "undefined",
  });

  // Add contact mutation
  const addContactMutation = useMutation({
    mutationFn: async (contactData: Partial<Contact>) => {
      const response = await fetch(`/api/business-plans/${businessPlanId}/contacts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(contactData),
      });
      if (!response.ok) throw new Error("Failed to add contact");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${businessPlanId}/contacts`] });
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${businessPlanId}/sales-stats`] });
      toast({ title: "Contact added successfully!" });
    },
  });

  // Update contact mutation
  const updateContactMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Contact> }) => {
      const response = await fetch(`/api/business-plans/${businessPlanId}/contacts/${id}`, {
        method: "PUT", 
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to update contact");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${businessPlanId}/contacts`] });
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${businessPlanId}/sales-stats`] });
      setEditingContact(null);
    },
  });

  const handleAddContact = () => {
    setIsAddingNew(true);
    setNewContact({
      businessPlanId: parseInt(businessPlanId!),
      customerName: "",
      contactInfo: "",
      channelSource: "Other",
      status: "New",
      nextAction: "Call",
      nextActionDate: "",
      notes: "",
      lastActivity: new Date().toISOString()
    });
  };

  const handleSaveNewContact = () => {
    if (!newContact.customerName?.trim()) {
      toast({ title: "Please enter customer name", variant: "destructive" });
      return;
    }
    addContactMutation.mutate(newContact, {
      onSuccess: () => {
        setIsAddingNew(false);
        setNewContact({});
      }
    });
  };

  const handleCancelNewContact = () => {
    setIsAddingNew(false);
    setNewContact({});
  };

  const handleUpdateContact = (contact: Contact, field: string, value: string) => {
    const updatedData = { 
      ...contact, 
      [field]: value,
      lastActivity: new Date().toISOString()
    };
    updateContactMutation.mutate({ id: contact.id!, data: updatedData });
  };

  const handleStatusChange = (contact: Contact, status: string) => {
    handleUpdateContact(contact, "status", status);
  };

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = contact.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.contactInfo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || contact.status === statusFilter;
    const matchesChannel = channelFilter === "all" || contact.channelSource === channelFilter;
    return matchesSearch && matchesStatus && matchesChannel;
  });

  const isOverdue = (date: string) => {
    if (!date) return false;
    return new Date(date) < new Date();
  };

  const formatContactInfo = (info: string) => {
    if (info.startsWith("http") || info.includes("wa.me") || info.includes("instagram.com")) {
      return (
        <a href={info} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline flex items-center gap-1">
          {info}
          <ExternalLink className="w-3 h-3" />
        </a>
      );
    }
    if (info.match(/^\+?[\d\s-()]+$/)) {
      return (
        <a href={`tel:${info}`} className="text-blue-600 hover:underline flex items-center gap-1">
          {info}
          <Phone className="w-3 h-3" />
        </a>
      );
    }
    return info;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
          <p className="text-muted-foreground">Loading Sales Notebook...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-primary" />
              <h1 className="text-xl font-bold">My First 50 Customers</h1>
            </div>
            <Link href={`/business-plan/${businessPlanId}`}>
              <Button variant="ghost">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Business Plan
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Section */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Progress</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Customers Won</span>
                    <span className="font-bold">{stats?.wonContacts || 0} / 50</span>
                  </div>
                  <Progress value={(stats?.wonContacts || 0) / 50 * 100} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    {stats?.conversionRate || 0}% conversion rate
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">Milestones</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    {stats?.milestones?.firstCustomer ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <Target className="w-4 h-4 text-gray-400" />
                    )}
                    <span className={stats?.milestones?.firstCustomer ? "text-green-600" : "text-gray-400"}>
                      🎉 First Customer
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {stats?.milestones?.tenCustomers ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <Target className="w-4 h-4 text-gray-400" />
                    )}
                    <span className={stats?.milestones?.tenCustomers ? "text-green-600" : "text-gray-400"}>
                      💪 10 Customers
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {stats?.milestones?.firstRevenue ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <Target className="w-4 h-4 text-gray-400" />
                    )}
                    <span className={stats?.milestones?.firstRevenue ? "text-green-600" : "text-gray-400"}>
                      🪙 First ₹10,000
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center">
                <Button onClick={handleAddContact} className="bg-[#78350f] hover:bg-[#92400e] text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add New Contact
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                <Input 
                  placeholder="Search by name or contact..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  {statusOptions.map(status => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={channelFilter} onValueChange={setChannelFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by Channel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Channels</SelectItem>
                  {channelOptions.map(channel => (
                    <SelectItem key={channel} value={channel}>{channel}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Contacts Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1200px]">
                <thead className="border-b">
                  <tr className="bg-muted/50">
                    <th className="text-left p-4 font-medium min-w-[150px]">Customer Name</th>
                    <th className="text-left p-4 font-medium min-w-[200px]">Contact Info</th>
                    <th className="text-left p-4 font-medium min-w-[120px]">Channel</th>
                    <th className="text-left p-4 font-medium min-w-[120px]">Status</th>
                    <th className="text-left p-4 font-medium min-w-[120px]">Next Action</th>
                    <th className="text-left p-4 font-medium min-w-[130px]">Next Date</th>
                    <th className="text-left p-4 font-medium min-w-[200px]">Notes</th>
                    <th className="text-left p-4 font-medium min-w-[120px]">Last Activity</th>
                    <th className="text-left p-4 font-medium min-w-[100px]">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {/* New Contact Row */}
                  {isAddingNew && (
                    <tr className="border-b bg-green-50 hover:bg-green-100">
                      <td className="p-4">
                        <Input
                          value={newContact.customerName || ""}
                          onChange={(e) => setNewContact({...newContact, customerName: e.target.value})}
                          placeholder="Enter customer name..."
                          className="w-full"
                          autoFocus
                        />
                      </td>
                      <td className="p-4">
                        <Input
                          value={newContact.contactInfo || ""}
                          onChange={(e) => setNewContact({...newContact, contactInfo: e.target.value})}
                          placeholder="Phone, email, or link..."
                          className="w-full"
                        />
                      </td>
                      <td className="p-4">
                        <Select 
                          value={newContact.channelSource || "Other"} 
                          onValueChange={(value) => setNewContact({...newContact, channelSource: value})}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {channelOptions.map(channel => (
                              <SelectItem key={channel} value={channel}>{channel}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-4">
                        <Select 
                          value={newContact.status || "New"} 
                          onValueChange={(value) => setNewContact({...newContact, status: value})}
                        >
                          <SelectTrigger className="w-full">
                            <Badge variant="outline" className={statusColors[newContact.status as keyof typeof statusColors] || "bg-blue-100 text-blue-800"}>
                              {newContact.status || "New"}
                            </Badge>
                          </SelectTrigger>
                          <SelectContent>
                            {statusOptions.map(status => (
                              <SelectItem key={status} value={status}>{status}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-4">
                        <Select 
                          value={newContact.nextAction || "Call"} 
                          onValueChange={(value) => setNewContact({...newContact, nextAction: value})}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {nextActionOptions.map(action => (
                              <SelectItem key={action} value={action}>{action}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-4">
                        <Input
                          type="date"
                          value={newContact.nextActionDate?.split('T')[0] || ''}
                          onChange={(e) => setNewContact({...newContact, nextActionDate: e.target.value})}
                          className="w-full"
                        />
                      </td>
                      <td className="p-4">
                        <Textarea
                          value={newContact.notes || ""}
                          onChange={(e) => setNewContact({...newContact, notes: e.target.value})}
                          placeholder="Add notes..."
                          className="w-full min-h-[40px]"
                          rows={2}
                        />
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">
                        New
                      </td>
                      <td className="p-4">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            onClick={handleSaveNewContact}
                            className="bg-green-600 hover:bg-green-700 text-white px-2 h-8"
                            disabled={addContactMutation.isPending}
                          >
                            💾
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleCancelNewContact}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 px-2 h-8"
                          >
                            ✖️
                          </Button>
                        </div>
                      </td>
                    </tr>
                  )}

                  {/* Existing Contacts */}
                  {filteredContacts.map((contact, index) => (
                    <tr key={contact.id || index} className="border-b hover:bg-muted/25">
                      <td className="p-4">
                        <div className="w-full overflow-hidden">
                          {editingContact?.id === contact.id ? (
                            <Input
                              value={contact.customerName}
                              onChange={(e) => handleUpdateContact(contact, "customerName", e.target.value)}
                              placeholder="Enter name..."
                              className="w-full"
                              onBlur={() => setEditingContact(null)}
                              autoFocus
                            />
                          ) : (
                            <div 
                              onClick={() => setEditingContact(contact)}
                              className="cursor-pointer hover:bg-gray-50 p-1 rounded min-h-[24px] break-words"
                              title={contact.customerName}
                            >
                              {contact.customerName || "Click to edit..."}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="w-full overflow-hidden">
                          {editingContact?.id === contact.id ? (
                            <Input
                              value={contact.contactInfo}
                              onChange={(e) => handleUpdateContact(contact, "contactInfo", e.target.value)}
                              placeholder="Phone, email, or link..."
                              className="w-full"
                              onBlur={() => setEditingContact(null)}
                            />
                          ) : (
                            <div 
                              onClick={() => setEditingContact(contact)}
                              className="cursor-pointer hover:bg-gray-50 p-1 rounded min-h-[24px] break-words"
                              title={contact.contactInfo}
                            >
                              {contact.contactInfo ? formatContactInfo(contact.contactInfo) : "Click to edit..."}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <Select 
                          value={contact.channelSource} 
                          onValueChange={(value) => handleUpdateContact(contact, "channelSource", value)}
                        >
                          <SelectTrigger className="w-full border-0 bg-transparent focus:ring-0">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {channelOptions.map(channel => (
                              <SelectItem key={channel} value={channel}>{channel}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-4">
                        <Select 
                          value={contact.status} 
                          onValueChange={(value) => handleUpdateContact(contact, "status", value)}
                        >
                          <SelectTrigger className="w-full border-0 bg-transparent focus:ring-0">
                            <Badge variant="outline" className={statusColors[contact.status as keyof typeof statusColors] || "bg-gray-100"}>
                              {contact.status}
                            </Badge>
                          </SelectTrigger>
                          <SelectContent>
                            {statusOptions.map(status => (
                              <SelectItem key={status} value={status}>{status}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-4">
                        <Select 
                          value={contact.nextAction} 
                          onValueChange={(value) => handleUpdateContact(contact, "nextAction", value)}
                        >
                          <SelectTrigger className="w-full border-0 bg-transparent focus:ring-0">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {nextActionOptions.map(action => (
                              <SelectItem key={action} value={action}>{action}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-4">
                        <Input
                          type="date"
                          value={contact.nextActionDate?.split('T')[0] || ''}
                          onChange={(e) => handleUpdateContact(contact, "nextActionDate", e.target.value)}
                          className={`w-full border-0 bg-transparent focus-visible:ring-0 ${
                            isOverdue(contact.nextActionDate) ? 'text-red-600' : ''
                          }`}
                        />
                      </td>
                      <td className="p-4">
                        <div className="w-full overflow-hidden">
                          {editingContact?.id === contact.id ? (
                            <Textarea
                              value={contact.notes}
                              onChange={(e) => handleUpdateContact(contact, "notes", e.target.value)}
                              placeholder="Add notes..."
                              className="w-full min-h-[40px]"
                              onBlur={() => setEditingContact(null)}
                              rows={2}
                            />
                          ) : (
                            <div 
                              onClick={() => setEditingContact(contact)}
                              className="cursor-pointer hover:bg-gray-50 p-1 rounded min-h-[24px] break-words max-h-[60px] overflow-y-auto"
                              title={contact.notes}
                            >
                              {contact.notes || "Click to add notes..."}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">
                        {contact.lastActivity ? new Date(contact.lastActivity).toLocaleDateString() : ''}
                      </td>
                      <td className="p-4">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleStatusChange(contact, "Won")}
                            className="text-green-600 hover:text-green-700 hover:bg-green-50 p-1 h-8 w-8"
                            title="Mark as Won"
                          >
                            ✅
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleStatusChange(contact, "Lost")}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 p-1 h-8 w-8"
                            title="Mark as Lost"
                          >
                            ❌
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {filteredContacts.length === 0 && !isAddingNew && (
              <div className="p-8 text-center text-muted-foreground">
                <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No contacts found. Add your first contact to get started!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}