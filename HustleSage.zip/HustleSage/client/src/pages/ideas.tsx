
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { ChatBox } from "@/components/chat-box";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  Lightbulb,
  MessageCircle,
  Send,
  Loader2,
  AlertCircle,
  CheckCircle,
  Sparkles,
  TrendingUp,
  Users,
  MapPin,
  Clock,
  DollarSign,
  Zap,
  FileText,
  ChevronDown,
  ChevronRight,
  AlertTriangle
} from "lucide-react";

interface BusinessIdea {
  id: number;
  title: string;
  description: string;
  targetMarket: string;
  profitPotential: string;
  startupCost: string;
  difficulty: 'Low' | 'Medium' | 'High';
  timeToLaunch: string;
  isSelected?: boolean;
}

interface ChatMessage {
  id: number;
  message: string;
  isFromUser: boolean;
  createdAt: string;
}

// Component for displaying individual idea with its dedicated chatbox
function IdeaWithChat({ idea, onCreatePlan, isExpanded, onToggle, businessPlans }: { 
  idea: BusinessIdea; 
  onCreatePlan: (idea: BusinessIdea) => void;
  isExpanded: boolean;
  onToggle: () => void;
  businessPlans: any[];
}) {
  const { toast } = useToast();
  
  // Fetch chat history for this specific idea
  const { data: ideaChatMessages = [], refetch: refetchChat } = useQuery<ChatMessage[]>({
    queryKey: ["/api/ideas", idea.id, "chat"],
    enabled: !!idea.id && isExpanded,
    retry: 1,
  });

  const difficultyColors = {
    Low: "bg-green-100 text-green-800 border-green-200",
    Medium: "bg-yellow-100 text-yellow-800 border-yellow-200", 
    High: "bg-red-100 text-red-800 border-red-200"
  };

  // Check if a business plan already exists for this idea
  const existingPlan = businessPlans.find((plan: any) => 
    plan.title === idea.title || 
    (plan.aiGeneratedIdeas && plan.aiGeneratedIdeas.some((aiIdea: any) => aiIdea.title === idea.title))
  );

  return (
    <Card className="comic-border overflow-hidden">
      <CardHeader 
        className="bg-gradient-to-r from-teal/10 to-coral/10 cursor-pointer hover:from-teal/15 hover:to-coral/15 transition-colors"
        onClick={onToggle}
      >
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-2xl mb-2 flex items-center gap-2 text-teal">
              <Zap className="w-6 h-6" />
              {idea.title}
              {isExpanded ? <ChevronDown className="w-5 h-5 ml-auto" /> : <ChevronRight className="w-5 h-5 ml-auto" />}
            </CardTitle>
            <p className="text-gray-600 leading-relaxed">
              {idea.description}
            </p>
          </div>
          <Badge 
            className={`ml-4 font-medium border ${
              difficultyColors[idea.difficulty]
            }`}
          >
            {idea.difficulty}
          </Badge>
        </div>
      </CardHeader>

      {isExpanded && (
        <CardContent className="space-y-6 p-6">
          {/* Key Metrics Grid */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-teal/5 rounded-lg p-4 border border-teal/10">
              <div className="flex items-center gap-3 mb-2">
                <Users className="w-5 h-5 text-teal" />
                <h4 className="font-semibold">Target Market</h4>
              </div>
              <p className="text-sm text-gray-600">
                {idea.targetMarket}
              </p>
            </div>

            <div className="bg-green-50 rounded-lg p-4 border border-green-100">
              <div className="flex items-center gap-3 mb-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                <h4 className="font-semibold">Profit Potential</h4>
              </div>
              <p className="text-sm text-gray-600">
                {idea.profitPotential}
              </p>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 border border-blue-100">
              <div className="flex items-center gap-3 mb-2">
                <DollarSign className="w-5 h-5 text-blue-600" />
                <h4 className="font-semibold">Startup Cost</h4>
              </div>
              <p className="text-sm text-gray-600">
                {idea.startupCost}
              </p>
            </div>

            <div className="bg-purple-50 rounded-lg p-4 border border-purple-100">
              <div className="flex items-center gap-3 mb-2">
                <Clock className="w-5 h-5 text-purple-600" />
                <h4 className="font-semibold">Time to Launch</h4>
              </div>
              <p className="text-sm text-gray-600">
                {idea.timeToLaunch}
              </p>
            </div>
          </div>

          {/* Business Plan Button */}
          <div className="flex justify-center pt-4">
            {existingPlan ? (
              <div className="flex gap-3 items-center">
                <Button
                  onClick={() => window.location.href = `/business-plan/${existingPlan.id}`}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-lg px-6 py-3 shadow-md"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  View Business Plan
                </Button>
                <div className="text-sm text-green-600 font-medium">
                  ✅ Plan Created
                </div>
              </div>
            ) : (
              <Button
                onClick={() => onCreatePlan(idea)}
                className="bg-orange-500 hover:bg-orange-600 text-white font-semibold text-lg px-6 py-3 shadow-md"
              >
                <FileText className="w-4 h-4 mr-2" />
                Generate Business Plan
              </Button>
            )}
          </div>

          {/* Dedicated Chatbox for this idea */}
          <div className="mt-6">
            <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-800 mb-2">
                💬 Chat about: {idea.title}
              </h3>
              <p className="text-sm text-blue-600">
                Ask questions about this specific business idea. Your conversation is saved here.
              </p>
            </div>

            <ChatBox
              idea={{
                title: idea.title,
                description: idea.description,
                revenuePotential: idea.profitPotential,
                difficultyLevel: idea.difficulty
              }}
              ideaId={idea.id}
              chatContext="idea-exploration"
              persistedMessages={ideaChatMessages}
              onNewMessage={() => refetchChat()}
            />
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export default function Ideas() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [expandedIdeaId, setExpandedIdeaId] = useState<number | null>(null);
  const [showBusinessPlanDialog, setShowBusinessPlanDialog] = useState(false);
  const [selectedIdeaForPlan, setSelectedIdeaForPlan] = useState<BusinessIdea | null>(null);

  // Get user profile to check if completed
  const { data: profile, isLoading: profileLoading } = useQuery<any>({
    queryKey: ["/api/profile"],
    retry: 1,
  });

  // Check if user has business plans
  const { data: businessPlans = [] } = useQuery<any[]>({
    queryKey: ["/api/business-plans"],
    enabled: !!profile?.isCompleted,
    retry: 1,
  });

  // Get generated business ideas
  const { data: businessIdeas = [], isLoading: ideasLoading, error: ideasError, refetch: refetchBusinessIdeas } = useQuery<BusinessIdea[]>({
    queryKey: ["/api/business-ideas"],
    enabled: !!profile?.isCompleted,
    retry: 1,
  });

  // Generate ideas mutation
  const generateIdeasMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/generate-ideas", {
        method: "POST",
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/business-ideas"] });
      toast({
        title: "Ideas Generated!",
        description: "Your personalized business ideas are ready.",
      });
    },
    onError: (error: any) => {
      if (error.message?.includes('locked business plan')) {
        toast({
          title: "Business Plan Already Complete",
          description: "You already have a locked business plan. Only one business plan per user is allowed.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Generation Failed",
          description: "Failed to generate ideas. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  // Create business plan mutation
  const createBusinessPlanMutation = useMutation({
    mutationFn: async (idea: BusinessIdea) => {
      return await apiRequest("/api/create-business-plan", {
        method: "POST",
        body: JSON.stringify({ ideaId: idea.id }),
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Business Plan Created!",
        description: "Your comprehensive business plan has been generated successfully.",
      });
      setShowBusinessPlanDialog(false);
      setSelectedIdeaForPlan(null);
      // Navigate to business plan page
      window.location.href = `/business-plan/${data.id}`;
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Create Plan",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
      setShowBusinessPlanDialog(false);
      setSelectedIdeaForPlan(null);
    },
  });

  const handleCreateBusinessPlan = (idea: BusinessIdea) => {
    setSelectedIdeaForPlan(idea);
    setShowBusinessPlanDialog(true);
  };

  const confirmCreateBusinessPlan = () => {
    if (selectedIdeaForPlan) {
      createBusinessPlanMutation.mutate(selectedIdeaForPlan);
    }
  };

  const handleToggleIdea = (ideaId: number) => {
    setExpandedIdeaId(expandedIdeaId === ideaId ? null : ideaId);
  };

  if (profileLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!profile?.isCompleted) {
    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto text-center">
          <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">
            {profile ? "Complete Your Profile" : "Create Your Profile First"}
          </h2>
          <p className="text-muted-foreground mb-6">
            {profile
              ? "Your profile is saved but incomplete. Finish all steps to unlock personalized business ideas!"
              : "We need to know about your skills, goals, and preferences to generate personalized business ideas."
            }
          </p>
          <Link href="/profile-setup">
            <Button size="lg">
              {profile ? "Continue Profile Setup" : "Complete Profile"}
            </Button>
          </Link>
          {profile && (
            <p className="text-sm text-green-600 mt-4">
              ✅ Your progress has been saved
            </p>
          )}
        </div>
      </div>
    );
  }

  // Check if user has a locked business plan
  const hasLockedPlan = businessPlans.some((plan: any) => plan.isLocked);

  if (hasLockedPlan) {
    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto text-center">
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Business Plan Complete</h2>
          <p className="text-muted-foreground mb-6">
            You have successfully created and locked your business plan. Focus on execution now!
          </p>
          <div className="flex gap-4 justify-center">
            <Link href="/dashboard">
              <Button size="lg">View Dashboard</Button>
            </Link>
            <Link href={`/business-plan/${businessPlans.find((p: any) => p.isLocked)?.id}`}>
              <Button variant="outline" size="lg">View Business Plan</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Business Ideas</h1>
          <p className="text-muted-foreground">
            AI-generated ideas tailored for your skills and goals. Click on any idea to expand and explore.
          </p>
        </div>

        <div className="w-full space-y-6">
          {ideasError ? (
            <Card>
              <CardContent className="p-8 text-center">
                <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Unable to Load Ideas</h3>
                <p className="text-muted-foreground mb-6">
                  There was an issue loading your business ideas. Please try again.
                </p>
                <Button
                  onClick={() => window.location.reload()}
                  variant="outline"
                >
                  Refresh Page
                </Button>
              </CardContent>
            </Card>
          ) : businessIdeas.length === 0 && !ideasLoading ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Sparkles className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Generate Your First Ideas</h3>
                <p className="text-muted-foreground mb-6">
                  Get personalized business ideas based on your profile, skills, and location.
                </p>
                {!profile?.isCompleted ? (
                  <div className="space-y-4">
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                      <p className="text-amber-800 text-sm font-medium">
                        Complete your profile first to generate personalized ideas
                      </p>
                    </div>
                    <Button
                      asChild
                      size="lg"
                      className="bg-primary hover:bg-primary/90"
                    >
                      <Link href="/profile-setup">
                        Complete Profile First
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={() => generateIdeasMutation.mutate()}
                    disabled={generateIdeasMutation.isPending}
                    size="lg"
                  >
                    {generateIdeasMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating Ideas...
                      </>
                    ) : (
                      <>
                        <Lightbulb className="w-4 h-4 mr-2" />
                        Generate Ideas
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              <div className="space-y-4">
                {businessIdeas.map((idea) => (
                  <IdeaWithChat 
                    key={idea.id} 
                    idea={idea} 
                    onCreatePlan={handleCreateBusinessPlan}
                    isExpanded={expandedIdeaId === idea.id}
                    onToggle={() => handleToggleIdea(idea.id)}
                    businessPlans={businessPlans}
                  />
                ))}
              </div>
            </div>
          )}

          {businessIdeas.length > 0 && (
            <div className="text-center">
              {!profile?.isCompleted ? (
                <div className="space-y-3">
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3 max-w-md mx-auto">
                    <p className="text-amber-800 text-sm font-medium">
                      Complete your profile to generate more personalized ideas
                    </p>
                  </div>
                  <Button variant="outline" asChild>
                    <Link href="/profile-setup">
                      Complete Profile
                    </Link>
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  onClick={() => generateIdeasMutation.mutate()}
                  disabled={generateIdeasMutation.isPending}
                >
                  {generateIdeasMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate More Ideas
                    </>
                  )}
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Business Plan Confirmation Dialog */}
      <Dialog open={showBusinessPlanDialog} onOpenChange={setShowBusinessPlanDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              Generate Business Plan
            </DialogTitle>
            <DialogDescription className="space-y-3 pt-2">
              <p>
                You are about to generate a comprehensive business plan for:
              </p>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="font-semibold text-gray-900">
                  {selectedIdeaForPlan?.title}
                </p>
              </div>
              <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg">
                <p className="text-amber-800 text-sm font-medium">
                  ⚠️ Important: You can only generate ONE business plan during the pilot phase.
                </p>
                <p className="text-amber-700 text-sm mt-1">
                  This will include financial projections, marketing strategies, and execution plans.
                </p>
              </div>
              <p className="text-sm text-gray-600">
                Are you sure you want to proceed with this idea?
              </p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button 
              variant="outline" 
              onClick={() => setShowBusinessPlanDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={confirmCreateBusinessPlan}
              disabled={createBusinessPlanMutation.isPending}
              className="bg-coral hover:bg-coral/80"
            >
              {createBusinessPlanMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Business Plan...
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4 mr-2" />
                  Yes, Create Plan
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
