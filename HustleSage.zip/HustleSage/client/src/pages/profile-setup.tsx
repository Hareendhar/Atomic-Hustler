import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { FloatingElements } from "@/components/floating-elements";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Rocket, ArrowLeft, ArrowRight, User, Heart, Briefcase, DollarSign, Target } from "lucide-react";

const profileSchema = z.object({
  // Demographics
  ageGroup: z.string().min(1, "Please select your age group"),
  age: z.number().min(16, "Age must be at least 16").max(100, "Age must be realistic"),
  gender: z.string().min(1, "Please select your gender"),
  location: z.string().min(1, "Please enter your location"),
  country: z.string().min(1, "Please select your country"),
  city: z.string().min(1, "Please select your city"),
  businessLocation: z.string().min(1, "Please enter where you plan to run your business"),
  locationType: z.string().min(1, "Please select location type"),
  languages: z.array(z.string()).min(1, "Please select at least one language"),
  isWorking: z.boolean(),
  currentProfession: z.string().min(1, "Please select your current profession"),
  availableHours: z.number().min(1, "Please enter available hours").max(168, "Cannot exceed 168 hours per week"),

  // Personality traits
  comfortWithSelling: z.string().min(1, "Please select your comfort level"),
  comfortOnCamera: z.boolean(),
  comfortWithWriting: z.boolean(),
  organizationSkills: z.boolean(),
  workPreference: z.string().min(1, "Please select work preference"),

  // Skills and tools
  topSkills: z.array(z.string()).min(1, "Please select at least one skill"),
  digitalToolsComfort: z.string().min(1, "Please select your comfort level"),
  socialMediaKnowledge: z.boolean(),
  deviceType: z.string().min(1, "Please select device type"),

  // Financial readiness
  investmentCapacity: z.string().min(1, "Please select investment capacity"),
  hasStorageSpace: z.boolean(),
  okWithDeliveries: z.boolean(),

  // Aspirations
  mainReason: z.array(z.string()).min(1, "Please select at least one reason"),
  incomeGoal: z.string().min(1, "Please select income goal"),
  fullTimeGoal: z.string().min(1, "Please select full-time goal"),

  // Optional fields
  healthRestrictions: z.string().optional().default(""),
  supportSystem: z.string().optional().default(""),
  additionalInfo: z.string().optional().default(""),
});

type ProfileFormData = z.infer<typeof profileSchema>;

const COUNTRIES = [
  "India", "United States", "Canada", "United Kingdom", "Australia", "Germany", "France", "Singapore", "UAE", "Other"
];

const INDIAN_CITIES = [
  "Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad", "Jaipur", "Surat",
  "Lucknow", "Kanpur", "Nagpur", "Indore", "Thane", "Bhopal", "Visakhapatnam", "Pimpri-Chinchwad", "Patna", "Vadodara",
  "Ghaziabad", "Ludhiana", "Agra", "Nashik", "Faridabad", "Meerut", "Rajkot", "Kalyan-Dombivali", "Vasai-Virar", "Varanasi",
  "Srinagar", "Aurangabad", "Dhanbad", "Amritsar", "Navi Mumbai", "Allahabad", "Ranchi", "Howrah", "Coimbatore", "Jabalpur",
  "Gwalior", "Vijayawada", "Jodhpur", "Madurai", "Raipur", "Kota", "Guwahati", "Chandigarh", "Solapur", "Hubli-Dharwad", "Other"
];

const PROFESSIONS = [
  "Student", "Software Engineer", "Teacher", "Doctor", "Nurse", "Engineer", "Business Analyst", "Marketing Professional",
  "Sales Executive", "Accountant", "HR Professional", "Designer", "Consultant", "Manager", "Executive", "Entrepreneur",
  "Freelancer", "Government Employee", "Bank Employee", "Lawyer", "Architect", "Pharmacist", "Researcher", "Data Analyst",
  "Content Writer", "Social Media Manager", "Chef", "Driver", "Security Guard", "Shopkeeper", "Farmer", "Homemaker",
  "Retired", "Unemployed", "Other"
];

const STEPS = [
  { id: 1, title: "Demographics & Lifestyle", icon: User, color: "coral", bgClass: "bg-orange-500", textClass: "text-orange-500" },
  { id: 2, title: "Comfort & Personality", icon: Heart, color: "teal", bgClass: "bg-teal-500", textClass: "text-teal-500" },
  { id: 3, title: "Skills & Tools", icon: Briefcase, color: "sky", bgClass: "bg-sky-500", textClass: "text-sky-500" },
  { id: 4, title: "Financial Readiness", icon: DollarSign, color: "mint", bgClass: "bg-emerald-500", textClass: "text-emerald-500" },
  { id: 5, title: "Aspirations & Goals", icon: Target, color: "plum", bgClass: "bg-purple-500", textClass: "text-purple-500" },
];

export default function ProfileSetup() {
  const [currentStep, setCurrentStep] = useState(1);
  const [, setLocation] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  const { data: existingProfile, isLoading: profileLoading } = useQuery<any>({
    queryKey: ["/api/profile"],
    retry: false,
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    mode: "onBlur",
    defaultValues: {
      ageGroup: "",
      age: 25,
      gender: "",
      location: "",
      country: "",
      city: "",
      businessLocation: "",
      locationType: "",
      languages: [],
      isWorking: false,
      currentProfession: "",
      availableHours: 10,
      comfortWithSelling: "",
      comfortOnCamera: false,
      comfortWithWriting: false,
      organizationSkills: false,
      workPreference: "",
      topSkills: [],
      digitalToolsComfort: "",
      socialMediaKnowledge: false,
      deviceType: "",
      investmentCapacity: "",
      hasStorageSpace: false,
      okWithDeliveries: false,
      mainReason: [],
      incomeGoal: "",
      fullTimeGoal: "",
      healthRestrictions: "",
      supportSystem: "",
      additionalInfo: "",
    },
  });

  // Load existing profile data
  useEffect(() => {
    if (existingProfile) {
      const formData = {
        ...existingProfile,
        languages: existingProfile.languages || [],
        topSkills: existingProfile.topSkills || [],
        mainReason: existingProfile.mainReason || [],
      };
      form.reset(formData);
    }
  }, [existingProfile, form]);

  // Auth check
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  const saveProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData & { isCompleted?: boolean }) => {
      console.log("Submitting profile data:", data);
      return await apiRequest("/api/profile", { 
        method: "POST", 
        body: JSON.stringify(data) 
      });
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      if (variables.isCompleted) {
        toast({
          title: "Profile Completed! 🎉",
          description: "Your profile has been completed successfully! Ready to generate business ideas.",
        });
        setLocation("/ideas");
      } else {
        toast({
          title: "Progress Saved ✅",
          description: "Your progress has been saved. You can continue anytime!",
        });
      }
    },
    onError: (error) => {
      console.error("Profile save error:", error);
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const saveAndContinueMutation = useMutation({
    mutationFn: async (data: Partial<ProfileFormData>) => {
      console.log("Saving progress for step:", currentStep, data);
      return await apiRequest("/api/profile", { 
        method: "POST", 
        body: JSON.stringify(data) 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({
        title: "Progress Saved ✅",
        description: "Your progress has been saved successfully!",
      });
    },
    onError: (error) => {
      console.error("Save progress error:", error);
      
      // Extract meaningful error message
      let errorMessage = "Failed to save progress. Please try again.";
      
      if (error instanceof Error) {
        if (error.message.includes("toISOString")) {
          errorMessage = "Data format error. Please refresh the page and try again.";
        } else if (error.message.includes("constraint")) {
          errorMessage = "Please fill in all required fields before saving.";
        } else if (error.message.includes("validation")) {
          errorMessage = "Please check all fields are correctly filled.";
        } else {
          errorMessage = error.message;
        }
      }
      
      toast({
        title: "Save Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const saveAndContinue = async () => {
    try {
      const currentFormData = form.getValues();
      
      // Get current step's required fields for validation
      const stepFields = getStepFields(currentStep);
      
      // Validate only current step's required fields
      const missingFields = stepFields.filter(field => {
        const value = currentFormData[field];
        
        // Handle boolean fields (like isWorking) - they have default values
        if (field === 'isWorking' || field === 'comfortOnCamera' || field === 'comfortWithWriting' || 
            field === 'organizationSkills' || field === 'socialMediaKnowledge' || 
            field === 'hasStorageSpace' || field === 'okWithDeliveries') {
          return false; // Boolean fields are always valid (have defaults)
        }
        
        // Handle array fields (like languages, topSkills, mainReason)
        if (Array.isArray(value)) {
          return value.length === 0;
        }
        
        // Handle string fields that are required
        if (typeof value === 'string') {
          return value.trim() === '';
        }
        
        // Handle number fields - they have defaults so just check if reasonable
        if (typeof value === 'number') {
          return field === 'age' ? (value < 16 || value > 100) : (value <= 0);
        }
        
        // Handle null/undefined - these are missing
        return value === null || value === undefined || value === '';
      });

      // Create user-friendly field names
      const fieldDisplayNames: Record<string, string> = {
        ageGroup: "Age Group",
        age: "Exact Age", 
        gender: "Gender",
        country: "Country",
        city: "City",
        locationType: "Location Type",
        location: "Current Address/Area",
        businessLocation: "Business Location",
        languages: "Languages (select at least one)",
        currentProfession: "Current Profession",
        availableHours: "Available Hours per Week",
        comfortWithSelling: "Comfort with Selling",
        workPreference: "Work Preference",
        topSkills: "Top Skills (select at least one)",
        digitalToolsComfort: "Digital Tools Comfort",
        deviceType: "Device Type",
        investmentCapacity: "Investment Capacity",
        mainReason: "Main Reason (select at least one)",
        incomeGoal: "Income Goal",
        fullTimeGoal: "Full-time Goal"
      };

      if (missingFields.length > 0) {
        const missingFieldNames = missingFields.map(field => fieldDisplayNames[field] || field);
        toast({
          title: "Missing Information",
          description: `Please complete these required fields: ${missingFieldNames.join(", ")}`,
          variant: "destructive",
        });
        return;
      }

      // Prepare clean data for saving - include all form data but mark as incomplete
      const cleanFormData = { ...currentFormData };
      
      // Remove any computed or unwanted fields
      delete cleanFormData.id;
      delete cleanFormData.createdAt;
      delete cleanFormData.updatedAt;
      
      // Ensure arrays are properly handled
      cleanFormData.languages = cleanFormData.languages || [];
      cleanFormData.topSkills = cleanFormData.topSkills || [];
      cleanFormData.mainReason = cleanFormData.mainReason || [];
      
      // Save with isCompleted: false for partial saves
      await saveAndContinueMutation.mutateAsync({ 
        ...cleanFormData, 
        isCompleted: false 
      });
      
      if (currentStep < STEPS.length) {
        setCurrentStep(currentStep + 1);
      }
    } catch (error) {
      console.error("Save and continue error:", error);
    }
  };

  const getStepFields = (step: number): (keyof ProfileFormData)[] => {
    switch (step) {
      case 1:
        return ['ageGroup', 'age', 'gender', 'country', 'city', 'locationType', 'location', 'businessLocation', 'languages', 'isWorking', 'currentProfession', 'availableHours'];
      case 2:
        return ['comfortWithSelling', 'comfortOnCamera', 'comfortWithWriting', 'organizationSkills', 'workPreference'];
      case 3:
        return ['topSkills', 'digitalToolsComfort', 'socialMediaKnowledge', 'deviceType'];
      case 4:
        return ['investmentCapacity', 'hasStorageSpace', 'okWithDeliveries'];
      case 5:
        return ['mainReason', 'incomeGoal', 'fullTimeGoal'];
      default:
        return [];
    }
  };

  const getStepCompletionStatus = (step: number, profile: any): boolean => {
    if (!profile) return false;
    
    const fields = getStepFields(step);
    return fields.every(field => {
      const value = profile[field];
      if (Array.isArray(value)) {
        return value.length > 0;
      }
      return value !== null && value !== undefined && value !== '';
    });
  };

  const nextStep = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const onSubmit = async (data: ProfileFormData) => {
    try {
      console.log("Form submitted with data:", data);

      // Create user-friendly field names
      const fieldDisplayNames: Record<string, string> = {
        ageGroup: "Age Group",
        gender: "Gender",
        location: "Current Address/Area",
        country: "Country",
        city: "City",
        businessLocation: "Business Location",
        locationType: "Location Type",
        currentProfession: "Current Profession",
        comfortWithSelling: "Comfort with Selling",
        workPreference: "Work Preference",
        digitalToolsComfort: "Digital Tools Comfort",
        deviceType: "Device Type",
        investmentCapacity: "Investment Capacity",
        incomeGoal: "Income Goal",
        fullTimeGoal: "Full-time Goal"
      };

      // Validate all required fields are filled
      const requiredFields = {
        ageGroup: data.ageGroup,
        gender: data.gender,
        location: data.location,
        country: data.country,
        city: data.city,
        businessLocation: data.businessLocation,
        locationType: data.locationType,
        currentProfession: data.currentProfession,
        comfortWithSelling: data.comfortWithSelling,
        workPreference: data.workPreference,
        digitalToolsComfort: data.digitalToolsComfort,
        deviceType: data.deviceType,
        investmentCapacity: data.investmentCapacity,
        incomeGoal: data.incomeGoal,
        fullTimeGoal: data.fullTimeGoal,
      };

      const missingStringFields = Object.entries(requiredFields)
        .filter(([key, value]) => !value || (typeof value === 'string' && value.trim() === ''))
        .map(([key]) => fieldDisplayNames[key] || key);

      // Check array fields separately
      const missingArrayFields = [];
      if (!data.languages || data.languages.length === 0) {
        missingArrayFields.push("Languages (select at least one)");
      }
      if (!data.topSkills || data.topSkills.length === 0) {
        missingArrayFields.push("Top Skills (select at least one)");
      }
      if (!data.mainReason || data.mainReason.length === 0) {
        missingArrayFields.push("Main Reason (select at least one)");
      }

      const allMissingFields = [...missingStringFields, ...missingArrayFields];

      if (allMissingFields.length > 0) {
        toast({
          title: "Missing Required Information",
          description: `Please complete these fields: ${allMissingFields.join(", ")}`,
          variant: "destructive",
        });
        return;
      }

      // Clean the data before submitting
      const cleanData = { ...data };
      delete cleanData.id;
      delete cleanData.createdAt;
      delete cleanData.updatedAt;

      saveProfileMutation.mutate({ ...cleanData, isCompleted: true });
    } catch (error) {
      console.error("Form validation error:", error);
      toast({
        title: "Validation Error",
        description: "Please check all fields and try again",
        variant: "destructive",
      });
    }
  };

  const progress = (currentStep / STEPS.length) * 100;

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-coral mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile setup...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen relative overflow-x-hidden">
      <FloatingElements />

      {/* Header */}
      <header className="relative z-10 bg-white/90 backdrop-blur-sm border-b-2 border-sky/20">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-coral to-teal rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-sm">AH</span>
              </div>
              <span className="font-handwritten text-2xl font-bold gradient-text">Atomic Hustler</span>
            </div>
            <Button 
              onClick={() => setLocation("/")}
              variant="outline"
              className="border-coral text-coral hover:bg-coral hover:text-white rounded-full"
            >
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <div className="relative z-10 container mx-auto px-6 py-12">
        {/* Progress Header */}
        <div className="mb-12 text-center">
          <h1 className="font-handwritten text-4xl lg:text-5xl font-bold gradient-text mb-4">
            Create Your Profile ✨
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Help us understand you better so we can recommend the perfect side hustle!
          </p>

          <div className="max-w-2xl mx-auto mb-8">
            <div className="flex justify-between mb-4">
              {STEPS.map((step, index) => {
                const StepIcon = step.icon;
                const isCompleted = existingProfile && getStepCompletionStatus(step.id, existingProfile);
                return (
                  <div key={step.id} className="flex flex-col items-center">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-colors ${
                      isCompleted
                        ? 'bg-green-500 text-white'
                        : currentStep === step.id 
                          ? `${step.bgClass} text-white` 
                          : 'bg-gray-200 text-gray-500'
                    }`}>
                      {isCompleted ? (
                        <span className="text-lg font-bold">✓</span>
                      ) : (
                        <StepIcon className="w-6 h-6" />
                      )}
                    </div>
                    <span className={`text-xs text-center max-w-20 ${
                      isCompleted ? 'text-green-500' :
                      currentStep === step.id ? step.textClass : 'text-gray-500'
                    }`}>
                      {step.title}
                    </span>
                    {isCompleted && (
                      <span className="text-xs text-green-600 mt-1">Saved</span>
                    )}
                  </div>
                );
              })}
            </div>
            <Progress value={progress} className="h-2" />
            <p className="text-sm text-gray-500 mt-2">
              Step {currentStep} of {STEPS.length} ({Math.round(progress)}% complete)
            </p>
            {existingProfile && !existingProfile.isCompleted && (
              <p className="text-sm text-blue-600 mt-1">
                💾 You can save your progress at any step and continue later
              </p>
            )}
          </div>
        </div>

        {/* Form */}
        <div className="max-w-4xl mx-auto">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">

              {/* Step 1: Demographics & Lifestyle */}
              {currentStep === 1 && (
                <Card className="comic-border">
                  <CardHeader>
                    <CardTitle className="font-handwritten text-3xl text-coral">
                      📍 Demographics & Lifestyle
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="ageGroup"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Age Group *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Select age group" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="18-25">18-25 years</SelectItem>
                                <SelectItem value="26-35">26-35 years</SelectItem>
                                <SelectItem value="36-50">36-50 years</SelectItem>
                                <SelectItem value="50+">50+ years</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="age"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Exact Age</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="16" 
                                max="100" 
                                placeholder="e.g. 28" 
                                className="rounded-full"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Gender *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Select gender" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Male">Male</SelectItem>
                                <SelectItem value="Female">Female</SelectItem>
                                <SelectItem value="Non-binary">Non-binary</SelectItem>
                                <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid md:grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Country *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Select country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {COUNTRIES.map((country) => (
                                  <SelectItem key={country} value={country}>{country}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">City *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Select city" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {INDIAN_CITIES.map((city) => (
                                  <SelectItem key={city} value={city}>{city}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="locationType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Location Type *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Select location type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Urban">Urban (Metro cities)</SelectItem>
                                <SelectItem value="Tier 2">Tier 2 (Medium cities)</SelectItem>
                                <SelectItem value="Rural">Rural (Villages/Small towns)</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Current Address/Area *</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Andheri West, Sector 14, Main Street" className="rounded-full" {...field} />
                            </FormControl>
                            <FormDescription>Specific area or neighborhood</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="businessLocation"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Business Location *</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. From home, Local market, Online" className="rounded-full" {...field} />
                            </FormControl>
                            <FormDescription>Where will you run your business?</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="languages"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">What languages can you speak or write in comfortably? *</FormLabel>
                          <FormDescription>Select all that apply</FormDescription>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {["Hindi", "English", "Tamil", "Telugu", "Bengali", "Marathi", "Gujarati", "Kannada", "Malayalam", "Punjabi", "Urdu", "Other"].map((language) => (
                              <div key={language} className="flex items-center space-x-2">
                                <Checkbox
                                  checked={field.value?.includes(language)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      field.onChange([...field.value, language]);
                                    } else {
                                      field.onChange(field.value?.filter((l) => l !== language));
                                    }
                                  }}
                                />
                                <label className="text-sm font-medium">{language}</label>
                              </div>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="isWorking"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Are you currently working or a full-time student? *</FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={(value) => field.onChange(value === "true")}
                                value={field.value !== undefined ? (field.value ? "true" : "false") : undefined}
                                className="flex space-x-6"
                              >
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="true" id="working-yes" />
                                  <label htmlFor="working-yes">Yes</label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="false" id="working-no" />
                                  <label htmlFor="working-no">No</label>
                                </div>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="currentProfession"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-lg font-semibold">Current Profession *</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Select your profession" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {PROFESSIONS.map((profession) => (
                                  <SelectItem key={profession} value={profession}>{profession}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="availableHours"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">How many hours per week can you give to a side hustle?</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1" 
                              max="168" 
                              placeholder="e.g. 10" 
                              className="rounded-full w-32"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormDescription>Consider your current commitments</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Step 2: Comfort & Personality */}
              {currentStep === 2 && (
                <Card className="comic-border">
                  <CardHeader>
                    <CardTitle className="font-handwritten text-3xl text-teal">
                      💫 Comfort & Personality Traits
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="comfortWithSelling"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you comfortable speaking to strangers or selling to people? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Yes" id="selling-yes" />
                                <label htmlFor="selling-yes">Yes, I love talking to people!</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Somewhat" id="selling-somewhat" />
                                <label htmlFor="selling-somewhat">Somewhat, I can manage</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="No" id="selling-no" />
                                <label htmlFor="selling-no">No, I prefer to avoid it</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="comfortOnCamera"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you comfortable appearing on camera (e.g., YouTube)?</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => field.onChange(value === "true")}
                              defaultValue={field.value ? "true" : "false"}
                              className="flex space-x-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="true" id="camera-yes" />
                                <label htmlFor="camera-yes">Yes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="false" id="camera-no" />
                                <label htmlFor="camera-no">No</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="comfortWithWriting"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you comfortable writing content or blog posts?</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => field.onChange(value === "true")}
                              defaultValue={field.value ? "true" : "false"}
                              className="flex space-x-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="true" id="writing-yes" />
                                <label htmlFor="writing-yes">Yes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="false" id="writing-no" />
                                <label htmlFor="writing-no">No</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="organizationSkills"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you good at managing or organizing things?</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => field.onChange(value === "true")}
                              defaultValue={field.value ? "true" : "false"}
                              className="flex space-x-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="true" id="org-yes" />
                                <label htmlFor="org-yes">Yes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="false" id="org-no" />
                                <label htmlFor="org-no">No</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="workPreference"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Do you prefer working alone or in collaboration? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Alone" id="work-alone" />
                                <label htmlFor="work-alone">Alone - I work best independently</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="With others" id="work-others" />
                                <label htmlFor="work-others">With others - I love teamwork</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="No preference" id="work-no-pref" />
                                <label htmlFor="work-no-pref">No preference - I'm flexible</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Step 3: Skills & Tools */}
              {currentStep === 3 && (
                <Card className="comic-border">
                  <CardHeader>
                    <CardTitle className="font-handwritten text-3xl text-sky">
                      🛠️ Skills & Tools
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="topSkills"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Select your top 3 skills *</FormLabel>
                          <FormDescription>Choose the skills you're most confident in</FormDescription>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                            {["Cooking", "Design", "Teaching", "Sales", "Finance", "Organizing", "Gardening", "Sewing", "Writing", "Photography", "Music", "Programming", "Crafts", "Fitness", "Other"].map((skill) => (
                              <div key={skill} className="flex items-center space-x-2">
                                <Checkbox
                                  checked={field.value?.includes(skill)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      if (field.value.length < 3) {
                                        field.onChange([...field.value, skill]);
                                      }
                                    } else {
                                      field.onChange(field.value?.filter((s) => s !== skill));
                                    }
                                  }}
                                  disabled={!field.value?.includes(skill) && field.value?.length >= 3}
                                />
                                <label className="text-sm font-medium">{skill}</label>
                              </div>
                            ))}
                          </div>
                          <p className="text-sm text-gray-500">
                            Selected: {field.value?.length || 0}/3
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="digitalToolsComfort"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you comfortable using digital tools like WhatsApp Business, Canva, or Google Docs? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Yes" id="tools-yes" />
                                <label htmlFor="tools-yes">Yes, I'm comfortable with digital tools</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Learning" id="tools-learning" />
                                <label htmlFor="tools-learning">I'm learning, willing to explore</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="No" id="tools-no" />
                                <label htmlFor="tools-no">No, I prefer simple methods</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="socialMediaKnowledge"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Do you know how to use social media for promoting something?</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => field.onChange(value === "true")}
                              defaultValue={field.value ? "true" : "false"}
                              className="flex space-x-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="true" id="social-yes" />
                                <label htmlFor="social-yes">Yes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="false" id="social-no" />
                                <label htmlFor="social-no">No</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="deviceType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Do you have a laptop or only a smartphone? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Laptop + Phone" id="device-both" />
                                <label htmlFor="device-both">Laptop + Phone</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Only Smartphone" id="device-phone" />
                                <label htmlFor="device-phone">Only Smartphone</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Step 4: Financial Readiness */}
              {currentStep === 4 && (
                <Card className="comic-border">
                  <CardHeader>
                    <CardTitle className="font-handwritten text-3xl text-mint">
                      💰 Financial Readiness
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="investmentCapacity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">How much money can you invest upfront (if needed)? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹0" id="invest-0" />
                                <label htmlFor="invest-0">₹0 - I need zero investment ideas</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹1-5K" id="invest-1-5k" />
                                <label htmlFor="invest-1-5k">₹1,000 - ₹5,000</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹5-10K" id="invest-5-10k" />
                                <label htmlFor="invest-5-10k">₹5,000 - ₹10,000</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹10-25K" id="invest-10-25k" />
                                <label htmlFor="invest-10-25k">₹10,000 - ₹25,000</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹25K+" id="invest-25k+" />
                                <label htmlFor="invest-25k+">₹25,000+</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="hasStorageSpace"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Do you have a place to store or sell physical products?</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => field.onChange(value === "true")}
                              defaultValue={field.value ? "true" : "false"}
                              className="flex space-x-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="true" id="storage-yes" />
                                <label htmlFor="storage-yes">Yes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="false" id="storage-no" />
                                <label htmlFor="storage-no">No</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="okWithDeliveries"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you okay doing deliveries or logistics?</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={(value) => field.onChange(value === "true")}
                              defaultValue={field.value ? "true" : "false"}
                              className="flex space-x-6"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="true" id="delivery-yes" />
                                <label htmlFor="delivery-yes">Yes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="false" id="delivery-no" />
                                <label htmlFor="delivery-no">No</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Step 5: Aspirations & Goals */}
              {currentStep === 5 && (
                <Card className="comic-border">
                  <CardHeader>
                    <CardTitle className="font-handwritten text-3xl text-plum">
                      🎯 Aspirations & Motivation
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <FormField
                      control={form.control}
                      name="mainReason"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">What's your main reason for starting a side hustle? *</FormLabel>
                          <FormDescription>Select all that apply</FormDescription>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {["Need extra income", "Passion project", "Boredom/free time", "Long-term business goal", "Financial independence", "Skill development"].map((reason) => (
                              <div key={reason} className="flex items-center space-x-2">
                                <Checkbox
                                  checked={field.value?.includes(reason)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      field.onChange([...field.value, reason]);
                                    } else {
                                      field.onChange(field.value?.filter((r) => r !== reason));
                                    }
                                  }}
                                />
                                <label className="text-sm font-medium">{reason}</label>
                              </div>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="incomeGoal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">What's your income goal in 3-6 months? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹1K-5K" id="goal-1-5k" />
                                <label htmlFor="goal-1-5k">₹1,000 - ₹5,000 per month</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹5K-20K" id="goal-5-20k" />
                                <label htmlFor="goal-5-20k">₹5,000 - ₹20,000 per month</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹20K-50K" id="goal-20-50k" />
                                <label htmlFor="goal-20-50k">₹20,000 - ₹50,000 per month</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="₹50K+" id="goal-50k+" />
                                <label htmlFor="goal-50k+">₹50,000+ per month</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fullTimeGoal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-lg font-semibold">Are you looking to make this full-time eventually? *</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Yes" id="fulltime-yes" />
                                <label htmlFor="fulltime-yes">Yes, I want to build a full-time business</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="Maybe" id="fulltime-maybe" />
                                <label htmlFor="fulltime-maybe">Maybe, let's see how it goes</label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="No" id="fulltime-no" />
                                <label htmlFor="fulltime-no">No, just extra income is fine</label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Optional Fields */}
                    <div className="border-t pt-6">
                      <h3 className="font-handwritten text-xl text-gray-700 mb-4">Optional Information</h3>

                      <FormField
                        control={form.control}
                        name="healthRestrictions"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Do you have any health restrictions that may impact your work?</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Optional - any health considerations we should know about" className="rounded-xl" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="supportSystem"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Who will support you in this journey?</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="rounded-full">
                                  <SelectValue placeholder="Optional - select your support system" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Self">Self - I'm doing this alone</SelectItem>
                                <SelectItem value="Spouse">Spouse/Partner</SelectItem>
                                <SelectItem value="Children">Children</SelectItem>
                                <SelectItem value="Community">Community/Friends</SelectItem>
                                <SelectItem value="None">None</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="additionalInfo"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Anything else you'd like us to know about you?</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Optional - share anything that might help us recommend better ideas" className="rounded-xl" {...field} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Navigation */}
              <div className="flex justify-between items-center pt-8">
                <Button
                  type="button"
                  onClick={prevStep}
                  disabled={currentStep === 1}
                  variant="outline"
                  className="border-coral text-coral hover:bg-coral hover:text-white rounded-full px-6"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>

                <div className="text-center">
                  <p className="text-sm text-gray-500">
                    Step {currentStep} of {STEPS.length}
                  </p>
                  {existingProfile && !existingProfile.isCompleted && (
                    <p className="text-xs text-green-600 mt-1">
                      ✅ Progress saved
                    </p>
                  )}
                </div>

                <div className="flex gap-2">
                  {currentStep < STEPS.length ? (
                    <>
                      <Button
                        type="button"
                        onClick={saveAndContinue}
                        disabled={saveAndContinueMutation.isPending}
                        variant="outline"
                        className="border-teal text-teal hover:bg-teal hover:text-white rounded-full px-4"
                      >
                        {saveAndContinueMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-teal mr-2"></div>
                            Saving...
                          </>
                        ) : (
                          "Save & Continue"
                        )}
                      </Button>
                      <Button
                        type="button"
                        onClick={nextStep}
                        className="bg-gradient-to-r from-coral to-teal text-white rounded-full px-6"
                      >
                        Next
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </>
                  ) : (
                    <Button
                      type="submit"
                      disabled={saveProfileMutation.isPending}
                      className="bg-gradient-to-r from-coral via-teal to-sky text-white rounded-full px-8"
                    >
                      {saveProfileMutation.isPending ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Completing...
                        </>
                      ) : (
                        <>
                          Complete Profile & Generate Ideas ✨
                          <Rocket className="w-4 h-4 ml-2" />
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}