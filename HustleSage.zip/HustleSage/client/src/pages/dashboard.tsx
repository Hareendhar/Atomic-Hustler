import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { type BusinessPlan, type FinancialPlan, type MarketingPlan } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Plus, 
  FileText, 
  Eye, 
  TrendingUp, 
  CheckCircle, 
  Megaphone, 
  IndianRupee,
  Calendar,
  RefreshCw,
  Users,
  MapPin,
  Clock,
  DollarSign,
  Lightbulb
} from "lucide-react";

// Business Plan Card Component
function BusinessPlanCard({ plan, setLocation }: { plan: any, setLocation: any }) {
  const { toast } = useToast();

  // Query to check if financial plan exists
  const { data: financialPlan, isLoading: financialLoading } = useQuery<FinancialPlan>({
    queryKey: ["/api/business-plans", plan.id, "financial-plan"],
    retry: 1,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Query to check if marketing plan exists
  const { data: marketingPlan, isLoading: marketingLoading } = useQuery<MarketingPlan>({
    queryKey: ["/api/business-plans", plan.id, "marketing-plan"],
    retry: 1,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Generate financial plan mutation
  const generateFinancialPlanMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/business-plans/${plan.id}/generate-financial-plan`, {
        method: "POST",
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({
          queryKey: ["/api/business-plans", plan.id, "financial-plan"],
        });
      queryClient.setQueryData(["/api/business-plans", plan.id, "financial-plan"], data);
      toast({
        title: "Success! 💰",
        description: "Financial plan generated successfully!",
      });
      // Navigate to financial plan page
      setLocation(`/financial-plan/${plan.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate financial plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Generate marketing plan mutation
  const generateMarketingPlanMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/business-plans/${plan.id}/generate-marketing-plan`, {
        method: "POST",
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({
          queryKey: [`/api/business-plans/${plan.id}/marketing-plan`],
        });
      queryClient.setQueryData([`/api/business-plans/${plan.id}/marketing-plan`], data);
      toast({
        title: "Success! 📢",
        description: "Marketing plan generated successfully!",
      });
      // Navigate to marketing plan page
      setLocation(`/marketing-plan/${plan.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate marketing plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateFinancialPlan = () => {
    generateFinancialPlanMutation.mutate();
  };

  const handleViewFinancialPlan = () => {
    setLocation(`/financial-plan/${plan.id}`);
  };

  const handleCreateMarketingPlan = () => {
    generateMarketingPlanMutation.mutate();
  };

  const handleViewMarketingPlan = () => {
    setLocation(`/marketing-plan/${plan.id}`)
  };

  const handleViewSalesNotebook = () => {
    setLocation(`/sales-notebook/${plan.id}`);
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      draft: { label: "DRAFT", className: "bg-amber-100 text-amber-800 border-amber-300" },
      completed: { label: "COMPLETED", className: "bg-green-100 text-green-800 border-green-300" },
      locked: { label: "LOCKED", className: "bg-gray-100 text-gray-800 border-gray-300" },
    };

    const config = statusMap[status as keyof typeof statusMap] || statusMap.draft;

    return (
      <span className={`px-2 py-1 text-xs font-medium border rounded-md ${config.className}`}>
        {config.label}
      </span>
    );
  };

  return (
    <Card className="border-2 border-gray-200 hover:border-primary/20 transition-colors">
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-foreground mb-2">{plan.title}</h3>
            {getStatusBadge(plan.status)}
          </div>
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
            {plan.daysPlanned} Days
          </Badge>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-6 line-clamp-2">
          {plan.businessSummary || "Complete business plan with execution calendar and strategic guidance."}
        </p>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Link href={`/business-plan/${plan.id}`}>
            <Button variant="default" size="sm" className="w-full">
              <FileText className="w-4 h-4 mr-2" />
              View Plan
            </Button>
          </Link>
          <Link href={`/calendar/${plan.id}`}>
            <Button variant="outline" size="sm" className="w-full">
              <Calendar className="w-4 h-4 mr-2" />
              Calendar
            </Button>
          </Link>
        </div>

        {/* Financial Analysis Section */}
        <div className="border-t pt-4">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="font-medium text-sm">Financial Analysis</span>
          </div>

          {financialLoading ? (
            <div className="flex items-center justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : financialPlan ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <div className="text-sm">
                  <div className="font-medium text-green-800">Plan Ready</div>
                  <div className="text-green-600">Financial analysis completed</div>
                </div>
              </div>
              <Button 
                onClick={handleViewFinancialPlan}
                size="sm"
                className="w-full bg-[#b45309] hover:bg-[#92400e] text-white"
              >
                <Eye className="w-4 h-4 mr-2" />
                View Financial Plan
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <Plus className="w-4 h-4 text-amber-600" />
                <div className="text-sm">
                  <div className="font-medium text-amber-800">Analysis Needed</div>
                  <div className="text-amber-600">Generate financial roadmap</div>
                </div>
              </div>
              <Button 
                onClick={handleCreateFinancialPlan}
                disabled={generateFinancialPlanMutation.isPending}
                size="sm"
                className="w-full"
                variant="outline"
              >
                {generateFinancialPlanMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2"></div>
                    Generating...
                  </>
                ) : (
                  <>
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Create Financial Plan
                  </>
                )}
              </Button>
            </div>
          )}
        </div>

        {/* Marketing Strategy Section */}
        <div className="border-t pt-4 mt-4">
          <div className="flex items-center gap-2 mb-3">
            <Megaphone className="w-4 h-4 text-primary" />
            <span className="font-medium text-sm">Marketing Strategy</span>
          </div>

          {marketingLoading ? (
            <div className="flex items-center justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : marketingPlan ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <div className="text-sm">
                  <div className="font-medium text-green-800">Strategy Ready</div>
                  <div className="text-green-600">Marketing plan completed</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button 
                  onClick={handleViewMarketingPlan}
                  size="sm"
                  className="bg-[#78350f] hover:bg-[#92400e] text-white"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  View Plan
                </Button>
                <Button 
                  onClick={handleViewSalesNotebook}
                  size="sm"
                  className="bg-primary hover:bg-primary/90 text-white"
                >
                  <Users className="w-4 h-4 mr-1" />
                  Sales Notebook
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <Plus className="w-4 h-4 text-amber-600" />
                <div className="text-sm">
                  <div className="font-medium text-amber-800">Strategy Needed</div>
                  <div className="text-amber-600">Generate marketing roadmap</div>
                </div>
              </div>
              <Button 
                onClick={handleCreateMarketingPlan}
                disabled={generateMarketingPlanMutation.isPending}
                size="sm"
                className="w-full"
                variant="outline"
              >
                {generateMarketingPlanMutation.isPending ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2"></div>
                    Generating...
                  </>
                ) : (
                  <>
                    <Megaphone className="w-4 h-4 mr-2" />
                    Create Marketing Plan
                  </>
                )}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Define the UserProfile type
type UserProfile = {
  isCompleted: boolean;
  ageGroup?: string;
  gender?: string;
  location?: string;
  country?: string;
  city?: string;
  businessLocation?: string;
  locationType?: string;
  languages?: string[];
  isWorking?: boolean;
  currentProfession?: string;
  availableHours?: number;
  comfortWithSelling?: string;
  comfortOnCamera?: string;
  comfortWithWriting?: string;
  organizationSkills?: string;
  workPreference?: string;
  topSkills?: string[];
  digitalToolsComfort?: string;
  socialMediaKnowledge?: string;
  deviceType?: string;
  investmentCapacity?: string;
  hasStorageSpace?: boolean;
  okWithDeliveries?: boolean;
  mainReason?: string;
  incomeGoal?: number;
  fullTimeGoal?: boolean;
};

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
    retry: false,
  });

  const { data: businessPlans = [], isLoading: plansLoading } = useQuery({
    queryKey: ["/api/business-plans"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !user) {
      console.log("User not authenticated, redirecting to login");
      window.location.href = "/api/login";
      return;
    }
  }, [user, isLoading]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // Calculate profile completion percentage
  const calculateProfileCompletion = (profile: UserProfile | undefined): number => {
    if (!profile) return 0;

    // Check if profile is marked as completed first
    if (profile.isCompleted) return 100;

    const requiredFields = [
      'ageGroup', 'gender', 'location', 'country', 'city', 'businessLocation',
      'locationType', 'languages', 'isWorking', 'currentProfession',
      'availableHours', 'comfortWithSelling', 'comfortOnCamera', 
      'comfortWithWriting', 'organizationSkills', 'workPreference', 
      'topSkills', 'digitalToolsComfort', 'socialMediaKnowledge', 
      'deviceType', 'investmentCapacity', 'hasStorageSpace', 
      'okWithDeliveries', 'mainReason', 'incomeGoal', 'fullTimeGoal'
    ];

    let filledFields = 0;
    requiredFields.forEach(field => {
      const value = profile[field as keyof UserProfile];
      if (value !== null && value !== undefined && value !== '' && 
          (Array.isArray(value) ? value.length > 0 : true)) {
        filledFields++;
      }
    });

    return Math.round((filledFields / requiredFields.length) * 100);
  };

  if (isLoading || profileLoading || plansLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-amber-600 rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xs">AH</span>
              </div>
              <span className="text-xl font-semibold text-foreground">Atomic Hustler</span>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                {user?.profileImageUrl && (
                  <img 
                    src={user.profileImageUrl} 
                    alt="Profile" 
                    className="w-8 h-8 rounded-full border-2 border-border object-cover"
                  />
                )}
                <span className="font-medium text-foreground">
                  Hi, {user?.firstName || user?.email?.split('@')[0] || 'there'}!
                </span>
              </div>
              <Button variant="outline" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Your Side Hustle Dashboard
          </h1>
          <p className="text-xl text-muted-foreground">
            Manage your profile and business plans all in one place
          </p>
        </div>

        {/* Quick Stats */}
        {profile?.isCompleted && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary mb-1">{Array.isArray(businessPlans) ? businessPlans.length : 0}</div>
                <div className="text-sm text-muted-foreground">Business Plans</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary mb-1">{profile?.availableHours || 0}</div>
                <div className="text-sm text-muted-foreground">Hours/Week</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary mb-1">{profile?.incomeGoal || 'Not set'}</div>
                <div className="text-sm text-muted-foreground">Income Goal</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary mb-1">{profile?.location || 'Not set'}</div>
                <div className="text-sm text-muted-foreground">Location</div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Profile Section - Compact Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="w-5 h-5 text-primary" />
                  Your Profile
                </CardTitle>
              </CardHeader>
              <CardContent>
                {profile?.isCompleted ? (
                  <div className="space-y-4">
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="text-sm font-medium text-green-800 mb-1">Profile Complete</div>
                      <div className="text-xs text-green-600">Ready to create business plans</div>
                    </div>

                    <div className="space-y-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span>{profile?.ageGroup || 'Not set'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>{profile?.location || 'Not set'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span>{profile?.availableHours || 0} hrs/week</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-muted-foreground" />
                        <span>{profile?.investmentCapacity || 'Not set'}</span>
                      </div>
                    </div>

                    <Link href="/profile-setup">
                      <Button variant="outline" size="sm" className="w-full">
                        Update Profile
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                      <div className="text-sm font-medium text-amber-800 mb-1">Profile Incomplete</div>
                      <div className="text-xs text-amber-600">Complete to get personalized recommendations</div>
                    </div>

                    <p className="text-sm text-muted-foreground">
                      Tell us about your skills, goals, and constraints for perfect side hustle matches.
                    </p>

                    <Link href="/profile-setup">
                      <Button size="sm" className="w-full">
                        Complete Profile
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Business Plans Section - Main Content */}
          <div className="lg:col-span-3">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-semibold text-foreground">My Business Plans</h2>
                <p className="text-muted-foreground">Your journey to financial independence</p>
              </div>
              {profile?.isCompleted && businessPlans.length === 0 && (
                <Button onClick={() => setLocation('/ideas')}>
                  <Plus className="w-4 h-4 mr-2" />
                  Generate Ideas First
                </Button>
              )}
            </div>

            {!profile?.isCompleted ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-muted rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Users className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Complete Your Profile First</h3>
                  <p className="text-muted-foreground mb-4">
                    You need to complete your profile before creating business plans.
                  </p>
                  <Link href="/profile-setup">
                    <Button>Complete Profile</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : businessPlans.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-muted rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Plus className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">No Business Plans Yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Generate business ideas first to create your perfect side hustle plan!
                  </p>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                    <p className="text-amber-800 text-sm font-medium">
                      You need business ideas before creating a plan
                    </p>
                  </div>
                  <Button onClick={() => setLocation('/ideas')}>
                    <Lightbulb className="w-4 h-4 mr-2" />
                    Generate Ideas First
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6">
                {businessPlans.map((plan: any) => (
                  <BusinessPlanCard key={plan.id} plan={plan} setLocation={setLocation} />
                ))}

                {businessPlans.length > 0 && (
                  <div className="text-center py-4">
                    {businessPlans.some((plan: any) => plan.isLocked) ? (
                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center justify-center gap-2 mb-2">
                          <CheckCircle className="w-5 h-5 text-green-600" />
                          <span className="font-medium text-green-800">Business Plan Locked</span>
                        </div>
                        <p className="text-sm text-green-600">
                          Your business plan is complete and ready for execution. Focus on implementing your strategy!
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">
                        Complete and lock your business plan to finalize your side hustle strategy
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}