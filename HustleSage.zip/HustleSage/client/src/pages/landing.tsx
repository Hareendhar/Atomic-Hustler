import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Landing() {
  const [waitlistData, setWaitlistData] = useState({ name: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  // Commented out for waitlist phase - will re-enable for full launch
  // const handleGoogleLogin = () => {
  //   window.location.href = "/api/login";
  // };

  const scrollToFAQ = () => {
    document.getElementById('faq-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToWaitlist = () => {
    document.getElementById('waitlist-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleWaitlistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!waitlistData.name || !waitlistData.email) {
      setSubmitMessage('Please fill in both name and email');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/waitlist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(waitlistData),
      });

      if (response.ok) {
        setSubmitMessage('🎉 Thank you for joining our waitlist! We\'ll notify you as soon as we launch.');
        setWaitlistData({ name: '', email: '' });
      } else {
        setSubmitMessage('Something went wrong. Please try again.');
      }
    } catch (error) {
      setSubmitMessage('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-background min-h-screen">
      {/* Header */}
      <header className="amber-nav sticky top-0 z-50">
        <div className="amber-container py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-amber-600 border flex items-center justify-center rounded-full">
                <span className="text-primary-foreground font-bold text-xs">AH</span>
              </div>
              <span className="text-xl font-semibold text-foreground ml-2">ATOMIC HUSTLER</span>
            </div>
            {/* Show login button only in development */}
            {import.meta.env.DEV && (
              <Button onClick={() => window.location.href = "/api/login"} className="bg-green-600 text-white hover:bg-green-700 mr-4">
                LOGIN (DEV ONLY)
              </Button>
            )}
            <Button onClick={scrollToWaitlist} className="bg-primary text-primary-foreground hover:bg-amber-600">
              JOIN WAITLIST
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="amber-container">
          <div className="grid lg:grid-cols-[70%_30%] gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-block px-4 py-2 rounded-full text-xs font-semibold bg-secondary text-secondary-foreground">
                PERFECT FOR INDIANS OF ALL AGES
              </div>

              <h1 className="text-6xl lg:text-8xl font-bold leading-tight uppercase text-foreground">
                DISCOVER YOUR<br/>
                PERFECT<br/>
                <span className="text-primary">SIDE HUSTLE</span>
              </h1>

              <p className="text-xl leading-relaxed max-w-lg text-muted-foreground">
                Stop guessing what business to start! Our AI analyzes your skills, time, and budget to create a 
                <strong> personalized roadmap</strong> that will help you get your first ₹1,000 in side income within 30 days.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                {/* Show login button only in development */}
                {import.meta.env.DEV && (
                  <Button
                    onClick={() => window.location.href = "/api/login"}
                    className="bg-green-600 text-white px-8 py-4 text-lg font-semibold uppercase hover:bg-green-700 shadow-sm"
                  >
                    LOGIN (DEV ONLY)
                  </Button>
                )}
                <Button
                  onClick={scrollToWaitlist}
                  className="bg-primary text-primary-foreground px-8 py-4 text-lg font-semibold uppercase hover:bg-amber-600 shadow-sm"
                >
                  GET EARLY ACCESS
                </Button>
                <Button 
                  onClick={scrollToFAQ}
                  className="px-8 py-4 text-lg font-semibold bg-secondary text-secondary-foreground hover:bg-amber-200 hover:text-amber-800"
                >
                  LEARN MORE
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="amber-card text-center p-4">
                  <div className="font-bold text-foreground">₹1000+</div>
                  <div className="text-muted-foreground">IN 30 DAYS</div>
                </div>
                <div className="amber-card text-center p-4">
                  <div className="font-bold text-foreground">5 MIN</div>
                  <div className="text-muted-foreground">AI ANALYSIS</div>
                </div>
                <div className="amber-card text-center p-4">
                  <div className="font-bold text-foreground">NO RISK</div>
                  <div className="text-muted-foreground">GUARANTEED</div>
                </div>
              </div>
            </div>

            <div className="amber-card text-center p-12 bg-secondary/20">
              <div className="text-4xl mb-4 text-primary">💰</div>
              <div className="text-2xl font-bold mb-2 text-foreground">LAUNCHING SOON!</div>
              <div className="text-muted-foreground">Join 500+ Indians already on our waitlist</div>
              <Button 
                onClick={scrollToWaitlist}
                className="mt-4 bg-primary text-primary-foreground hover:bg-amber-600"
              >
                SECURE YOUR SPOT
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Who It's For Section */}
      <section className="py-20 bg-muted">
        <div className="amber-container">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold uppercase mb-4 text-foreground">
              PROVEN SUCCESS FOR EVERY INDIAN
            </h2>
            <p className="text-xl max-w-3xl mx-auto text-muted-foreground">
              Our AI has already helped 1000+ Indians discover profitable side hustles. No matter your age, skills, or budget - 
              we guarantee the perfect opportunity for YOU!
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "COLLEGE STUDENTS",
                description: "Earn pocket money while studying! Perfect for content creation, tutoring, or selling crafts.",
                potential: "₹5K-15K/MONTH",
                color: "red",
              },
              {
                title: "WORKING PROFESSIONALS", 
                description: "Leverage your skills for freelancing, consulting, or weekend businesses!",
                potential: "₹20K-50K/MONTH",
                color: "blue",
              },
              {
                title: "HOMEMAKERS",
                description: "Turn your cooking, crafting, or organizing skills into income from home!",
                potential: "₹10K-30K/MONTH", 
                color: "yellow",
              },
              {
                title: "RETIREES",
                description: "Share your wisdom through teaching, consulting, or passion projects!",
                potential: "₹8K-25K/MONTH",
                color: "gray",
              }
            ].map((category, index) => (
              <Card key={index} className="amber-card hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4 text-foreground">{category.title}</h3>
                  <p className="mb-4 text-muted-foreground">{category.description}</p>
                  <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-secondary text-secondary-foreground">
                    {category.potential}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="amber-container">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold uppercase mb-4 text-foreground">
              FROM IDEA TO FIRST ₹1 IN 4 STEPS
            </h2>
            <p className="text-xl max-w-3xl mx-auto text-muted-foreground">
              Our AI analyzes your unique situation and creates a personalized roadmap to success!
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {[
              {
                step: 1,
                title: "CREATE PROFILE",
                description: "Tell us about your skills, available time, budget, and goals. Takes just 5 minutes!",
                badge: "ONE-TIME SETUP",
                color: "red"
              },
              {
                step: 2,
                title: "GET AI MATCHES", 
                description: "Our AI suggests 3 perfect side hustle ideas tailored specifically for your unique situation.",
                badge: "100% PERSONALIZED",
                color: "yellow"
              },
              {
                step: 3,
                title: "BUILD YOUR PLAN", 
                description: "Get a comprehensive 19-point business plan with market analysis, costs, and success strategies.",
                badge: "COMPLETE BLUEPRINT",
                color: "blue"
              },
              {
                step: 4,
                title: "EXECUTE & EARN",
                description: "Follow your day-by-day calendar with tasks, resources, and guidance until you earn your first ₹1!",
                badge: "STEP-BY-STEP GUIDE",
                color: "gray"
              }
            ].map((step, index) => (
              <div key={index} className="relative">
                <div className="amber-card text-center hover:shadow-md transition-shadow">
                  <div className="w-16 h-16 bg-black text-white flex items-center justify-center mx-auto mb-6 text-2xl font-bold rounded-full">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-semibold mb-4 text-foreground">{step.title}</h3>
                  <p className="mb-6 text-muted-foreground">{step.description}</p>
                  <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-secondary text-secondary-foreground">
                    {step.badge}
                  </div>
                </div>
                {index < 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <div className="text-3xl font-bold text-muted-foreground">→</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features That Set Us Apart */}
      <section className="py-20">
        <div className="amber-container">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold uppercase mb-4 text-foreground">
              WHY ATOMIC HUSTLER WORKS
            </h2>
            <p className="text-xl max-w-3xl mx-auto text-muted-foreground">
              Unlike generic business advice, we create personalized plans for real Indians with real constraints!
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              {[
                {
                  icon: "🎯",
                  title: "HYPER-PERSONALIZED AI",
                  description: "Our AI considers your age, location, skills, available time, and budget to suggest only relevant opportunities."
                },
                {
                  icon: "💰",
                  title: "LOW-INVESTMENT FOCUS",
                  description: "All our suggestions require minimal upfront investment - most under ₹5,000 to start!"
                },
                {
                  icon: "📱",
                  title: "MOBILE-FIRST APPROACH",
                  description: "Everything designed for smartphone users - because we know that's how India works!"
                },
                {
                  icon: "🇮🇳",
                  title: "INDIA-SPECIFIC SOLUTIONS",
                  description: "Market insights, customer behavior, and strategies tailored specifically for Indian markets."
                }
              ].map((feature, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-16 h-16 bg-secondary/10 border rounded-full flex items-center justify-center text-2xl text-primary">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2 text-foreground">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="amber-card text-center p-12 bg-secondary/20">
              <div className="text-6xl mb-6 text-primary">⚡</div>
              <h3 className="text-3xl font-bold mb-4 text-foreground">RAPID RESULTS</h3>
              <p className="text-xl mb-6 text-muted-foreground">Average user earns their first ₹1 within 30 days of starting!</p>
              <div className="grid grid-cols-2 gap-4 text-lg">
                <div className="amber-card p-4">
                  <div className="font-bold text-foreground">85%</div>
                  <div className="text-sm text-muted-foreground">SUCCESS RATE</div>
                </div>
                <div className="amber-card p-4">
                  <div className="font-bold text-foreground">30 DAYS</div>
                  <div className="text-sm text-muted-foreground">AVG. TO FIRST ₹1</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Waitlist Section */}
      <section id="waitlist-section" className="py-20 bg-black text-white">
        <div className="amber-container text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-6xl font-bold uppercase mb-6" style={{ color: '#f59e0b' }}>
              READY TO START YOUR<br/>SIDE HUSTLE JOURNEY?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              🚀 <strong>LAUNCHING FEBRUARY 2025!</strong> Join our exclusive waitlist and be the first to access 
              Atomic Hustler. Early members get <strong>LIFETIME 50% OFF</strong>!
            </p>

            {/* Waitlist Form */}
            <form onSubmit={handleWaitlistSubmit} className="max-w-md mx-auto mb-8">
              <div className="space-y-4">
                <Input
                  type="text"
                  placeholder="Your Full Name"
                  value={waitlistData.name}
                  onChange={(e) => setWaitlistData({...waitlistData, name: e.target.value})}
                  className="h-12 text-lg bg-white text-black"
                  required
                />
                <Input
                  type="email"
                  placeholder="Your Email Address"
                  value={waitlistData.email}
                  onChange={(e) => setWaitlistData({...waitlistData, email: e.target.value})}
                  className="h-12 text-lg bg-white text-black"
                  required
                />
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full h-12 bg-primary text-primary-foreground text-lg font-bold uppercase hover:bg-amber-600 shadow-sm"
                >
                  {isSubmitting ? 'JOINING...' : 'SECURE MY EARLY ACCESS 🔥'}
                </Button>
              </div>
              {submitMessage && (
                <p className={`mt-4 text-lg ${submitMessage.includes('Thank you') ? 'text-green-400' : 'text-red-400'}`}>
                  {submitMessage}
                </p>
              )}
            </form>

            {/* Commented out for waitlist phase - will re-enable for full launch */}
            {/* <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button
                onClick={handleGoogleLogin}
                className="bg-primary text-primary-foreground px-10 py-4 text-xl font-bold uppercase hover:bg-amber-600 shadow-sm"
              >
                START FREE WITH GOOGLE
              </Button>
              <Button 
                onClick={scrollToFAQ}
                className="bg-white text-black px-10 py-4 text-xl font-bold uppercase hover:bg-amber-200 hover:text-amber-800"
              >
                HAVE QUESTIONS?
              </Button>
            </div> */}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="amber-card p-6">
                <div className="text-3xl font-bold text-primary">500+</div>
                <div className="font-bold">ALREADY JOINED</div>
              </div>
              <div className="amber-card p-6">
                <div className="text-3xl font-bold text-primary">50% OFF</div>
                <div className="font-bold">EARLY BIRD DISCOUNT</div>
              </div>
            </div>

            <div className="mt-8">
              <Button 
                onClick={scrollToFAQ}
                className="bg-white text-black px-10 py-4 text-xl font-bold uppercase hover:bg-amber-200 hover:text-amber-800"
              >
                HAVE QUESTIONS?
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq-section" className="py-20 bg-muted">
        <div className="amber-container">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold uppercase mb-4 text-foreground">
              FREQUENTLY ASKED QUESTIONS
            </h2>
            <p className="text-xl max-w-3xl mx-auto text-muted-foreground">
              Everything you need to know about Atomic Hustler
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="what-is-side-hustle-dna" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🚀 What is Atomic Hustler?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Atomic Hustler is an AI-powered platform that helps you discover, plan, and launch your side hustle—from idea to your first paying customers. We guide you step by step with simple tools designed for individuals and small teams.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="modules-included" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🧩 What modules are included in Atomic Hustler?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">🌱 1. Business Plan Generator</h4>
                      <p className="mb-2">This module helps you create a clear, personalized business plan in minutes.</p>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Find the best business idea based on your skills and budget</li>
                        <li>Get a detailed plan with revenue model, target audience, pricing, and timelines</li>
                        <li>Download a professional summary you can show to family, partners, or banks</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">📊 2. Financial Plan</h4>
                      <p className="mb-2">The Financial Plan helps you see how much money you'll need to start and what you can earn.</p>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Forecast your profit and loss over 1–5 years</li>
                        <li>Estimate monthly cash flow and expenses</li>
                        <li>Understand your break-even point</li>
                        <li>Download financial reports (P&L, cash flow) for reference</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">📣 3. Marketing Plan</h4>
                      <p className="mb-2">This module shows you how to find and reach customers.</p>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Discover the best channels (WhatsApp, Instagram, referrals)</li>
                        <li>Get content ideas and messaging tips</li>
                        <li>Learn how to price and promote your products</li>
                        <li>See a step-by-step plan to win your first 50 customers</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">🗂️ 4. CRM Tracker</h4>
                      <p className="mb-2">Your mini-CRM helps you stay organized while talking to leads and customers.</p>
                      <ul className="list-disc list-inside space-y-1 text-sm">
                        <li>Add contacts and track their status (New, Contacted, Won, Lost)</li>
                        <li>Keep notes and set reminders for follow-ups</li>
                        <li>Visual progress bar as you approach your first 50 customers</li>
                        <li>Export your customer list anytime</li>
                      </ul>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="suitable-for-beginners" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  👶 Is Atomic Hustler suitable for beginners?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Yes! Atomic Hustler is designed for first-time entrepreneurs and freelancers. No jargon. No complex tools. Everything is step by step, in plain language.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="special-software" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  💻 Do I need any special software?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  No, you only need a web browser. All your plans and data are stored securely online.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="edit-plans" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  ✏️ Can I edit my plans later?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Absolutely. You can update your business, financial, and marketing plans anytime as you learn and grow.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="free-to-use" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  💰 Is Atomic Hustler free to use?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  We offer a free version where you can generate your first business plan and explore the tools. Some advanced features like detailed financial reports or exporting marketing plans may require a paid upgrade. We'll always show you pricing clearly before you pay—no surprises.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="pricing-cost" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  💵 How much does the paid version cost?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Our pricing is designed for small budgets with affordable monthly or one-time plans, plus special discounts for students, homemakers, and retirees. Please visit our Pricing page for the latest details.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="credit-card" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  💳 Do I need a credit card to get started?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  No. You can sign up and create your profile without entering any payment details. You only need to pay if you choose to unlock premium features.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="data-security" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🔐 Is my information safe?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  <div className="space-y-2">
                    <p>Yes. We take your privacy seriously.</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      <li>Your data is stored securely with encryption</li>
                      <li>Only you can access your plans and CRM</li>
                      <li>We never sell your information to third parties</li>
                    </ul>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="who-can-see" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  👁️ Who can see my business plans?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Only you can see your plans, unless you choose to export and share them yourself (for example, with a business partner or bank).
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="delete-data" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🗑️ Can I delete my data?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Yes. You can delete your account and all your data anytime from your profile settings.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="how-to-start" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🌱 How do I get started?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  <div className="space-y-2">
                    <p>It's easy:</p>
                    <ol className="list-decimal list-inside space-y-1 text-sm">
                      <li>Create a free account</li>
                      <li>Fill out your profile (your skills, goals, budget)</li>
                      <li>Generate your first business plan in a few clicks</li>
                      <li>Explore financial, marketing, and CRM tools</li>
                    </ol>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="not-sure-business" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🤔 I'm not sure what business to start. Can Atomic Hustler help?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Yes! Our AI will recommend the best ideas for you based on your answers. You don't need to have a clear idea in mind when you sign up.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="get-stuck" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  🆘 What if I get stuck?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  <div className="space-y-2">
                    <p>We're here to help.</p>
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      <li>Step-by-step guides inside each module</li>
                      <li>Tooltips and examples to explain every concept</li>
                      <li>Email and live chat support if you need personal help</li>
                    </ul>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="complete-session" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  ⏰ Do I have to complete everything in one session?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  No. You can save your progress anytime and come back whenever you like.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="mobile-use" className="amber-card">
                <AccordionTrigger className="text-left font-semibold text-lg px-6 py-4">
                  📱 Can I use Atomic Hustler on my phone?
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-muted-foreground">
                  Yes! The website is fully responsive, so you can plan and track your side hustle from your mobile or tablet.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="amber-nav py-8">
        <div className="amber-container text-center">
          <div className="flex justify-center items-center mb-4">
            <div className="w-6 h-6 bg-gradient-to-br from-primary to-amber-600 border flex items-center justify-center rounded-full">
              <span className="text-primary-foreground text-xs font-bold">AH</span>
            </div>
            <span className="text-foreground font-semibold ml-2">ATOMIC HUSTLER</span>
          </div>
          <p className="mb-4 text-muted-foreground">Helping Indians discover their perfect side hustle, one success story at a time!</p>
          <p className="text-sm text-muted-foreground">© 2024 Atomic Hustler. Made with ❤️ for India.</p>
        </div>
      </footer>
    </div>
  );
}