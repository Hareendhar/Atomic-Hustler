CREATE TABLE "business_ideas" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" varchar NOT NULL,
	"profile_id" integer NOT NULL,
	"title" varchar NOT NULL,
	"description" text NOT NULL,
	"target_market" text NOT NULL,
	"profit_potential" text NOT NULL,
	"startup_cost" text NOT NULL,
	"difficulty" varchar NOT NULL,
	"time_to_launch" text NOT NULL,
	"ai_data" jsonb,
	"is_selected" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "contacts" (
	"id" serial PRIMARY KEY NOT NULL,
	"business_plan_id" integer NOT NULL,
	"customer_name" text NOT NULL,
	"contact_info" text,
	"channel_source" text NOT NULL,
	"status" text NOT NULL,
	"next_action" text,
	"next_action_date" timestamp,
	"notes" text,
	"last_activity" timestamp DEFAULT now(),
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "business_plans" ALTER COLUMN "selected_idea_index" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "business_plans" ALTER COLUMN "ai_generated_ideas" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ALTER COLUMN "location" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "age" integer NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "gender" text NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "country" text NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "city" text NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "business_location" text NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "current_profession" text NOT NULL;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD COLUMN "has_created_business_plan" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "business_ideas" ADD CONSTRAINT "business_ideas_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "business_ideas" ADD CONSTRAINT "business_ideas_profile_id_user_profiles_id_fk" FOREIGN KEY ("profile_id") REFERENCES "public"."user_profiles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contacts" ADD CONSTRAINT "contacts_business_plan_id_business_plans_id_fk" FOREIGN KEY ("business_plan_id") REFERENCES "public"."business_plans"("id") ON DELETE no action ON UPDATE no action;