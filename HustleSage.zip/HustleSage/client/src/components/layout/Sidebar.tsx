
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Home,
  Lightbulb,
  FileText,
  TrendingUp,
  Megaphone,
  Calendar,
  Notebook,
  User,
  Settings,
  LogOut,
  ChevronRight,
  Lock,
  CheckCircle,
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  // Get user profile and business plans to determine module availability
  const { data: profile } = useQuery({
    queryKey: ["/api/profile"],
    retry: 1,
  });

  const { data: businessPlans = [] } = useQuery({
    queryKey: ["/api/business-plans"],
    retry: 1,
  });

  const { data: ideas = [] } = useQuery({
    queryKey: ["/api/business-ideas"],
    retry: 1,
  });

  const hasProfile = profile?.isCompleted || false;
  const hasIdeas = Array.isArray(ideas) && ideas.length > 0;
  const hasBusinessPlan = Array.isArray(businessPlans) && businessPlans.length > 0;
  const latestPlan = Array.isArray(businessPlans) ? businessPlans[0] : null; // Most recent business plan

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const menuItems = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      href: "/",
      available: true,
      description: "Dashboard overview"
    },
    {
      id: "ideas",
      label: "Ideas",
      icon: Lightbulb,
      href: "/ideas",
      available: hasProfile,
      description: "AI-generated business ideas & chat"
    },
    {
      id: "business-plan",
      label: "Business Plan",
      icon: FileText,
      href: "/business-plans",
      available: hasIdeas,
      description: "Detailed business planning"
    },
    {
      id: "financial-plan",
      label: "Financial Plan",
      icon: TrendingUp,
      href: "/financial-plan",
      available: hasBusinessPlan,
      description: "Financial projections & analysis"
    },
    {
      id: "marketing-plan",
      label: "Marketing Plan",
      icon: Megaphone,
      href: "/marketing-plan",
      available: hasBusinessPlan,
      description: "Marketing strategy & channels"
    },
    {
      id: "calendar",
      label: "Calendar",
      icon: Calendar,
      href: "/calendar",
      available: hasBusinessPlan,
      description: "Execution timeline & tasks"
    },
    {
      id: "sales-notebook",
      label: "Sales Notebook",
      icon: Notebook,
      href: "/sales-notebook",
      available: hasBusinessPlan,
      description: "Sales tracking & notes"
    }
  ];

  return (
    <div className={cn("flex flex-col h-full bg-card border-r", className)}>
      {/* Profile Section */}
      <div className="p-4 border-b">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user?.profileImageUrl || ""} />
            <AvatarFallback>
              {user?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {user?.firstName || user?.email?.split('@')[0] || 'User'}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {(profile as any)?.location || 'Complete profile'}
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <Link href="/profile-setup">
            <Button variant="outline" size="sm" className="flex-1">
              <User className="w-3 h-3 mr-1" />
              Profile
            </Button>
          </Link>
          <Button variant="outline" size="sm" onClick={handleLogout}>
            <LogOut className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => {
          const isActive = location === item.href || location.startsWith(item.href + '/');
          const Icon = item.icon;

          if (!item.available) {
            return (
              <div key={item.id} className="group">
                <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-muted/50 text-muted-foreground cursor-not-allowed">
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{item.label}</span>
                  <Lock className="w-3 h-3 ml-auto" />
                </div>
                <p className="text-xs text-muted-foreground mt-1 px-3">
                  {item.id === 'ideas' ? 'Complete profile first' :
                   item.id === 'business-plan' ? 'Generate ideas first' :
                   'Create business plan first'}
                </p>
              </div>
            );
          }

          return (
            <div key={item.id}>
              <Link href={item.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-3 h-auto py-2",
                    isActive && "bg-primary text-primary-foreground"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm">{item.label}</span>
                </Button>
              </Link>
            </div>
          );
        })}
      </div>

      {/* Bottom Section */}
      <div className="p-4 border-t">
        <div className="text-xs text-muted-foreground text-center">
          <div className="font-medium">Hustle Mover</div>
          <div>AI-Powered Business Planning</div>
        </div>
      </div>
    </div>
  );
}