import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  User,
  MapPin,
  Clock,
  TrendingUp,
  FileText,
  Lightbulb,
  Plus,
  CheckCircle,
  AlertCircle
} from "lucide-react";

export default function Home() {
  const { user } = useAuth();

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
    retry: 1,
  });

  const { data: businessPlans = [], isLoading: plansLoading } = useQuery({
    queryKey: ["/api/business-plans"],
    retry: 1,
  });

  if (profileLoading || plansLoading) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
              <p className="text-muted-foreground">Loading dashboard...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const isNewUser = !profile?.isCompleted;
  const hasBusinessPlans = businessPlans.length > 0;

  // Calculate completion progress
  const getProfileProgress = () => {
    if (!profile) return 0;
    const fields = [
      profile.ageGroup,
      profile.location,
      profile.topSkills,
      profile.availableHours,
      profile.incomeGoal
    ];
    const completed = fields.filter(field => field && field !== '').length;
    return Math.round((completed / fields.length) * 100);
  };

  const profileProgress = getProfileProgress();

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              Welcome back, {user?.firstName || user?.email?.split('@')[0] || 'there'}!
            </h1>
            <p className="text-muted-foreground mt-1">
              Here's your business planning overview
            </p>
          </div>
          
          {isNewUser && (
            <Link href="/ideas">
              <Button size="lg" className="gap-2">
                <Plus className="w-4 h-4" />
                Start with New Ideas
              </Button>
            </Link>
          )}
        </div>

        {/* New User Welcome */}
        {isNewUser && (
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-primary" />
                Get Started with Your Business Journey
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Welcome to Hustle Mover! Let's help you discover and plan your perfect side hustle.
              </p>
              <div className="flex gap-3">
                <Link href="/profile-setup">
                  <Button variant="outline">Complete Profile</Button>
                </Link>
                <Link href="/ideas">
                  <Button>Generate Business Ideas</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Profile Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Profile Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Completion</span>
                <Badge variant={profileProgress === 100 ? "default" : "secondary"}>
                  {profileProgress}%
                </Badge>
              </div>
              <Progress value={profileProgress} className="w-full" />
              
              {profile ? (
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span>{profile.location || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3 h-3 text-muted-foreground" />
                    <span>{profile.availableHours || 'Not specified'} hours/week</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-3 h-3 text-muted-foreground" />
                    <span>Goal: {profile.incomeGoal || 'Not specified'}</span>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground mb-3">Profile not completed</p>
                  <Link href="/profile-setup">
                    <Button size="sm">Complete Profile</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Business Plans Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Business Plans
              </CardTitle>
            </CardHeader>
            <CardContent>
              {hasBusinessPlans ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold">{businessPlans.length}</span>
                    <Badge variant="default">Active</Badge>
                  </div>
                  
                  <div className="space-y-2">
                    {businessPlans.slice(0, 3).map((plan: any) => (
                      <div key={plan.id} className="p-2 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium truncate">
                            {plan.title}
                          </span>
                          <Badge variant={plan.status === 'locked' ? 'default' : 'secondary'} className="text-xs">
                            {plan.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>

                  {businessPlans.length > 3 && (
                    <p className="text-xs text-muted-foreground">
                      +{businessPlans.length - 3} more plans
                    </p>
                  )}
                </div>
              ) : (
                <div className="text-center py-4">
                  <FileText className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground mb-3">No business plans yet</p>
                  {profile?.isCompleted ? (
                    <Link href="/ideas">
                      <Button size="sm">Generate Ideas</Button>
                    </Link>
                  ) : (
                    <p className="text-xs text-muted-foreground">Complete profile first</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link href="/profile-setup">
                <Button variant="outline" className="w-full justify-start">
                  <User className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              </Link>
              
              {profile?.isCompleted && (
                <Link href="/ideas">
                  <Button variant="outline" className="w-full justify-start">
                    <Lightbulb className="w-4 h-4 mr-2" />
                    Generate New Ideas
                  </Button>
                </Link>
              )}
              
              {hasBusinessPlans && (
                <>
                  <Link href={`/business-plan/${businessPlans[0].id}`}>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="w-4 h-4 mr-2" />
                      View Latest Plan
                    </Button>
                  </Link>
                  
                  <Link href={`/execution-calendar/${businessPlans[0].id}`}>
                    <Button variant="outline" className="w-full justify-start">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Check Calendar
                    </Button>
                  </Link>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Usage Summary */}
        {hasBusinessPlans && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{businessPlans.length}</div>
                  <div className="text-sm text-muted-foreground">Business Plans</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {businessPlans.filter((p: any) => p.status === 'locked').length}
                  </div>
                  <div className="text-sm text-muted-foreground">Completed Plans</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">7</div>
                  <div className="text-sm text-muted-foreground">Days Active</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">12</div>
                  <div className="text-sm text-muted-foreground">Tasks Completed</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}