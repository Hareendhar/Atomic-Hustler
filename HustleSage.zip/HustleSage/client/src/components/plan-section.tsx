import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface PlanSectionProps {
  title: string;
  icon: string;
  content: string;
  color: string;
}

export function PlanSection({ title, icon, content, color }: PlanSectionProps) {
  return (
    <Card className="comic-border hover:shadow-lg transition-all duration-300">
      <CardHeader>
        <CardTitle className={`font-handwritten text-xl text-${color} flex items-center space-x-3`}>
          <span className="text-2xl">{icon}</span>
          <span>{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose prose-sm max-w-none">
          <div className="text-gray-700 leading-relaxed whitespace-pre-line">
            {content}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
