
import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { type BusinessPlan, type FinancialPlan } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlanSection } from "@/components/plan-section";
import {
  FileText,
  Download,
  Lock,
  AlertTriangle,
  Lightbulb,
  Users,
  Target,
  DollarSign,
  Calendar,
  Shield,
  TrendingUp,
  ArrowLeft
} from "lucide-react";

// Remove local interface since we're using the one from schema

export default function BusinessPlan() {
  const { id } = useParams<{ id?: string }>();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeSection, setActiveSection] = useState("summary");

  // Get specific business plan if ID provided
  const { data: businessPlan, isLoading: planLoading, error: planError } = useQuery<BusinessPlan>({
    queryKey: ["/api/business-plans", id],
    enabled: !!id && id !== "new" && !isNaN(parseInt(id || "")),
    retry: 1,
  });

  // Check if financial plan exists
  const { data: financialPlan, isLoading: financialLoading } = useQuery<FinancialPlan>({
    queryKey: ["/api/business-plans", id, "financial-plan"],
    enabled: !!id && id !== "new" && !isNaN(parseInt(id || "")),
    retry: 1,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Generate financial plan mutation
  const generateFinancialPlanMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/business-plans/${id}/generate-financial-plan`, {
        method: "POST",
      });
    },
    onSuccess: (data) => {
      // Invalidate and update the cache with new data
      queryClient.invalidateQueries({
        queryKey: ["/api/business-plans", id, "financial-plan"],
      });
      queryClient.setQueryData(["/api/business-plans", id, "financial-plan"], data);
      
      toast({
        title: "Success! 💰",
        description: "Financial plan generated successfully! Redirecting...",
      });
      
      // Wait a moment for cache to update, then navigate
      setTimeout(() => {
        setLocation(`/financial-plan/${id}`);
      }, 1000);
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate financial plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Lock business plan mutation
  const lockPlanMutation = useMutation({
    mutationFn: async (planId: number) => {
      return await apiRequest(`/api/business-plans/${planId}/lock`, {
        method: "PATCH",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${id}`] });
      toast({
        title: "Plan Locked!",
        description: "Your business plan is now read-only and saved permanently.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to lock business plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleLockPlan = () => {
    if (businessPlan && !businessPlan.isLocked) {
      lockPlanMutation.mutate(businessPlan.id);
    }
  };

  if (planLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
            <p className="text-muted-foreground">Loading business plan...</p>
          </div>
        </div>
      </div>
    );
  }

  // Show specific business plan
  if (!businessPlan) {
    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto text-center">
          <AlertTriangle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Business Plan Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The requested business plan could not be found.
          </p>
          <Button onClick={() => setLocation("/business-plans")} size="lg">
            Back to Business Plans
          </Button>
        </div>
      </div>
    );
  }

  const sections = [
    { id: "summary", label: "Overview", icon: FileText },
    { id: "customer", label: "Target Customer", icon: Users },
    { id: "problem", label: "Problem & Solution", icon: Target },
    { id: "revenue", label: "Revenue Model", icon: DollarSign },
    { id: "execution", label: "Execution Strategy", icon: Calendar },
    { id: "legal", label: "Legal & Compliance", icon: Shield },
    { id: "analysis", label: "Analysis & Metrics", icon: TrendingUp },
  ];

  return (
    <div className="p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation("/business-plans")}
                className="mr-2"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Back
              </Button>
              <div className="p-2 rounded-lg bg-primary/10">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-3xl font-bold">{businessPlan.title}</h1>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={businessPlan.status === 'locked' ? 'default' : 'secondary'}>
                {businessPlan.status}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {businessPlan.daysPlanned}-day execution plan
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {financialPlan ? (
              <Button 
                onClick={() => setLocation(`/financial-plan/${businessPlan.id}`)}
                variant="outline"
              >
                <DollarSign className="w-4 h-4 mr-2" />
                View Financial Plan
              </Button>
            ) : (
              <Button 
                onClick={() => generateFinancialPlanMutation.mutate()}
                disabled={generateFinancialPlanMutation.isPending}
                variant="outline"
              >
                <DollarSign className="w-4 h-4 mr-2" />
                {generateFinancialPlanMutation.isPending ? "Generating..." : "Generate Financial Plan"}
              </Button>
            )}
            <Button 
              onClick={() => setLocation(`/execution-calendar/${businessPlan.id}`)}
              variant="outline"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Calendar
            </Button>
            {!businessPlan.isLocked && (
              <Button 
                onClick={handleLockPlan}
                disabled={lockPlanMutation.isPending}
                variant="outline"
              >
                <Lock className="w-4 h-4 mr-2" />
                {lockPlanMutation.isPending ? "Locking..." : "Lock Plan"}
              </Button>
            )}
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Content */}
        <Tabs value={activeSection} onValueChange={setActiveSection}>
          <TabsList className="grid w-full grid-cols-7">
            {sections.map((section) => {
              const Icon = section.icon;
              return (
                <TabsTrigger key={section.id} value={section.id} className="flex items-center gap-1">
                  <Icon className="w-3 h-3" />
                  <span className="hidden sm:inline">{section.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          <TabsContent value="summary" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PlanSection
                title="Business Summary"
                content={businessPlan?.businessSummary || ''}
                icon={<FileText className="w-5 h-5" />}
              />
              <PlanSection
                title="Value Proposition"
                content={businessPlan?.valueProposition || ''}
                icon={<Target className="w-5 h-5" />}
              />
            </div>
            <PlanSection
              title="Tools & Resources"
              content={businessPlan?.toolsResources || ''}
              icon={<Lightbulb className="w-5 h-5" />}
            />
          </TabsContent>

          <TabsContent value="customer" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PlanSection
                title="Target Customer"
                content={businessPlan?.targetCustomer || ''}
                icon={<Users className="w-5 h-5" />}
              />
              <PlanSection
                title="Customer Relationships"
                content={businessPlan?.customerRelationships || ''}
                icon={<Users className="w-5 h-5" />}
              />
            </div>
          </TabsContent>

          <TabsContent value="problem" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PlanSection
                title="Problem Solving"
                content={businessPlan?.problemSolving || ''}
                icon={<Target className="w-5 h-5" />}
              />
              <PlanSection
                title="Product/Service"
                content={businessPlan?.productService || ''}
                icon={<Target className="w-5 h-5" />}
              />
            </div>
          </TabsContent>

          <TabsContent value="revenue" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PlanSection
                title="Revenue Model"
                content={businessPlan?.revenueModel || ''}
                icon={<DollarSign className="w-5 h-5" />}
              />
              <PlanSection
                title="Cost Structure"
                content={businessPlan?.costStructure || ''}
                icon={<DollarSign className="w-5 h-5" />}
              />
            </div>
          </TabsContent>

          <TabsContent value="execution" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PlanSection
                title="Key Activities"
                content={businessPlan?.keyActivities || ''}
                icon={<Calendar className="w-5 h-5" />}
              />
              <PlanSection
                title="Channels"
                content={businessPlan?.channels || ''}
                icon={<Calendar className="w-5 h-5" />}
              />
            </div>
            <PlanSection
              title="Key Partnerships"
              content={businessPlan?.keyPartnerships || ''}
              icon={<Users className="w-5 h-5" />}
            />
          </TabsContent>

          <TabsContent value="legal" className="space-y-6">
            <PlanSection
              title="Legal Compliance"
              content={businessPlan.legalCompliance}
              icon={<Shield className="w-5 h-5" />}
            />
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <PlanSection
                title="Risks & Mitigation"
                content={businessPlan.risks}
                icon={<AlertTriangle className="w-5 h-5" />}
              />
              <PlanSection
                title="Success Metrics"
                content={businessPlan.successMetrics}
                icon={<TrendingUp className="w-5 h-5" />}
              />
            </div>
            
            {/* Success Stories */}
            {businessPlan?.successStories && Array.isArray(businessPlan.successStories) && businessPlan.successStories.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Success Stories</h3>
                <div className="grid gap-4">
                  {businessPlan.successStories.map((story: any, index: number) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="text-lg">{story.businessName}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">{story.description}</p>
                        <p className="text-sm"><strong>Success Factors:</strong> {story.successFactors}</p>
                        {story.website && (
                          <p className="text-sm mt-2">
                            <strong>Website:</strong> 
                            <a href={story.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline ml-1">
                              {story.website}
                            </a>
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Failure Analysis */}
            {businessPlan?.failureAnalysis && Array.isArray(businessPlan.failureAnalysis) && businessPlan.failureAnalysis.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Failure Analysis</h3>
                <div className="grid gap-4">
                  {businessPlan.failureAnalysis.map((failure: any, index: number) => (
                    <Card key={index} className="border-orange-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-orange-700">{failure.businessName}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">{failure.idea}</p>
                        <p className="text-sm mb-2"><strong>Failure Reasons:</strong> {failure.failureReasons}</p>
                        <p className="text-sm"><strong>Lessons Learned:</strong> {failure.lessons}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
