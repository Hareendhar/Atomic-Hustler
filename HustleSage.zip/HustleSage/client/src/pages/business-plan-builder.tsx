import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FloatingElements } from "@/components/floating-elements";
import { BusinessIdeaCard } from "@/components/business-idea-card";
import { ChatBox } from "@/components/chat-box";
import { PlanSection } from "@/components/plan-section";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Rocket, ArrowLeft, Lightbulb, FileText, Calendar, Lock, Download, TrendingUp, DollarSign, PieChart, Calculator, BarChart3, AlertTriangle } from "lucide-react";

export default function BusinessPlanBuilder() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [selectedIdeaIndex, setSelectedIdeaIndex] = useState<number | null>(null);
  const [generatedIdeas, setGeneratedIdeas] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState("ideas");

  // Auth check
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, authLoading, toast]);

  // Check if user has business plans
  const { data: existingPlans = [] } = useQuery({
    queryKey: ["/api/business-plans"],
    enabled: !!user,
    retry: 1,
  });

  // Check if user already has a locked plan
  useEffect(() => {
    if (existingPlans.length > 0 && id === "new") {
      const hasLockedPlan = existingPlans.some((plan: any) => plan.isLocked);
      if (hasLockedPlan) {
        toast({
          title: "Business Plan Already Complete",
          description: "You already have a locked business plan. Only one business plan per user is allowed.",
          variant: "destructive",
        });
        setLocation("/dashboard");
        return;
      }
    }
  }, [existingPlans, id, setLocation, toast]);

  // Load existing business plan if ID is provided
  const { data: businessPlan, isLoading: planLoading } = useQuery({
    queryKey: [`/api/business-plans/${id}`],
    enabled: id !== "new",
    retry: false,
  });

  // Load user profile
  const { data: profile } = useQuery({
    queryKey: ["/api/profile"],
    retry: false,
  });

  // Generate ideas mutation
  const generateIdeasMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/generate-ideas");
      return await response.json();
    },
    onSuccess: (data) => {
      setGeneratedIdeas(data.ideas);
      toast({
        title: "Ideas Generated! 🎉",
        description: "We've found 3 perfect side hustles for you!",
      });
    },
    onError: (error) => {
      console.error("Ideas generation error:", error);
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error Generating Ideas",
        description: "Failed to generate business ideas. Our AI service might be temporarily unavailable. Please try again in a few moments.",
        variant: "destructive",
      });
    },
  });

  // Create business plan mutation
  const createPlanMutation = useMutation({
    mutationFn: async ({ ideas, selectedIdeaIndex }: { ideas: any[], selectedIdeaIndex: number }) => {
      const response = await apiRequest("POST", "/api/create-business-plan", {
        ideas,
        selectedIdeaIndex,
      });
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/business-plans"] });
      toast({
        title: "Business Plan Created! 🚀",
        description: "Your comprehensive business plan is ready!",
      });
      setLocation(`/business-plan/${data.id}`);
    },
    onError: (error) => {
      console.error("Business plan creation error:", error);
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      if ((error as Error).message?.includes('locked business plan')) {
        toast({
          title: "Business Plan Already Complete",
          description: "You already have a locked business plan. Only one business plan per user is allowed.",
          variant: "destructive",
        });
        setLocation("/dashboard");
        return;
      }
      toast({
        title: "Error Creating Business Plan",
        description: "Failed to create business plan. Our AI service might be temporarily unavailable. Please try again in a few moments.",
        variant: "destructive",
      });
    },
  });

  // Lock business plan mutation
  const lockPlanMutation = useMutation({
    mutationFn: async (planId: number) => {
      const response = await apiRequest("PATCH", `/api/business-plans/${planId}/lock`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/business-plans/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/business-plans"] });
      toast({
        title: "Plan Locked! 🔒",
        description: "Your business plan is complete! Focus on execution now. No new plans can be created.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to lock business plan. Please try again.",
      });
    },
  });

  // Initialize for new plans
  useEffect(() => {
    if (id === "new" && !generateIdeasMutation.isPending && generatedIdeas.length === 0) {
      if (!profile?.isCompleted) {
        toast({
          title: "Profile Required",
          description: "Please complete your profile first to generate business ideas.",
          variant: "destructive",
        });
        setLocation("/profile-setup");
        return;
      }
      generateIdeasMutation.mutate();
    }
  }, [id, profile, generateIdeasMutation, generatedIdeas.length, setLocation, toast]);

  // Load existing plan data
  useEffect(() => {
    if (businessPlan && id !== "new") {
      setGeneratedIdeas(businessPlan.aiGeneratedIdeas || []);
      setSelectedIdeaIndex(businessPlan.selectedIdeaIndex);
      setActiveTab("plan");
    }
  }, [businessPlan, id]);

  const handleIdeaSelect = (index: number) => {
    setSelectedIdeaIndex(index);
    setActiveTab("chat");
  };

  const handleCreatePlan = () => {
    if (selectedIdeaIndex !== null && generatedIdeas.length > 0) {
      createPlanMutation.mutate({
        ideas: generatedIdeas,
        selectedIdeaIndex,
      });
    }
  };

  const handleLockPlan = () => {
    if (businessPlan && !businessPlan.isLocked) {
      lockPlanMutation.mutate(businessPlan.id);
    }
  };

  const canEdit = businessPlan ? !businessPlan.isLocked : true;
  const isNew = id === "new";

  if (authLoading || (id !== "new" && planLoading)) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#f59e0b] mx-auto mb-4"></div>
          <p className="text-[#262626]">Loading business plan...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen">
      <FloatingElements />

      {/* Header */}
      <header className="bg-white border-b border-[#e5e7eb] sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#f59e0b] flex items-center justify-center font-bold text-xl text-white rounded">
                AH
              </div>
              <span className="text-2xl font-bold text-[#262626]">ATOMIC HUSTLER</span>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setLocation("/")}
                className="bg-[#f3f4f6] hover:bg-[#e5e7eb] text-[#262626] font-medium py-2 px-4 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-4 h-4 mr-2 inline" />
                BACK TO DASHBOARD
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Plan Status */}
        {businessPlan && (
          <div className="mb-8">
            <div className="bg-[#fffbeb] border border-[#f59e0b] rounded-lg p-4 text-center">
              <div className="flex justify-center items-center space-x-4 mb-2">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  businessPlan.status === "locked" ? "bg-[#ef4444] text-white" :
                  businessPlan.status === "completed" ? "bg-[#10b981] text-white" :
                  "bg-[#f59e0b] text-white"
                }`}>
                  {businessPlan.status === "locked" ? "LOCKED" :
                   businessPlan.status === "completed" ? "COMPLETED" :
                   "DRAFT"}
                </span>
                <span className="bg-[#f59e0b] text-white px-3 py-1 rounded-full text-sm font-medium">
                  {businessPlan.daysPlanned}-DAY PLAN
                </span>
              </div>
              {businessPlan.isLocked && (
                <p className="text-sm font-medium text-[#262626]">
                  THIS PLAN IS LOCKED AND READ-ONLY. CREATED {new Date(businessPlan.createdAt).toLocaleDateString()}
                </p>
              )}
            </div>
          </div>
        )}

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="grid w-full grid-cols-3 gap-2 mb-8">
            <button 
              onClick={() => setActiveTab("ideas")}
              className={`py-3 px-4 rounded-lg font-medium transition-colors ${
                activeTab === "ideas" 
                  ? "bg-[#f59e0b] text-white" 
                  : "bg-[#f3f4f6] text-[#262626] hover:bg-[#e5e7eb]"
              }`}
            >
              IDEAS
            </button>
            <button 
              onClick={() => setActiveTab("chat")}
              disabled={selectedIdeaIndex === null}
              className={`py-3 px-4 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                activeTab === "chat" 
                  ? "bg-[#f59e0b] text-white" 
                  : "bg-[#f3f4f6] text-[#262626] hover:bg-[#e5e7eb]"
              }`}
            >
              CHAT
            </button>
            <button 
              onClick={() => setActiveTab("plan")}
              disabled={!businessPlan && isNew}
              className={`py-3 px-4 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                activeTab === "plan" 
                  ? "bg-[#f59e0b] text-white" 
                  : "bg-[#f3f4f6] text-[#262626] hover:bg-[#e5e7eb]"
              }`}
            >
              BUSINESS PLAN
            </button>
          </div>

          {/* Ideas Tab */}
          <TabsContent value="ideas">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold text-[#262626] mb-4">
                Your Personalized Business Ideas! 💡
              </h2>
              <p className="text-xl text-[#6b7280]">
                Based on your profile, here are 3 perfect side hustles tailored just for you!
              </p>
            </div>

            {generateIdeasMutation.isPending ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[#f59e0b] mx-auto mb-6"></div>
                <h3 className="text-xl font-semibold text-[#262626] mb-2">Generating Your Ideas...</h3>
                <p className="text-[#6b7280]">Our AI is analyzing your profile to find perfect matches!</p>
              </div>
            ) : generatedIdeas.length > 0 ? (
              <div className="grid md:grid-cols-3 gap-8 mb-8">
                {generatedIdeas.map((idea, index) => (
                  <BusinessIdeaCard
                    key={index}
                    idea={idea}
                    index={index}
                    isSelected={selectedIdeaIndex === index}
                    onSelect={() => handleIdeaSelect(index)}
                    disabled={!canEdit}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Lightbulb className="w-16 h-16 text-[#9ca3af] mx-auto mb-4" />
                <p className="text-[#6b7280]">No ideas generated yet</p>
              </div>
            )}

            {/* Generate Plan Button */}
            {selectedIdeaIndex !== null && isNew && canEdit && (
              <div className="text-center">
                <Button
                  onClick={handleCreatePlan}
                  disabled={createPlanMutation.isPending}
                  className="bg-[#f59e0b] hover:bg-[#d97706] text-white rounded-lg px-10 py-4 text-xl font-bold transition-colors"
                >
                  {createPlanMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                      Creating Your Plan...
                    </>
                  ) : (
                    <>
                      <FileText className="w-5 h-5 mr-3" />
                      Generate Complete Business Plan
                    </>
                  )}
                </Button>
                <p className="text-sm text-[#6b7280] mt-2">
                  This will create a comprehensive 19-point business plan with execution calendar
                </p>
              </div>
            )}
          </TabsContent>

          {/* Chat Tab */}
          <TabsContent value="chat">
            {selectedIdeaIndex !== null && generatedIdeas[selectedIdeaIndex] ? (
              <div className="space-y-8">
                <div className="grid lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-1">
                    <BusinessIdeaCard
                      idea={generatedIdeas[selectedIdeaIndex]}
                      index={selectedIdeaIndex}
                      isSelected={true}
                      onSelect={() => {}}
                      disabled={true}
                      compact={true}
                    />
                  </div>
                  <div className="lg:col-span-2">
                    <ChatBox
                      idea={generatedIdeas[selectedIdeaIndex]}
                      businessPlanId={businessPlan?.id}
                      ideaIndex={selectedIdeaIndex}
                    />
                  </div>
                </div>

                {/* Generate Plan Button for new plans */}
                {isNew && canEdit && (
                  <div className="text-center space-y-4">
                    <Button
                      onClick={handleCreatePlan}
                      disabled={createPlanMutation.isPending}
                      className="bg-[#f59e0b] hover:bg-[#d97706] text-white rounded-lg px-10 py-4 text-xl font-bold transition-colors"
                    >
                      {createPlanMutation.isPending ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                          Creating Your Plan...
                        </>
                      ) : (
                        <>
                          <FileText className="w-5 h-5 mr-3" />
                          Generate Complete Business Plan
                        </>
                      )}
                    </Button>
                    <p className="text-sm text-[#6b7280]">
                      Ready to move forward? Generate your comprehensive business plan now!
                    </p>
                    <p className="text-xs text-[#9ca3af]">
                      💡 You can chat with the AI advisor above to learn more about this idea, or proceed directly to generate your business plan.
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-[#6b7280]">Please select an idea first to start chatting!</p>
              </div>
            )}
          </TabsContent>

          {/* Business Plan Tab */}
          <TabsContent value="plan">
            {businessPlan ? (
              <div className="space-y-8">
                <div className="text-center mb-8">
                  <h2 className="text-4xl font-bold text-[#262626] mb-4">
                    Your Complete Business Plan 📋
                  </h2>
                  <p className="text-xl text-[#6b7280]">
                    Everything you need to launch your side hustle successfully!
                  </p>
                </div>

                {/* Timeline Overview */}
                <Card className="mb-8 bg-[#f0f9ff] border border-[#0ea5e9] rounded-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl text-[#0ea5e9] flex items-center">
                      ⏰ Your {businessPlan.daysPlanned}-Day Journey
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold text-[#262626] mb-2">Timeline</h4>
                        <p className="text-[#374151]">
                          This plan is designed to be completed in <strong>{businessPlan.daysPlanned} days</strong>.
                          Each day has specific tasks and resources to guide your progress.
                        </p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-[#262626] mb-2">Daily Commitment</h4>
                        <p className="text-[#374151]">
                          Based on your available time, you'll spend focused time each day building your side hustle step by step.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Business Summary */}
                <Card className="mb-8 bg-white border border-[#e5e7eb] rounded-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl text-[#10b981] flex items-center">
                      🎯 Business Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-[#374151] leading-relaxed">{businessPlan.businessSummary}</p>
                  </CardContent>
                </Card>

                {/* Plan Sections */}
                <div className="grid gap-6">
                  <PlanSection
                    title="Target Customer"
                    icon="🎯"
                    content={businessPlan.targetCustomer}
                    color="teal"
                  />

                  <PlanSection
                    title="Problem You're Solving"
                    icon="❗"
                    content={businessPlan.problemSolving}
                    color="sky"
                  />

                  <PlanSection
                    title="Value Proposition"
                    icon="💡"
                    content={businessPlan.valueProposition}
                    color="mint"
                  />

                  <PlanSection
                    title="Revenue Model"
                    icon="💰"
                    content={businessPlan.revenueModel}
                    color="plum"
                  />

                  <PlanSection
                    title="Key Activities"
                    icon="⚡"
                    content={businessPlan.keyActivities}
                    color="coral"
                  />

                  <PlanSection
                    title="Product/Service Overview"
                    icon="📦"
                    content={businessPlan.productService}
                    color="teal"
                  />

                  <PlanSection
                    title="Marketing Channels"
                    icon="📢"
                    content={businessPlan.channels}
                    color="sky"
                  />

                  <PlanSection
                    title="Customer Relationships"
                    icon="🤝"
                    content={businessPlan.customerRelationships}
                    color="mint"
                  />

                  <PlanSection
                    title="Key Partnerships"
                    icon="🤝"
                    content={businessPlan.keyPartnerships}
                    color="plum"
                  />

                  <PlanSection
                    title="Cost Structure"
                    icon="💸"
                    content={businessPlan.costStructure}
                    color="coral"
                  />

                  <PlanSection
                    title="Success Metrics (KPIs)"
                    icon="📊"
                    content={businessPlan.successMetrics}
                    color="teal"
                  />

                  <PlanSection
                    title="Legal & Compliance"
                    icon="⚖️"
                    content={businessPlan.legalCompliance}
                    color="sky"
                  />

                  <PlanSection
                    title="Tools & Resources"
                    icon="🛠️"
                    content={businessPlan.toolsResources}
                    color="mint"
                  />

                  <PlanSection
                    title="Risks & Mitigation"
                    icon="⚠️"
                    content={businessPlan.risks}
                    color="plum"
                  />

                  {/* Success Stories */}
                  {businessPlan.successStories && Array.isArray(businessPlan.successStories) && businessPlan.successStories.length > 0 && (
                    <Card className="bg-white border border-[#e5e7eb] rounded-lg">
                      <CardHeader>
                        <CardTitle className="text-2xl text-[#10b981]">
                          🌟 Success Stories - This Idea Works!
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-6">
                          {businessPlan.successStories.map((story: any, index: number) => (
                            <div key={index} className="bg-[#f0fdf4] border border-[#bbd7c6] rounded-lg p-4">
                              <h4 className="font-bold text-[#10b981] mb-2">{story.businessName}</h4>
                              <p className="text-[#374151] text-sm mb-2">{story.description}</p>
                              <p className="text-[#3f6212] text-xs mb-3">
                                <strong>Success Factors:</strong> {story.successFactors}
                              </p>
                              <div className="flex space-x-3 text-xs">
                                {story.website && (
                                  <a href={story.website} target="_blank" rel="noopener noreferrer" className="text-[#0ea5e9] hover:underline">
                                    🌐 Website
                                  </a>
                                )}
                                {story.instagram && (
                                  <span className="text-[#e91e63]">📸 {story.instagram}</span>
                                )}
                                {story.youtube && (
                                  <span className="text-[#f44336]">📺 {story.youtube}</span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Failure Analysis */}
                  {businessPlan.failureAnalysis && Array.isArray(businessPlan.failureAnalysis) && businessPlan.failureAnalysis.length > 0 && (
                    <Card className="bg-white border border-[#e5e7eb] rounded-lg">
                      <CardHeader>
                        <CardTitle className="text-2xl text-[#ef4444]">
                          📚 Learn from Failures - Avoid These Mistakes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-6">
                          {businessPlan.failureAnalysis.map((failure: any, index: number) => (
                            <div key={index} className="bg-[#fef2f2] border border-[#f87171] rounded-lg p-4">
                              <h4 className="font-bold text-[#ef4444] mb-2">{failure.businessName}</h4>
                              <p className="text-[#374151] text-sm mb-2">
                                <strong>What they tried:</strong> {failure.idea}
                              </p>
                              <p className="text-[#374151] text-sm mb-2">
                                <strong>Why they failed:</strong> {failure.failureReasons}
                              </p>
                              <p className="text-[#374151] text-sm">
                                <strong>Key lesson:</strong> {failure.lessons}
                              </p>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex justify-center space-x-4 pt-8">
                  <Button
                    onClick={() => setLocation(`/calendar/${businessPlan.id}`)}
                    className="bg-[#b45309] hover:bg-[#92400e] text-white rounded-lg px-8 py-3 font-semibold transition-colors"
                  >
                    <Calendar className="w-5 h-5 mr-2" />
                    View Execution Calendar
                  </Button>

                  <Button
                    className="bg-[#f3f4f6] hover:bg-[#e5e7eb] text-[#262626] border border-[#e5e7eb] rounded-lg px-8 py-3 font-semibold transition-colors"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Export PDF
                  </Button>

                  <Button
                    onClick={() => setActiveTab("plan")}
                    className="bg-[#f59e0b] hover:bg-[#d97706] text-white rounded-lg px-8 py-3 font-semibold transition-colors"
                  >
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Generate Financial Plan
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-[#9ca3af] mx-auto mb-4" />
                <p className="text-[#6b7280]">No business plan created yet</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}