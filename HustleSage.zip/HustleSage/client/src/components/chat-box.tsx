import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Send, Bot, User } from "lucide-react";

interface BusinessIdea {
  title: string;
  description: string;
  revenuePotential: string;
  difficultyLevel: string;
}

interface ChatBoxProps {
  idea: BusinessIdea;
  businessPlanId?: number;
  ideaIndex?: number;
  ideaId?: number;
  chatContext?: 'idea-exploration' | 'business-plan';
  persistedMessages?: ChatMessage[];
  onNewMessage?: () => void;
}

interface ChatMessage {
  id: number;
  message: string;
  isFromUser: boolean;
  createdAt: string;
}

// Component to render formatted text with markdown-like formatting
function FormattedMessage({ content }: { content: string }) {
  // Handle undefined or null content
  if (!content) {
    return <div>Loading...</div>;
  }
  
  // Split content by newlines and process each line
  const lines = content.split('\n');

  return (
    <div className="space-y-2">
      {lines.map((line, lineIndex) => {
        if (!line.trim()) return <br key={lineIndex} />;

        // Process inline formatting
        const processedLine = line
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold text
          .replace(/\*(.*?)\*/g, '<em>$1</em>') // Italic text
          .replace(/`(.*?)`/g, '<code class="bg-gray-200 px-1 rounded text-sm">$1</code>') // Inline code
          .replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">$1</a>'); // Links

        // Check if line starts with bullet point
        const isBulletPoint = line.trim().startsWith('•') || line.trim().startsWith('-') || line.trim().startsWith('*');

        return (
          <div
            key={lineIndex}
            className={isBulletPoint ? "ml-4" : ""}
            dangerouslySetInnerHTML={{ __html: processedLine }}
          />
        );
      })}
    </div>
  );
}

export function ChatBox({ idea, businessPlanId, ideaIndex, ideaId, chatContext = 'business-plan', persistedMessages = [], onNewMessage }: ChatBoxProps) {
  const [message, setMessage] = useState("");
  const [tempMessages, setTempMessages] = useState<ChatMessage[]>([]);
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load chat messages (only if business plan exists)
  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: [`/api/chat/${businessPlanId}/${ideaIndex}`],
    enabled: businessPlanId !== undefined && businessPlanId !== null,
    retry: false,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      // Handle different chat contexts
      if (chatContext === 'idea-exploration' && ideaId) {
        // Chat with specific idea using idea ID for context
        const response = await apiRequest("/api/chat-with-idea", {
          method: "POST",
          body: JSON.stringify({
            message: messageText,
            ideaId,
          }),
        });
        
        // Check if response is already parsed JSON or needs parsing
        if (typeof response === 'object' && response.response) {
          return response;
        }
        
        // If response is a Response object, parse it
        if (response && typeof response.json === 'function') {
          return await response.json();
        }
        
        // If response is already parsed, return it
        return response;
      } else if (!businessPlanId) {
        // Fallback to simple chat without persistence
        const response = await apiRequest("/api/chat-idea", {
          method: "POST",
          body: JSON.stringify({
            message: messageText,
            idea,
            chatHistory: tempMessages,
          }),
        });
        
        if (typeof response === 'object' && response.response) {
          return response;
        }
        
        if (response && typeof response.json === 'function') {
          return await response.json();
        }
        
        return response;
      } else {
        // Business plan context chat
        const response = await apiRequest("/api/chat", {
          method: "POST",
          body: JSON.stringify({
            message: messageText,
            businessPlanId,
            ideaIndex,
          }),
        });
        
        if (typeof response === 'object' && response.response) {
          return response;
        }
        
        if (response && typeof response.json === 'function') {
          return await response.json();
        }
        
        return response;
      }
    },
    onSuccess: (data) => {
      if (businessPlanId && ideaIndex !== undefined) {
        queryClient.invalidateQueries({ queryKey: [`/api/chat/${businessPlanId}/${ideaIndex}`] });
      } else if (chatContext === 'idea-exploration' && persistedMessages.length > 0) {
        // For persisted idea exploration, call the callback to refetch
        onNewMessage?.();
      } else if (chatContext === 'idea-exploration') {
        // For temporary idea exploration, create temporary message structure
        const userMessage = {
          id: Date.now(),
          message: message,
          isFromUser: true,
          createdAt: new Date().toISOString()
        };
        const aiMessage = {
          id: Date.now() + 1,
          message: data.response,
          isFromUser: false,
          createdAt: new Date().toISOString()
        };
        setTempMessages(prev => [...prev, userMessage, aiMessage]);
      } else {
        // Add messages to temporary state for other contexts
        setTempMessages(prev => [
          ...prev,
          { ...data.userMessage, id: Date.now() },
          { ...data.aiMessage, id: Date.now() + 1 }
        ]);
      }
      setMessage("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Chat Failed",
        description: error instanceof Error ? error.message : "Failed to get response. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Combine API messages, persisted messages, and temporary messages
  const allMessages: ChatMessage[] = businessPlanId 
    ? messages 
    : persistedMessages.length > 0 
      ? persistedMessages 
      : tempMessages;

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [allMessages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || sendMessageMutation.isPending) return;

    sendMessageMutation.mutate(message.trim());
  };

  const suggestedQuestions = [
    "How much can I realistically earn with this idea?",
    "What skills do I need to develop for this business?",
    "How do I find my first customers?",
    "What are the biggest challenges I might face?",
    "How long before I see my first revenue?",
    "What tools and resources do I need to get started?",
  ];

  const handleSuggestedQuestion = (question: string) => {
    if (!sendMessageMutation.isPending) {
      setMessage(question);
    }
  };

  return (
    <Card className="comic-border h-[600px] flex flex-col w-full max-w-full overflow-hidden">
      <CardHeader className="flex-shrink-0 border-b">
        <CardTitle className="font-handwritten text-xl text-teal flex items-center truncate">
          💬 Chat with your idea: {idea.title}
        </CardTitle>
        <p className="text-gray-600 text-sm">
          Ask anything about this business idea! Our AI advisor is here to help.
        </p>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col space-y-4 p-4 overflow-hidden">
        {/* Messages Area */}
        <ScrollArea className="flex-1 border rounded-lg p-4 max-h-[400px] overflow-y-auto">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal mx-auto mb-4"></div>
              <p className="text-gray-600">Loading conversation...</p>
            </div>
          ) : allMessages.length === 0 ? (
            <div className="text-center py-8">
              <Bot className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-700 mb-2">Welcome to your business advisor!</h3>
              <p className="text-gray-600 text-sm mb-4">
                I'm here to help you understand this business idea better. Ask me anything!
              </p>

              {/* Suggested Questions */}
              <div className="text-left">
                <p className="text-sm font-medium text-gray-700 mb-3">💡 Try asking:</p>
                <div className="space-y-2">
                  {suggestedQuestions.slice(0, 3).map((question, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestedQuestion(question)}
                      className="block w-full text-left text-sm bg-teal/10 hover:bg-teal/20 text-teal rounded-lg p-2 transition-colors"
                      disabled={sendMessageMutation.isPending}
                    >
                      "{question}"
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {allMessages.map((msg: ChatMessage) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.isFromUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex max-w-[85%] ${msg.isFromUser ? 'flex-row-reverse' : 'flex-row'} items-start space-x-2`}>
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      msg.isFromUser ? 'bg-coral ml-2' : 'bg-teal mr-2'
                    }`}>
                      {msg.isFromUser ? (
                        <User className="w-4 h-4 text-white" />
                      ) : (
                        <Bot className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <div className={`rounded-lg p-3 break-words ${
                      msg.isFromUser
                        ? 'bg-coral text-white'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      <div className="text-sm">
                        {msg.isFromUser ? (
                          <div className="whitespace-pre-wrap">{msg.message}</div>
                        ) : (
                          <FormattedMessage content={msg.message} />
                        )}
                      </div>
                      <p className={`text-xs mt-2 opacity-70`}>
                        {new Date(msg.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              {sendMessageMutation.isPending && (
                <div className="flex justify-start">
                  <div className="flex items-start space-x-2">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal flex items-center justify-center">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-gradient-to-r from-teal/10 to-teal/5 rounded-lg p-4 border border-teal/20">
                      <div className="flex items-center space-x-3">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-teal rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-teal rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-teal rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                        <span className="text-sm font-medium text-teal animate-pulse">
                          🤖 AI is thinking about your question...
                        </span>
                      </div>
                      <p className="text-xs text-teal/80 mt-2">
                        This usually takes 2-5 seconds. Please wait while I analyze your question.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>

        {/* Suggested Questions */}
        {allMessages.length > 0 && (
          <div className="flex-shrink-0">
            <p className="text-sm font-medium text-gray-700 mb-2">💡 Quick questions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.slice(0, 3).map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestedQuestion(question)}
                  className="text-xs bg-teal/10 hover:bg-teal/20 text-teal rounded-full px-3 py-1 transition-colors break-words"
                  disabled={sendMessageMutation.isPending}
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className={`flex space-x-2 flex-shrink-0 p-2 rounded-lg border transition-all duration-300 ${
          sendMessageMutation.isPending 
            ? 'bg-orange-50 border-orange-200 shadow-md' 
            : 'bg-white border-gray-200'
        }`}>
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ask anything about this business idea..."
            className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            disabled={sendMessageMutation.isPending}
            autoComplete="off"
          />
          <Button
            type="submit"
            disabled={!message.trim() || sendMessageMutation.isPending}
            className={`${sendMessageMutation.isPending ? 'bg-orange-500 hover:bg-orange-600' : 'bg-teal hover:bg-teal/80'} text-white rounded-full px-4 py-2 flex-shrink-0 min-w-[44px] h-[44px] transition-all duration-300`}
            size="sm"
            title={sendMessageMutation.isPending ? "AI is generating response..." : "Send message"}
          >
            {sendMessageMutation.isPending ? (
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}