import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight, ExternalLink, Youtube, FileText, Wrench, BookOpen } from "lucide-react";

interface ResourceLink {
  title: string;
  url: string;
  type: "youtube" | "blog" | "tool" | "guide";
}

interface CalendarTask {
  id: number;
  dayNumber: number;
  taskDate: string;
  title: string;
  description: string;
  resourceLinks: ResourceLink[];
  isCompleted: boolean;
  userNotes?: string;
}

interface CalendarTaskProps {
  task: CalendarTask;
  onUpdate: (taskId: number, isCompleted: boolean, userNotes?: string) => void;
  disabled?: boolean;
  compact?: boolean;
}

export function CalendarTask({ task, onUpdate, disabled = false, compact = false }: CalendarTaskProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [notes, setNotes] = useState(task.userNotes || "");
  const [isEditingNotes, setIsEditingNotes] = useState(false);

  const handleToggleComplete = (checked: boolean) => {
    if (!disabled) {
      console.log(`Updating task ${task.id} to completed: ${checked}`);
      onUpdate(task.id, checked, notes);
    }
  };

  const handleSaveNotes = () => {
    onUpdate(task.id, task.isCompleted, notes);
    setIsEditingNotes(false);
  };

  const getResourceIcon = (type: string) => {
    switch (type) {
      case "youtube":
        return <Youtube className="w-4 h-4 text-red-500" />;
      case "blog":
        return <FileText className="w-4 h-4 text-blue-500" />;
      case "tool":
        return <Wrench className="w-4 h-4 text-green-500" />;
      case "guide":
        return <BookOpen className="w-4 h-4 text-purple-500" />;
      default:
        return <ExternalLink className="w-4 h-4 text-gray-500" />;
    }
  };

  const taskDate = new Date(task.taskDate);
  const isToday = taskDate.toDateString() === new Date().toDateString();
  const isPast = taskDate < new Date() && !isToday;
  const isFuture = taskDate > new Date() && !isToday;

  if (compact) {
    return (
      <Card className={`transition-all duration-300 ${
        task.isCompleted ? 'bg-green-50 border-green-200' : 
        isToday ? 'bg-sky-50 border-sky-200' :
        isPast && !task.isCompleted ? 'bg-red-50 border-red-200' : ''
      }`}>
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Checkbox
              checked={task.isCompleted}
              onCheckedChange={handleToggleComplete}
              disabled={disabled}
              className="mt-1"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-2">
                <Badge className={`text-xs ${
                  isToday ? 'bg-sky-100 text-sky-800' :
                  isPast ? 'bg-gray-100 text-gray-600' :
                  'bg-mint-100 text-mint-800'
                }`}>
                  Day {task.dayNumber}
                </Badge>
                <span className="text-xs text-gray-500">
                  {taskDate.toLocaleDateString()}
                </span>
              </div>
              <h4 className={`font-semibold text-gray-800 ${task.isCompleted ? 'line-through' : ''}`}>
                {task.title}
              </h4>
              <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                {task.description}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`transition-all duration-300 ${
      task.isCompleted ? 'bg-green-50 border-green-200' : 
      isToday ? 'bg-sky-50 border-sky-200' :
      isPast && !task.isCompleted ? 'bg-red-50 border-red-200' : ''
    }`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <Checkbox
              checked={task.isCompleted}
              onCheckedChange={handleToggleComplete}
              disabled={disabled}
              className="mt-1"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Badge className={`${
                    isToday ? 'bg-sky-100 text-sky-800' :
                    isPast ? 'bg-gray-100 text-gray-600' :
                    'bg-mint-100 text-mint-800'
                  }`}>
                    Day {task.dayNumber}
                  </Badge>
                  {isToday && <Badge className="bg-orange-100 text-orange-800">Today!</Badge>}
                  {task.isCompleted && <Badge className="bg-green-100 text-green-800">✓ Done</Badge>}
                </div>
                <span className="text-sm text-gray-500">
                  {taskDate.toLocaleDateString()}
                </span>
              </div>
              <CardTitle className={`text-lg ${task.isCompleted ? 'line-through text-gray-500' : 'text-gray-800'}`}>
                {task.title}
              </CardTitle>
            </div>
          </div>
          <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm">
                {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </Button>
            </CollapsibleTrigger>
          </Collapsible>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className={`text-gray-700 mb-4 ${task.isCompleted ? 'opacity-60' : ''}`}>
          {task.description}
        </p>

        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          <CollapsibleContent className="space-y-4">
            {/* Resource Links */}
            {task.resourceLinks && task.resourceLinks.length > 0 && (
              <div>
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                  🔗 Helpful Resources
                </h4>
                <div className="grid gap-2">
                  {task.resourceLinks.map((resource, index) => (
                    <a
                      key={index}
                      href={resource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-3 p-3 bg-white border border-gray-200 rounded-lg hover:border-teal transition-colors"
                    >
                      {getResourceIcon(resource.type)}
                      <span className="text-sm font-medium text-gray-800 flex-1">
                        {resource.title}
                      </span>
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Notes Section */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-800 flex items-center">
                  📝 Your Notes
                </h4>
                {!disabled && (
                  <Button
                    onClick={() => isEditingNotes ? handleSaveNotes() : setIsEditingNotes(true)}
                    variant="outline"
                    size="sm"
                  >
                    {isEditingNotes ? "Save" : "Edit"}
                  </Button>
                )}
              </div>
              
              {isEditingNotes ? (
                <div className="space-y-2">
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Add your notes, thoughts, or progress updates..."
                    className="rounded-lg"
                    rows={3}
                  />
                  <div className="flex space-x-2">
                    <Button onClick={handleSaveNotes} size="sm" className="bg-teal text-white">
                      Save Notes
                    </Button>
                    <Button onClick={() => setIsEditingNotes(false)} variant="outline" size="sm">
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className={`p-3 bg-gray-50 rounded-lg ${!notes ? 'text-center' : ''}`}>
                  {notes ? (
                    <p className="text-gray-700 whitespace-pre-wrap">{notes}</p>
                  ) : (
                    <p className="text-gray-500 text-sm italic">
                      No notes yet. Click "Edit" to add your thoughts!
                    </p>
                  )}
                </div>
              )}
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}
