export function FloatingElements() {
  return (
    <>
      {/* Main floating dots background */}
      <div className="floating-dots"></div>
      
      {/* Additional floating elements */}
      <div className="fixed top-1/4 left-1/4 w-6 h-6 bg-mint rounded-full opacity-60 animate-bounce-slow z-0"></div>
      <div className="fixed top-3/4 right-1/3 w-4 h-4 bg-cream rounded-full opacity-50 animate-pulse-slow z-0"></div>
      <div className="fixed top-1/2 right-1/4 w-8 h-8 bg-plum rounded-full opacity-40 animate-float z-0"></div>
      
      {/* More scattered dots */}
      <div className="fixed top-1/6 right-1/6 w-3 h-3 bg-coral rounded-full opacity-30 animate-pulse-slow z-0"></div>
      <div className="fixed bottom-1/4 left-1/6 w-5 h-5 bg-teal rounded-full opacity-40 animate-bounce-slow z-0"></div>
      <div className="fixed top-2/3 left-1/3 w-4 h-4 bg-sky rounded-full opacity-35 animate-float z-0"></div>
      
      {/* Larger floating shapes */}
      <div className="fixed top-1/3 right-1/5 w-12 h-12 bg-mint/20 rounded-full animate-pulse-slow z-0"></div>
      <div className="fixed bottom-1/3 left-1/5 w-16 h-16 bg-coral/10 rounded-full animate-float z-0"></div>
      
      {/* Comic-style burst shapes */}
      <div className="fixed top-1/5 left-2/3 opacity-20 z-0">
        <svg width="30" height="30" viewBox="0 0 30 30" className="animate-bounce-slow">
          <polygon points="15,0 18,10 30,10 21,16 24,26 15,20 6,26 9,16 0,10 12,10" fill="hsl(var(--cream))" />
        </svg>
      </div>
      
      <div className="fixed bottom-1/5 right-2/3 opacity-25 z-0">
        <svg width="25" height="25" viewBox="0 0 25 25" className="animate-pulse-slow">
          <polygon points="12.5,0 16,8 25,8 18,13 21,21 12.5,16 4,21 7,13 0,8 9,8" fill="hsl(var(--plum))" />
        </svg>
      </div>
    </>
  );
}
