import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ArrowRight } from "lucide-react";

interface BusinessIdea {
  title: string;
  description: string;
  opportunityTiming: string;
  marketGap: string;
  revenuePotential: string;
  difficultyLevel: string;
  founderFit: string;
  targetPersona: string;
  startupCosts: string;
  timeCommitment: string;
}

interface BusinessIdeaCardProps {
  idea: BusinessIdea;
  index: number;
  isSelected: boolean;
  onSelect: () => void;
  disabled?: boolean;
  compact?: boolean;
}

export function BusinessIdeaCard({ 
  idea, 
  index, 
  isSelected, 
  onSelect, 
  disabled = false,
  compact = false
}: BusinessIdeaCardProps) {
  const colors = ["coral", "teal", "sky"];
  const color = colors[index % colors.length];
  
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "beginner":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  if (compact) {
    return (
      <Card className={`comic-border ${isSelected ? `border-${color}` : ''} transition-all duration-300`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className={`font-handwritten text-xl text-${color}`}>
              {idea.title}
            </CardTitle>
            {isSelected && <CheckCircle className={`w-6 h-6 text-${color}`} />}
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 text-sm mb-3">{idea.description}</p>
          <div className="flex justify-between items-center text-xs">
            <Badge className={getDifficultyColor(idea.difficultyLevel)}>
              {idea.difficultyLevel}
            </Badge>
            <span className="font-semibold text-mint">{idea.revenuePotential}</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 comic-border ${
      isSelected ? `border-${color} shadow-lg` : ''
    }`}>
      <CardHeader>
        <div className="flex items-center justify-between mb-3">
          <div className={`w-12 h-12 bg-${color} rounded-full flex items-center justify-center text-white font-bold text-lg`}>
            {index + 1}
          </div>
          {isSelected && <CheckCircle className={`w-8 h-8 text-${color}`} />}
        </div>
        <CardTitle className={`font-handwritten text-2xl text-${color}`}>
          {idea.title}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-gray-600 leading-relaxed">{idea.description}</p>
        
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <span className="font-medium text-gray-700">Revenue Potential:</span>
            <p className="text-mint font-bold">{idea.revenuePotential}</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Time Commitment:</span>
            <p className="text-gray-800">{idea.timeCommitment}</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Startup Costs:</span>
            <p className="text-gray-800">{idea.startupCosts}</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Difficulty:</span>
            <Badge className={getDifficultyColor(idea.difficultyLevel)}>
              {idea.difficultyLevel}
            </Badge>
          </div>
        </div>
        
        <div className="space-y-2 text-sm">
          <div>
            <span className="font-medium text-gray-700">Perfect for you because:</span>
            <p className="text-gray-600">{idea.founderFit}</p>
          </div>
          <div>
            <span className="font-medium text-gray-700">Target customers:</span>
            <p className="text-gray-600">{idea.targetPersona}</p>
          </div>
        </div>
        
        <div className={`bg-${color}/10 rounded-lg p-3`}>
          <span className="font-medium text-gray-700 text-sm">Market Opportunity:</span>
          <p className="text-gray-600 text-sm">{idea.opportunityTiming}</p>
        </div>
        
        <div className={`bg-${color}/10 rounded-lg p-3`}>
          <span className="font-medium text-gray-700 text-sm">Market Gap:</span>
          <p className="text-gray-600 text-sm">{idea.marketGap}</p>
        </div>
        
        {!disabled && (
          <Button
            onClick={onSelect}
            className={`w-full ${
              isSelected 
                ? `bg-${color} text-white` 
                : `border-${color} text-${color} hover:bg-${color} hover:text-white`
            } rounded-full font-semibold transition-all duration-300`}
            variant={isSelected ? "default" : "outline"}
          >
            {isSelected ? (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Selected - Chat with this idea!
              </>
            ) : (
              <>
                Select this idea
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
