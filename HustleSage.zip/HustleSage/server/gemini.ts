import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface BusinessIdea {
  title: string;
  description: string;
  opportunityTiming: string;
  marketGap: string;
  revenuePotential: string;
  difficultyLevel: string;
  founderFit: string;
  targetPersona: string;
  startupCosts: string;
  timeCommitment: string;
}

export interface BusinessPlanContent {
  businessSummary: string;
  targetCustomer: string;
  problemSolving: string;
  valueProposition: string;
  revenueModel: string;
  keyActivities: string;
  productService: string;
  channels: string;
  customerRelationships: string;
  keyPartnerships: string;
  costStructure: string;
  successMetrics: string;
  legalCompliance: string;
  executionCalendar: CalendarEntry[];
  toolsResources: string;
  risks: string;
  exportOptions: string;
  successStories: SuccessStory[];
  failureAnalysis: FailureCase[];
  daysPlanned: number;
}

export interface CalendarEntry {
  day: number;
  date: string;
  title: string;
  description: string;
  resourceLinks: ResourceLink[];
}

export interface ResourceLink {
  title: string;
  url: string;
  type: "youtube" | "blog" | "tool" | "guide";
}

export interface SuccessStory {
  businessName: string;
  description: string;
  successFactors: string;
  website?: string;
  instagram?: string;
  youtube?: string;
}

export interface FailureCase {
  businessName: string;
  idea: string;
  failureReasons: string;
  lessons: string;
}

export interface FinancialPlan {
  revenueModel: string;
  revenueAssumptions: string;
  fixedMonthlyExpenses: string;
  variableCosts: string;
  startupCosts: string;
  loansCapital: string;
  profitLossForecast: string;
  cashFlow: string;
  breakEvenAnalysis: string;
  insightsWarnings: string;
  financialReports: string;
  comparePlanReality: string;
  exportSave: string;
}

export interface MarketingPlan {
  brandVoiceMessaging: string;
  recommendedChannels: string;
  contentPlanIdeas: string;
  first50CustomersStrategy: string;
  outreachScripts: string;
  toolsResources: string;
  kpisMetrics: string;
  estimatedBudget: string;
}

async function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function retryWithBackoff<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      const isRateLimitError = error.message?.includes('429') ||
                              error.message?.includes('quota') ||
                              error.message?.includes('RESOURCE_EXHAUSTED');

      if (isRateLimitError && attempt < maxRetries) {
        const delayMs = baseDelay * Math.pow(2, attempt) + Math.random() * 1000;
        console.log(`Rate limit hit, retrying in ${delayMs}ms (attempt ${attempt + 1}/${maxRetries + 1})`);
        await delay(delayMs);
        continue;
      }
      throw error;
    }
  }
  throw new Error('Max retries exceeded');
}

export async function generateBusinessIdeas(profileData: any): Promise<BusinessIdea[]> {
  const prompt = `
You are an expert business consultant specializing in side hustles for Indians. Based on the user profile below, generate exactly 3 personalized business ideas.

User Profile:
- Age Group: ${profileData.ageGroup} (Exact age: ${profileData.age})
- Gender: ${profileData.gender}
- Location: ${profileData.location}, ${profileData.city}, ${profileData.country} (${profileData.locationType})
- Business Location: ${profileData.businessLocation}
- Current Profession: ${profileData.currentProfession}
- Languages: ${JSON.stringify(profileData.languages)}
- Working Status: ${profileData.isWorking ? 'Currently working' : 'Not working'}
- Available Hours: ${profileData.availableHours} hours per week
- Comfort with selling: ${profileData.comfortWithSelling}
- Comfortable on camera: ${profileData.comfortOnCamera}
- Comfortable with writing: ${profileData.comfortWithWriting}
- Organization skills: ${profileData.organizationSkills}
- Work preference: ${profileData.workPreference}
- Top skills: ${JSON.stringify(profileData.topSkills)}
- Digital tools comfort: ${profileData.digitalToolsComfort}
- Social media knowledge: ${profileData.socialMediaKnowledge}
- Device type: ${profileData.deviceType}
- Investment capacity: ${profileData.investmentCapacity}
- Has storage space: ${profileData.hasStorageSpace}
- OK with deliveries: ${profileData.okWithDeliveries}
- Main reason: ${JSON.stringify(profileData.mainReason)}
- Income goal: ${profileData.incomeGoal}
- Full-time goal: ${profileData.fullTimeGoal}

Generate 3 business ideas that are:
1. Perfectly suited to their skills and constraints
2. Realistic for their location and resources
3. Aligned with their income goals
4. Feasible with their available time and investment capacity

Respond with JSON in exactly this format:
{
  "ideas": [
    {
      "title": "Business Idea Name",
      "description": "2-3 sentence description of the business",
      "opportunityTiming": "Why this is a good time for this business",
      "marketGap": "What gap in the market this addresses",
      "revenuePotential": "Realistic revenue range in ₹ per month",
      "difficultyLevel": "Beginner/Intermediate/Advanced",
      "founderFit": "Why this fits the user's profile specifically",
      "targetPersona": "Who the ideal customers are",
      "startupCosts": "Initial investment required in ₹",
      "timeCommitment": "Hours per week needed"
    }
  ]
}
`;

  try {
    const response = await retryWithBackoff(async () => {
      return await ai.models.generateContent({
        model: "gemini-2.5-flash", // Use flash model instead of pro to reduce quota usage
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              ideas: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    description: { type: "string" },
                    opportunityTiming: { type: "string" },
                    marketGap: { type: "string" },
                    revenuePotential: { type: "string" },
                    difficultyLevel: { type: "string" },
                    founderFit: { type: "string" },
                    targetPersona: { type: "string" },
                    startupCosts: { type: "string" },
                    timeCommitment: { type: "string" }
                  },
                  required: ["title", "description", "opportunityTiming", "marketGap", "revenuePotential", "difficultyLevel", "founderFit", "targetPersona", "startupCosts", "timeCommitment"]
                }
              }
            },
            required: ["ideas"]
          }
        },
        contents: prompt,
      });
    });

    const rawJson = response.text;
    if (rawJson) {
      const data = JSON.parse(rawJson);
      return data.ideas;
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Failed to generate business ideas after retries:", error);
    throw new Error(`Failed to generate business ideas: ${error}`);
  }
}

export async function generateBusinessPlan(profileData: any, selectedIdea: BusinessIdea): Promise<BusinessPlanContent> {
  // Calculate start date and determine duration based on complexity and available time
  const startDate = new Date();
  startDate.setDate(startDate.getDate() + 1); // Start tomorrow

  const availableHours = profileData.availableHours || 10;
  const isComplex = selectedIdea.difficultyLevel === 'Advanced';
  const isIntermediate = selectedIdea.difficultyLevel === 'Intermediate';

  // Determine duration based on complexity and available time
  let daysPlanned = 30; // Default
  if (isComplex || availableHours < 5) {
    daysPlanned = 90;
  } else if (isIntermediate || availableHours < 10) {
    daysPlanned = 60;
  }

  const prompt = `
You are an expert business consultant. Create a comprehensive 19-point business plan for the following business idea, tailored to the user's profile.

Selected Business Idea: ${selectedIdea.title}
Description: ${selectedIdea.description}

User Profile Summary:
- Demographics: ${profileData.age} year old ${profileData.gender}, ${profileData.currentProfession}
- Location: ${profileData.location} (${profileData.locationType})
- Business Location: ${profileData.businessLocation}
- Available Time: ${profileData.availableHours} hours/week
- Investment Capacity: ${profileData.investmentCapacity}
- Skills: ${JSON.stringify(profileData.topSkills)}
- Income Goal: ${profileData.incomeGoal}

IMPORTANT: Create exactly a ${daysPlanned}-day execution plan. Generate tasks for ALL ${daysPlanned} days starting from ${startDate.toISOString().split('T')[0]}.

Create a detailed business plan with:
1. Actionable steps for Indian market
2. Real resource links (YouTube videos, blogs, tools)
3. Specific to their location and constraints
4. ${daysPlanned}-day execution calendar with daily tasks
5. Real success stories and failure cases from similar businesses
6. Compliance requirements for India (GST, licenses, etc.)

The execution calendar MUST have exactly ${daysPlanned} entries, one for each day. Use the format YYYY-MM-DD for dates.

Respond with JSON in exactly this format:
{
  "businessSummary": "1-2 line business description",
  "targetCustomer": "Detailed customer persona with demographics and pain points",
  "problemSolving": "What specific problem this business solves",
  "valueProposition": "Why customers should choose this over alternatives",
  "revenueModel": "How money flows in (pricing, payment methods)",
  "keyActivities": "Daily/weekly activities the founder must do",
  "productService": "Detailed description of what's being sold",
  "channels": "How to reach and sell to customers (specific platforms/methods)",
  "customerRelationships": "How to build trust and retain customers",
  "keyPartnerships": "Suppliers, platforms, collaborators needed",
  "costStructure": "Breakdown of startup and recurring costs",
  "successMetrics": "Specific KPIs to track progress",
  "legalCompliance": "Required licenses, GST, legal requirements for India",
  "toolsResources": "Specific tools and platforms needed with brief descriptions",
  "risks": "Common pitfalls and how to avoid them",
  "exportOptions": "How to share/present this plan",
  "daysPlanned": ${daysPlanned},
  "executionCalendar": [
    ${Array.from({length: Math.min(daysPlanned, 5)}, (_, i) => {
      const taskDate = new Date(startDate);
      taskDate.setDate(taskDate.getDate() + i);
      return `{
      "day": ${i + 1},
      "date": "${taskDate.toISOString().split('T')[0]}",
      "title": "Day ${i + 1} Task",
      "description": "Detailed task description for day ${i + 1}",
      "resourceLinks": [
        {
          "title": "Resource name",
          "url": "https://example.com",
          "type": "youtube"
        }
      ]
    }`;
    }).join(',\n    ')}
    // Continue for all ${daysPlanned} days with proper date progression
  ],
  "successStories": [
    {
      "businessName": "Real business name",
      "description": "What they do and how they succeeded",
      "successFactors": "Key reasons for their success",
      "website": "https://website.com",
      "instagram": "@handle",
      "youtube": "channel name"
    }
  ],
  "failureAnalysis": [
    {
      "businessName": "Failed business name or anonymized",
      "idea": "What they tried to do",
      "failureReasons": "Why they failed",
      "lessons": "What to learn from their failure"
    }
  ]
}
`;

  try {
    const response = await retryWithBackoff(async () => {
      return await ai.models.generateContent({
        model: "gemini-2.5-flash", // Use flash model to reduce quota usage
        config: {
          responseMimeType: "application/json",
        },
        contents: prompt,
      });
    });

    const rawJson = response.text;
    if (rawJson) {
      const data = JSON.parse(rawJson);
      return data;
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    throw new Error(`Failed to generate business plan: ${error}`);
  }
}

export async function generateFinancialPlan(profileData: any, businessPlan: any): Promise<FinancialPlan> {
  console.log("Starting Gemini API call for financial plan generation");
  console.log("Profile data available:", !!profileData);
  console.log("Business plan available:", !!businessPlan);

  // Create a more focused prompt to avoid rate limiting
  const prompt = `
Create a comprehensive financial plan for this Indian side hustle business:

Business: ${businessPlan.title}
Summary: ${businessPlan.businessSummary || 'Not provided'}
Demographics: ${profileData.age} year old ${profileData.gender}, ${profileData.currentProfession}
Location: ${profileData.location}, ${profileData.city}, ${profileData.country} (${profileData.locationType})
Business Location: ${profileData.businessLocation}
Investment Capacity: ${profileData.investmentCapacity}
Income Goal: ${profileData.incomeGoal}
Available Hours: ${profileData.availableHours}/week

Generate specific financial data with realistic Indian market numbers. Use ₹ currency and include GST considerations.

Respond with JSON format:
{
  "revenueModel": "DETAILED REVENUE MODEL:
• Primary Revenue Stream: [specific model - unit sales/subscription/hourly billing]
• Pricing Structure: ₹[amount] per [unit/service/hour]
• Payment Methods: [UPI/Cash/Cards/EMI options]
• Revenue Frequency: [daily/weekly/monthly]
• Seasonal Variations: [festival seasons, monsoon impact, etc.]
• Market Size: [target market size in ₹]
• GST Impact: [rate and calculation]

Example: For pickle business - ₹200 per 500g jar, selling 50 jars/month = ₹10,000 monthly revenue",

  "revenueAssumptions": "REVENUE PROJECTIONS & ASSUMPTIONS:

📊 PRICING ASSUMPTIONS:
• Base Price: ₹[amount] per unit/service
• Market Research: Based on [competitor analysis/market rates]
• Price Growth: [%] annual increase

📈 VOLUME PROJECTIONS:
Month 1-3: [units] per month
Month 4-6: [units] per month (growth rate: [%])
Month 7-12: [units] per month (growth rate: [%])

🎯 CUSTOMER ASSUMPTIONS:
• New customers per month: [number]
• Customer retention rate: [%]
• Average order value: ₹[amount]

📅 SEASONAL FACTORS:
• Peak season: [months] (+[%] increase)
• Low season: [months] (-[%] decrease)
• Festival impact: [specific festivals and impact]

TOTAL YEAR 1 REVENUE: ₹[amount]",

  "fixedMonthlyExpenses": "FIXED MONTHLY EXPENSES BREAKDOWN:

🏢 INFRASTRUCTURE COSTS:
• Rent/Space: ₹[amount]/month
• Utilities (electricity): ₹[amount]/month
• Internet/Phone: ₹[amount]/month
• Storage/Warehouse: ₹[amount]/month

💼 BUSINESS OPERATIONS:
• Software subscriptions: ₹[amount]/month
• Insurance: ₹[amount]/month
• Banking charges: ₹[amount]/month
• Accounting/CA fees: ₹[amount]/month

📝 COMPLIANCE & LEGAL:
• GST filing: ₹[amount]/month
• Trade license renewal: ₹[amount]/month
• Professional fees: ₹[amount]/month

📱 DIGITAL TOOLS:
• Website maintenance: ₹[amount]/month
• Social media tools: ₹[amount]/month
• Payment gateway: ₹[amount]/month

TOTAL FIXED COSTS: ₹[amount]/month
Annual Fixed Costs: ₹[amount]",

  "variableCosts": "VARIABLE COSTS PER UNIT/SERVICE:

🛍️ DIRECT COSTS:
• Raw materials: ₹[amount] per unit ([%] of selling price)
• Packaging: ₹[amount] per unit
• Labor (if applicable): ₹[amount] per unit
• Quality control: ₹[amount] per unit

🚚 DELIVERY & LOGISTICS:
• Local delivery: ₹[amount] per order
• Courier charges: ₹[amount] per shipment
• Packaging materials: ₹[amount] per order
• Return handling: ₹[amount] per return

💳 TRANSACTION COSTS:
• Payment gateway: [%] of transaction value
• UPI charges: ₹[amount] per transaction
• Cash handling: ₹[amount] per cash transaction

📢 MARKETING (Variable):
• Digital ads: [%] of revenue
• Referral bonuses: ₹[amount] per referral
• Promotional materials: ₹[amount] per campaign

TOTAL VARIABLE COST: ₹[amount] per unit
Variable Cost %: [%] of selling price
Gross Margin: [%] per unit",

  "startupCosts": "ONE-TIME STARTUP INVESTMENT:

🏗️ SETUP COSTS:
• Equipment/Machinery: ₹[amount]
• Initial inventory: ₹[amount]
• Furniture & fixtures: ₹[amount]
• Technology setup: ₹[amount]

📋 LEGAL & COMPLIANCE:
• Business registration: ₹[amount]
• GST registration: ₹[amount]
• Trade license: ₹[amount]
• FSSAI (if food): ₹[amount]
• Professional fees: ₹[amount]

🎨 BRANDING & MARKETING:
• Logo & branding: ₹[amount]
• Website development: ₹[amount]
• Initial marketing: ₹[amount]
• Photography: ₹[amount]
• Packaging design: ₹[amount]

💰 WORKING CAPITAL:
• 3-month operating expenses: ₹[amount]
• Initial marketing budget: ₹[amount]
• Emergency fund: ₹[amount]

TOTAL STARTUP COST: ₹[amount]
Minimum Required: ₹[amount]
Recommended Budget: ₹[amount]",

  "loansCapital": "FUNDING & CAPITAL STRUCTURE:

💵 CAPITAL REQUIREMENTS:
• Total startup need: ₹[amount]
• Your investment capacity: ₹[investment capacity from profile]
• Additional funding needed: ₹[amount]

🏦 FUNDING OPTIONS FOR INDIA:

1️⃣ MUDRA LOANS:
• Shishu (up to ₹50,000): [interest rate]% interest
• Kishore (₹50K-₹5L): [interest rate]% interest
• Tarun (₹5L-₹10L): [interest rate]% interest

2️⃣ PRADHAN MANTRI SCHEMES:
• PM SVANidhi (₹10,000): [details]
• Stand-Up India: [if applicable]

3️⃣ DIGITAL LENDING:
• Fintech platforms: [rate]% interest
• Bank personal loans: [rate]% interest
• Gold loans: [rate]% interest

📊 RECOMMENDED STRUCTURE:
• Self-funding: ₹[amount] ([%])
• Loan amount: ₹[amount] ([%])
• Monthly EMI: ₹[amount]
• Loan tenure: [months] months

💡 BOOTSTRAP STRATEGY:
• Start with ₹[amount] minimum
• Reinvest profits for growth
• Scale gradually without debt",

  "profitLossForecast": "5-YEAR PROFIT & LOSS FORECAST:

📊 YEAR 1 (Monthly Breakdown):
Month 1: Revenue ₹[amount] | Expenses ₹[amount] | Profit ₹[amount]
Month 2: Revenue ₹[amount] | Expenses ₹[amount] | Profit ₹[amount]
[...continue for 12 months]

YEAR 1 TOTALS:
• Total Revenue: ₹[amount]
• Total Expenses: ₹[amount]
• Gross Profit: ₹[amount] ([%] margin)
• Net Profit: ₹[amount] ([%] margin)

📈 5-YEAR SUMMARY:
Year 1: Revenue ₹[amount] | Profit ₹[amount] ([%])
Year 2: Revenue ₹[amount] | Profit ₹[amount] ([%])
Year 3: Revenue ₹[amount] | Profit ₹[amount] ([%])
Year 4: Revenue ₹[amount] | Profit ₹[amount] ([%])
Year 5: Revenue ₹[amount] | Profit ₹[amount] ([%])

🎯 KEY RATIOS:
• Revenue Growth: [%] CAGR
• Profit Margin Improvement: [%] to [%]
• ROI: [%] by Year 3
• Payback Period: [months] months",

  "cashFlow": "CASH FLOW ANALYSIS (24 MONTHS):

💰 MONTH-BY-MONTH CASH FLOW:

Month 1:
• Opening Cash: ₹[amount]
• Cash Inflow: ₹[amount]
• Cash Outflow: ₹[amount]
• Closing Cash: ₹[amount]

[Continue for key months...]

🔴 CRITICAL MONTHS:
• Lowest cash point: Month [number] - ₹[amount]
• Cash positive month: Month [number]
• Peak funding requirement: ₹[amount]

📊 CASH FLOW PATTERNS:
• Average monthly inflow: ₹[amount]
• Average monthly outflow: ₹[amount]
• Seasonal cash variations: [%]

⚠️ CASH MANAGEMENT:
• Minimum cash buffer needed: ₹[amount]
• Payment terms impact: [details]
• Collection period: [days] days
• Payment period: [days] days

✅ CASH POSITIVE MILESTONES:
• Break-even month: Month [number]
• Consistent positive: Month [number]
• Target monthly cash: ₹[amount]",

  "breakEvenAnalysis": "BREAK-EVEN ANALYSIS:

🎯 BREAK-EVEN CALCULATIONS:

📊 UNIT ECONOMICS:
• Selling price per unit: ₹[amount]
• Variable cost per unit: ₹[amount]
• Contribution margin: ₹[amount] ([%])

🏢 FIXED COSTS:
• Monthly fixed costs: ₹[amount]
• Annual fixed costs: ₹[amount]

⚖️ BREAK-EVEN POINT:
• Units needed per month: [number] units
• Revenue needed per month: ₹[amount]
• Days to break-even: [number] days
• Break-even month: Month [number]

📈 SCALING ANALYSIS:
• To earn ₹10,000/month: [units] units
• To earn ₹25,000/month: [units] units
• To earn ₹50,000/month: [units] units

🛡️ MARGIN OF SAFETY:
• Current capacity: [units] per month
• Break-even requirement: [units] per month
• Safety margin: [%]
• Risk assessment: [Low/Medium/High]

💡 OPTIMIZATION TIPS:
• Reduce fixed costs by: [suggestions]
• Increase margins by: [suggestions]
• Scale faster by: [suggestions]",

  "insightsWarnings": "FINANCIAL INSIGHTS & WARNINGS:

🚨 RED FLAGS TO WATCH:

1️⃣ CASH FLOW RISKS:
• Months 2-4 show negative cash flow
• Peak funding requirement: ₹[amount]
• Seasonal dips in [months]

2️⃣ COST CONCERNS:
• Variable costs at [%] - industry average [%]
• Fixed costs high for initial scale
• [Specific cost concern]

3️⃣ MARKET RISKS:
• Price sensitivity in target market
• Competition pricing pressure
• Seasonal demand variations

💡 SUCCESS INDICATORS:

✅ POSITIVE SIGNALS:
• Break-even by Month [number]
• Healthy [%] gross margins
• Strong repeat customer potential
• Low customer acquisition cost

📊 KEY METRICS TO TRACK:
• Daily sales volume
• Customer acquisition cost: ₹[amount]
• Customer lifetime value: ₹[amount]
• Monthly recurring revenue
• Inventory turnover ratio

🎯 OPTIMIZATION OPPORTUNITIES:
• Increase prices by [%] after Month [number]
• Reduce material costs through bulk buying
• Automate [process] to reduce labor costs
• Focus on high-margin products/services

⚠️ EARLY WARNING SYSTEM:
• If daily sales < [number] units for 1 week
• If monthly costs exceed ₹[amount]
• If customer complaints > [number] per month",

  "financialReports": "FINANCIAL REPORTING & KPIs:

📊 KEY FINANCIAL RATIOS:

💰 PROFITABILITY RATIOS:
• Gross Profit Margin: [%] (Target: [%])
• Net Profit Margin: [%] (Industry: [%])
• Return on Investment: [%]
• Return on Assets: [%]

🔄 EFFICIENCY RATIOS:
• Inventory Turnover: [number] times/year
• Asset Turnover: [number] times/year
• Working Capital Turnover: [number]

💧 LIQUIDITY RATIOS:
• Current Ratio: [ratio]
• Quick Ratio: [ratio]
• Cash Conversion Cycle: [days] days

📈 GROWTH METRICS:
• Revenue Growth Rate: [%] monthly
• Customer Growth Rate: [%] monthly
• Average Order Value Growth: [%]

🎯 BUSINESS PERFORMANCE BENCHMARKS:

For [Business Type] in India:
• Average Gross Margin: [%]
• Average Net Margin: [%]
• Typical Break-even: [months] months
• Customer Retention: [%]

📋 MONTHLY REPORTING TEMPLATE:
• Revenue vs Target: ₹[amount] vs ₹[amount]
• Cost Control: ₹[amount] vs ₹[amount] budget
• Customer Metrics: [number] new, [%] retention
• Cash Position: ₹[amount] available
• Key Issues: [list]
• Next Month Focus: [priorities]",

  "comparePlanReality": "PLAN vs REALITY TRACKING FRAMEWORK:

📊 MONTHLY REVIEW CHECKLIST:

💰 REVENUE TRACKING:
• Planned Revenue: ₹[amount]
• Actual Revenue: ₹_____ (fill monthly)
• Variance: ____% (acceptable: ±15%)
• Key drivers: [factors affecting variance]

💸 COST TRACKING:
• Planned Fixed Costs: ₹[amount]
• Actual Fixed Costs: ₹_____ 
• Planned Variable Costs: ₹[amount]
• Actual Variable Costs: ₹_____\n• Cost Variance: ____% (target: <10%)

📈 PERFORMANCE METRICS:
• Units Sold: Plan [number] vs Actual ____
• New Customers: Plan [number] vs Actual ____
• Customer Retention: Plan [%] vs Actual ____%
• Average Order Value: Plan ₹[amount] vs Actual ₹____

🎯 QUARTERLY REVIEW POINTS:

✅ WHAT TO MEASURE:
1. Revenue achievement: ____% of target
2. Profit margins: ____% vs planned [%]
3. Cash burn rate: ₹____ vs planned ₹[amount]
4. Customer satisfaction score: ____/10
5. Market response: [qualitative assessment]

🔧 COURSE CORRECTION TRIGGERS:
• Revenue <80% of plan for 2 consecutive months
• Costs >120% of plan for any month
• Customer complaints >5% of orders
• Cash flow negative for >2 months

📋 ACTION PLAN TEMPLATE:
If actual differs from plan by >20%:
1. Identify root cause
2. Adjust pricing/costs/strategy
3. Update forecasts
4. Set new targets
5. Monitor weekly until back on track

💡 SUCCESS INDICATORS:
• Achieving 90%+ of revenue targets
• Maintaining planned cost structure
• Customer growth meeting expectations
• Positive cash flow by planned month",

  "exportSave": "EXPORT & SAVE OPTIONS:

📥 DOWNLOADABLE FINANCIAL PACKAGE INCLUDES:

📊 EXCEL WORKBOOK (Multiple Sheets):
• 5-Year P&L Projections
• Monthly Cash Flow (24 months)
• Break-even Analysis Calculator
• Cost Tracking Templates
• Revenue Projections by Product/Service
• KPI Dashboard
• Scenario Planning Tool (Best/Worst/Realistic)

📄 PDF REPORTS:
• Executive Summary (2 pages)
• Detailed Financial Plan (15 pages)
• Visual Charts & Graphs
• Action Plan Checklist
• Key Ratios & Benchmarks
• Monthly Review Templates

🎯 HOW TO USE THESE PROJECTIONS:

1️⃣ BUSINESS PLANNING:
• Set monthly revenue targets
• Plan inventory and resources
• Decide on hiring and expansion
• Apply for loans with solid projections

2️⃣ DAILY OPERATIONS:
• Track actual vs planned performance
• Make pricing decisions
• Control costs effectively
• Plan cash flow needs

3️⃣ INVESTOR/LENDER PRESENTATIONS:
• Professional financial projections
• Risk analysis and mitigation
• Growth potential demonstration
• Return on investment calculations

💼 PROFESSIONAL FEATURES:
• Editable templates for ongoing use
• Formulas for real-time updates
• Indian tax and compliance considerations
• Industry-specific benchmarks
• Seasonal adjustment factors

🔄 REGULAR UPDATES:
• Monthly actual vs plan comparison
• Quarterly forecast updates
• Annual strategy reviews
• Market condition adjustments

✅ READY FOR:
• Bank loan applications
• Investor pitches
• Business plan competitions
• Government scheme applications
• Partnership discussions"
}
`;

  try {
    console.log("Calling Gemini API with prompt length:", prompt.length);
    const response = await retryWithBackoff(async () => {
      console.log("Making API call to Gemini...");
      return await ai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              revenueModel: { type: "string" },
              revenueAssumptions: { type: "string" },
              fixedMonthlyExpenses: { type: "string" },
              variableCosts: { type: "string" },
              startupCosts: { type: "string" },
              loansCapital: { type: "string" },
              profitLossForecast: { type: "string" },
              cashFlow: { type: "string" },
              breakEvenAnalysis: { type: "string" },
              insightsWarnings: { type: "string" },
              financialReports: { type: "string" },
              comparePlanReality: { type: "string" },
              exportSave: { type: "string" }
            },
            required: ["revenueModel", "revenueAssumptions", "fixedMonthlyExpenses", "variableCosts", "startupCosts", "loansCapital", "profitLossForecast", "cashFlow", "breakEvenAnalysis", "insightsWarnings", "financialReports", "comparePlanReality", "exportSave"]
          }
        },
        contents: prompt,
      });
    });

    const rawJson = response.text;
    console.log("Gemini API response received, length:", rawJson?.length || 0);
    if (rawJson) {
      const data = JSON.parse(rawJson);
      console.log("Generated financial plan data keys:", Object.keys(data));
      console.log("Sample data check - revenueModel exists:", !!data.revenueModel);
      return data;
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Failed to generate financial plan, using fallback:", error);

    // Provide comprehensive fallback data based on the business plan
    const fallbackData: FinancialPlan = {
      revenueModel: `REVENUE MODEL FOR ${businessPlan.title?.toUpperCase() || 'YOUR BUSINESS'}:

• Primary Revenue Stream: ${getRevenueStreamType(businessPlan.title)}
• Pricing Structure: ₹500-2,000 per unit/service (market competitive)
• Payment Methods: UPI (60%), Cash (25%), Bank Transfer (15%)
• Revenue Frequency: Daily sales with weekly collections
• Seasonal Variations: Festival seasons (+30%), Monsoon impact (-10%)
• Market Size: Local market ₹50,000-2,00,000 monthly potential
• GST Impact: 18% for services, 5-12% for products

TARGET MONTHLY REVENUE: ₹${profileData.incomeGoal || '25,000'}`,

      revenueAssumptions: `REVENUE PROJECTIONS FOR ${profileData.location}:

📊 PRICING ASSUMPTIONS:
• Base Price: ₹750 per unit/service
• Market Research: Based on local competitor rates
• Price Growth: 10% annual increase

📈 VOLUME PROJECTIONS:
Month 1-3: 20 units per month (startup phase)
Month 4-6: 35 units per month (growth rate: 25%)
Month 7-12: 50+ units per month (growth rate: 15%)

🎯 CUSTOMER ASSUMPTIONS:
• New customers per month: 8-12
• Customer retention rate: 65%
• Average order value: ₹750
• Repeat customer rate: 40%

📅 SEASONAL FACTORS:
• Peak season: Oct-Dec, Mar-May (+25% increase)
• Low season: Jun-Sep (-15% decrease)
• Festival impact: Diwali, Holi, regional festivals (+30%)

TOTAL YEAR 1 REVENUE: ₹${parseInt(profileData.incomeGoal || '25000') * 12 || '3,00,000'}`,

      fixedMonthlyExpenses: `FIXED MONTHLY EXPENSES FOR ${profileData.location}:

🏢 INFRASTRUCTURE COSTS:
• Rent/Space: ₹3,000-8,000/month (depending on location)
• Utilities (electricity): ₹800-1,500/month
• Internet/Phone: ₹500-800/month
• Storage/Tools: ₹500-1,000/month

💼 BUSINESS OPERATIONS:
• Software subscriptions: ₹200-500/month
• Insurance: ₹300-600/month
• Banking charges: ₹100-300/month
• Accounting/CA fees: ₹500-1,000/month

📝 COMPLIANCE & LEGAL:
• GST filing: ₹300-600/month
• Trade license renewal: ₹50-100/month
• Professional fees: ₹200-500/month

📱 DIGITAL PRESENCE:
• Website maintenance: ₹200-500/month
• Social media tools: ₹100-300/month
• Payment gateway: 2-3% of transactions

TOTAL FIXED COSTS: ₹6,000-12,000/month
Recommended Budget: ₹8,000/month`,

      variableCosts: `VARIABLE COSTS PER UNIT/SERVICE:

🛍️ DIRECT COSTS:
• Raw materials: ₹150-250 per unit (20-35% of selling price)
• Packaging: ₹25-50 per unit
• Labor (if applicable): ₹50-100 per unit
• Quality control: ₹10-20 per unit

🚚 DELIVERY & LOGISTICS:
• Local delivery: ₹30-60 per order
• Courier charges: ₹40-100 per shipment
• Packaging materials: ₹15-30 per order
• Return handling: ₹25-50 per return

💳 TRANSACTION COSTS:
• Payment gateway: 2-3% of transaction value
• UPI charges: ₹0-5 per transaction
• Cash handling: ₹5-10 per cash transaction

📢 MARKETING (Variable):
• Digital ads: 5-10% of revenue
• Referral bonuses: ₹50-100 per referral
• Promotional materials: ₹20-40 per campaign

TOTAL VARIABLE COST: ₹300-500 per unit
Variable Cost %: 40-65% of selling price
Gross Margin: 35-60% per unit`,

      startupCosts: `ONE-TIME STARTUP INVESTMENT:

🏗️ SETUP COSTS:
• Equipment/Tools: ₹5,000-25,000
• Initial inventory: ₹3,000-15,000
• Furniture & fixtures: ₹2,000-10,000
• Technology setup: ₹3,000-12,000

📋 LEGAL & COMPLIANCE:
• Business registration: ₹1,000-3,000
• GST registration: ₹500-1,000
• Trade license: ₹500-2,000
• FSSAI (if food): ₹1,000-3,000
• Professional fees: ₹2,000-5,000

🎨 BRANDING & MARKETING:
• Logo & branding: ₹2,000-8,000
• Website development: ₹5,000-20,000
• Initial marketing: ₹3,000-10,000
• Photography: ₹1,000-5,000
• Packaging design: ₹1,500-6,000

💰 WORKING CAPITAL:
• 3-month operating expenses: ₹18,000-36,000
• Initial marketing budget: ₹5,000-15,000
• Emergency fund: ₹10,000-25,000

TOTAL STARTUP COST: ₹${calculateStartupCost(profileData.investmentCapacity)}
Your Budget: ₹${profileData.investmentCapacity}`,

      loansCapital: `FUNDING OPTIONS FOR INDIAN ENTREPRENEURS:

💵 CAPITAL REQUIREMENTS:
• Total startup need: ₹${calculateStartupCost(profileData.investmentCapacity)}
• Your investment capacity: ₹${profileData.investmentCapacity}
• Additional funding needed: ₹${Math.max(0, parseInt(calculateStartupCost(profileData.investmentCapacity).replace(/,/g, '')) - parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '0'))}

🏦 GOVERNMENT SCHEME OPTIONS:

1️⃣ MUDRA LOANS (Most Suitable):
• Shishu (up to ₹50,000): 8-10% interest, No collateral
• Kishore (₹50K-₹5L): 9-11% interest, Minimal documentation
• Tarun (₹5L-₹10L): 10-12% interest, Business plan required

2️⃣ PRADHAN MANTRI SCHEMES:
• PM SVANidhi (₹10,000): 7% interest for street vendors
• Stand-Up India (₹10L-₹1Cr): For women/SC/ST entrepreneurs

3️⃣ DIGITAL LENDING OPTIONS:
• Fintech platforms: 12-24% interest (quick approval)
• Bank personal loans: 11-16% interest
• Gold loans: 8-12% interest (against gold)

📊 RECOMMENDED STRUCTURE:
• Self-funding: ₹${profileData.investmentCapacity} (${Math.round((parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '0') / parseInt(calculateStartupCost(profileData.investmentCapacity).replace(/,/g, ''))) * 100)}%)
• MUDRA loan: ₹${Math.min(50000, Math.max(0, parseInt(calculateStartupCost(profileData.investmentCapacity).replace(/,/g, '')) - parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '0')))}
• Monthly EMI: ₹${Math.round(Math.min(50000, Math.max(0, parseInt(calculateStartupCost(profileData.investmentCapacity).replace(/,/g, '')) - parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '0'))) * 0.05)}

💡 BOOTSTRAP STRATEGY:
Start with minimum viable setup and reinvest profits for growth.`,

      profitLossForecast: `12-MONTH PROFIT & LOSS FORECAST:

📊 MONTHLY BREAKDOWN (Year 1):
Month 1: Revenue ₹8,000 | Expenses ₹12,000 | Loss (₹4,000)
Month 2: Revenue ₹12,000 | Expenses ₹11,000 | Profit ₹1,000
Month 3: Revenue ₹15,000 | Expenses ₹11,500 | Profit ₹3,500
Month 4-6: Revenue ₹18,000-25,000 | Profit ₹6,000-12,000
Month 7-12: Revenue ₹25,000-35,000 | Profit ₹12,000-20,000

📈 QUARTERLY SUMMARY:
Q1: Revenue ₹35,000 | Expenses ₹34,500 | Profit ₹500
Q2: Revenue ₹65,000 | Expenses ₹36,000 | Profit ₹29,000
Q3: Revenue ₹80,000 | Expenses ₹38,000 | Profit ₹42,000
Q4: Revenue ₹95,000 | Expenses ₹40,000 | Profit ₹55,000

YEAR 1 TOTALS:
• Total Revenue: ₹2,75,000
• Total Expenses: ₹1,48,500
• Gross Profit: ₹1,26,500 (46% margin)
• Net Profit: ₹1,26,500 (46% margin)

🎯 KEY RATIOS:
• Break-even month: Month 2
• Positive cash flow: Month 3
• ROI: 180% by Year 1
• Monthly growth rate: 15-25%`,

      cashFlow: `24-MONTH CASH FLOW ANALYSIS:

💰 CRITICAL FIRST 6 MONTHS:

Month 1:
• Opening Cash: ₹${profileData.investmentCapacity || '25,000'}
• Cash Inflow: ₹8,000
• Cash Outflow: ₹15,000
• Closing Cash: ₹${(parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '25000') + 8000 - 15000)}

Month 2:
• Opening Cash: ₹${(parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '25000') + 8000 - 15000)}
• Cash Inflow: ₹12,000
• Cash Outflow: ₹11,000
• Closing Cash: ₹${(parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '25000') + 8000 - 15000 + 12000 - 11000)}

🔴 CRITICAL MONTHS:
• Lowest cash point: Month 1 - ₹${(parseInt(profileData.investmentCapacity?.replace(/[^\d]/g, '') || '25000') + 8000 - 15000)}
• Cash positive month: Month 2
• Peak funding requirement: ₹35,000

📊 CASH FLOW PATTERNS:
• Average monthly inflow: ₹22,000 (after Month 3)
• Average monthly outflow: ₹12,000
• Seasonal cash variations: 25-30%

⚠️ CASH MANAGEMENT TIPS:
• Minimum cash buffer needed: ₹10,000
• Payment terms: 50% advance, 50% on delivery
• Collection period: 7-15 days
• Payment period: 30 days to suppliers

✅ MILESTONES:
• Break-even month: Month 2
• Consistent positive: Month 3
• Target monthly cash: ₹15,000+`,

      breakEvenAnalysis: `BREAK-EVEN ANALYSIS:

🎯 UNIT ECONOMICS:
• Selling price per unit: ₹750
• Variable cost per unit: ₹350
• Contribution margin: ₹400 (53%)

🏢 FIXED COSTS:
• Monthly fixed costs: ₹8,000
• Annual fixed costs: ₹96,000

⚖️ BREAK-EVEN CALCULATIONS:
• Units needed per month: 20 units
• Revenue needed per month: ₹15,000
• Days to break-even: 45-60 days
• Break-even month: Month 2

📈 SCALING TARGETS:
• To earn ₹10,000/month: 25 units (₹18,750 revenue)
• To earn ₹25,000/month: 45 units (₹33,750 revenue)
• To earn ₹50,000/month: 70 units (₹52,500 revenue)

🛡️ MARGIN OF SAFETY:
• Current capacity: 100 units per month
• Break-even requirement: 20 units per month
• Safety margin: 80% (Very Safe)
• Risk assessment: Low Risk

💡 OPTIMIZATION OPPORTUNITIES:
• Reduce fixed costs by: Working from home initially
• Increase margins by: Premium product variants
• Scale faster by: Digital marketing and referrals

🎯 SUCCESS METRICS:
If you can sell 1 unit per day consistently, you'll be profitable!`,

      insightsWarnings: `FINANCIAL INSIGHTS & RED FLAGS:

🚨 KEY RISKS TO MONITOR:

1️⃣ CASH FLOW RISKS:
• Month 1 will be challenging - have ₹15,000 buffer ready
• Seasonal dips during monsoon (Jun-Sep)
• Customer payment delays during festival seasons

2️⃣ COST CONCERNS:
• Variable costs at 47% - industry average 45%
• Fixed costs manageable but monitor utilities
• Marketing costs can escalate quickly - track ROI

3️⃣ MARKET RISKS:
• Price sensitivity in Indian market
• Competition pricing pressure
• Economic slowdown impact on discretionary spending

💡 SUCCESS INDICATORS:

✅ POSITIVE SIGNALS:
• Break-even by Month 2 (achievable)
• Healthy 53% gross margins
• Strong repeat customer potential in India
• Low customer acquisition cost

📊 WEEKLY TRACKING METRICS:
• Daily sales target: 1-2 units
• Weekly revenue target: ₹5,000-8,000
• Customer acquisition: 2-3 new customers/week
• Cost control: Stay within ₹2,500/week expenses

🎯 MONTHLY REVIEW POINTS:
• Revenue growth: Target 15-20% month-over-month
• Cost management: Keep variable costs under 50%
• Customer satisfaction: Maintain 4.5+ rating
• Cash position: Always keep ₹10,000+ buffer

⚠️ IMMEDIATE ACTION TRIGGERS:
• If weekly sales < 3 units for 2 consecutive weeks
• If monthly costs exceed ₹12,000
• If customer complaints > 2 per month
• If cash balance falls below ₹5,000

💼 GROWTH OPPORTUNITIES:
• Add premium variants after Month 6
• Explore B2B sales channels
• Consider franchise/partnership models
• Leverage digital platforms for expansion`,

      financialReports: `FINANCIAL REPORTING & KPI DASHBOARD:

📊 KEY PERFORMANCE INDICATORS:

💰 PROFITABILITY METRICS:
• Gross Profit Margin: 53% (Target: 50%+)
• Net Profit Margin: 46% (Industry: 35-40%)
• Return on Investment: 180% annually
• Revenue per customer: ₹750-1,200

🔄 OPERATIONAL EFFICIENCY:
• Inventory Turnover: 12 times/year (Monthly rotation)
• Customer Acquisition Cost: ₹150-250
• Customer Lifetime Value: ₹2,500-4,000
• Order fulfillment time: 2-3 days

💧 FINANCIAL HEALTH:
• Current Ratio: 2.5:1 (Healthy)
• Debt-to-Equity: 0.3:1 (Conservative)
• Cash Conversion Cycle: 15 days
• Working Capital: ₹25,000+

📈 GROWTH METRICS:
• Monthly Revenue Growth: 15-25%
• Customer Base Growth: 10-15% monthly
• Market Share (local): 5-10%
• Average Order Value Growth: [%]

🎯 INDIAN MARKET BENCHMARKS:
For similar businesses in India:
• Average Gross Margin: 45-50%
• Average Net Margin: 25-35%
• Typical Break-even: 3-6 months
• Customer Retention: 60-70%

📋 MONTHLY REPORTING TEMPLATE:
✅ Revenue Achievement: ___% of ₹${profileData.incomeGoal || '25,000'} target
✅ Cost Control: ₹___ vs ₹8,000 budget
✅ New Customers: ___ (Target: 8-12)
✅ Retention Rate: __% (Target: 65%+)
✅ Cash Position: ₹___ available
✅ Key Challenges: _______________
✅ Next Month Focus: _____________

📱 DIGITAL TOOLS FOR TRACKING:
• Accounting: Zoho Books/TallyPrime
• Inventory: Excel/Google Sheets
• Customer tracking: WhatsApp Business
• Payment tracking: UPI transaction history`,

      comparePlanReality: `PLAN vs REALITY TRACKING SYSTEM:

📋 WEEKLY REVIEW CHECKLIST:

💰 REVENUE TRACKING:
Planned Weekly Revenue: ₹${Math.round((parseInt(profileData.incomeGoal || '25000')) / 4.33)}
Actual Weekly Revenue: ₹_____ (Fill each week)
Variance: ____% (Acceptable range: ±20%)

📊 Key Performance Indicators:
• Units Sold: Plan 5-7/week vs Actual ____
• New Customers: Plan 2-3/week vs Actual ____
• Average Order Value: Plan ₹750 vs Actual ₹____
• Customer Retention: Plan 65% vs Actual ____%

💸 COST MONITORING:
• Weekly Fixed Costs: Plan ₹2,000 vs Actual ₹____
• Weekly Variable Costs: Plan ₹1,750 vs Actual ₹____
• Marketing Spend: Plan ₹500 vs Actual ₹____
• Total Weekly Costs: Plan ₹4,250 vs Actual ₹____

🎯 MONTHLY PERFORMANCE REVIEW:

📈 GROWTH METRICS (Month ___):
1. Revenue achievement: ____% of ₹${profileData.incomeGoal || '25,000'} target
2. Profit margins: ____% vs planned 46%
3. Customer acquisition: ____ vs target 10
4. Cash flow: ₹____ vs planned ₹15,000+
5. Market feedback: ____/10 rating

🔧 COURSE CORRECTION TRIGGERS:
RED FLAGS - Take immediate action if:
• Revenue <75% of target for 2 consecutive weeks
• Costs >125% of plan for any month  
• Customer satisfaction <4/5 rating
• Cash flow negative for >15 days
• No new customers for 1+ weeks

📋 ACTION PLAN TEMPLATE:
When actual differs from plan by >25%:

STEP 1: ROOT CAUSE ANALYSIS
• Market factors: ________________
• Internal factors: _______________
• Competition impact: ____________

STEP 2: IMMEDIATE ACTIONS
• Pricing adjustments: ___________
• Cost optimization: ____________
• Marketing strategy: ___________

STEP 3: UPDATED PROJECTIONS
• Revised monthly target: ₹______
• New customer target: ____ 
• Updated cost budget: ₹_______

STEP 4: MONITORING PLAN
• Daily tracking for next 2 weeks
• Weekly reviews until back on track
• Monthly strategy updates

💡 SUCCESS INDICATORS:
🟢 GREEN: 90%+ of targets met consistently
🟡 YELLOW: 75-89% of targets (needs attention)
🔴 RED: <75% of targets (immediate action required)

📊 QUARTERLY BUSINESS REVIEW:
Review every 3 months:
• Market position assessment
• Competitive landscape changes
• Financial performance vs industry
• Growth opportunities identification
• Strategic plan updates`,

      exportSave: `COMPREHENSIVE FINANCIAL TOOLKIT:

📥 DOWNLOADABLE PACKAGE INCLUDES:

📊 EXCEL FINANCIAL MODEL:
• 12-Month P&L Projections (Monthly breakdown)
• 24-Month Cash Flow Analysis
• Break-even Calculator with scenarios
• Cost Tracking Templates (Fixed & Variable)
• Revenue Forecasting by Product/Service
• KPI Dashboard with Indian benchmarks
• GST Calculation Templates
• Loan EMI Calculator (MUDRA/Bank loans)

📄 PROFESSIONAL REPORTS:
• Executive Summary (2-page investor-ready)
• Detailed Financial Plan (15-page comprehensive)
• Visual Charts & Graphs (Revenue, costs, growth)
• Monthly Review Templates
• Key Ratios & Industry Benchmarks
• Risk Analysis & Mitigation Plans

💼 BUSINESS TEMPLATES:
• Monthly Budget Planner
• Customer Acquisition Cost Calculator
• Inventory Management Tracker
• Seasonal Sales Forecasting Tool
• Competitor Pricing Analysis Template
• Marketing ROI Calculator

🎯 HOW TO USE THESE PROJECTIONS:

1️⃣ DAILY OPERATIONS:
• Set daily sales targets (1-2 units)
• Track actual vs planned performance
• Monitor cost control (daily spend limit)
• Manage cash flow needs

2️⃣ BUSINESS PLANNING:
• Monthly revenue target setting
• Inventory planning and procurement
• Hiring decisions and timing
• Expansion planning (new products/locations)

3️⃣ FUNDING APPLICATIONS:
• Bank loan presentations (MUDRA/Commercial)
• Investor pitch decks
• Government scheme applications
• Partnership proposals

📱 MOBILE-FRIENDLY TRACKING:
• WhatsApp Business integration templates
• Google Sheets mobile tracking
• UPI payment reconciliation formats
• Customer feedback tracking forms

🔄 REGULAR UPDATE SCHEDULE:
• Daily: Sales and expense tracking
• Weekly: Cash flow and customer metrics
• Monthly: Full financial review and forecasting
• Quarterly: Strategy review and market analysis

✅ COMPLIANCE READY:
• GST return preparation templates
• Income Tax calculation worksheets
• TDS tracking (if applicable)
• Audit trail maintenance
• Statutory compliance checklist

💡 BONUS TOOLS:
• Seasonal business planning calendar
• Festival season revenue boost strategies
• Cost optimization checklists
• Emergency fund calculation tools
• Growth milestone celebration tracker

🎓 LEARNING RESOURCES:
• Financial literacy guides for entrepreneurs
• Indian tax compliance basics
• Digital payment optimization tips
• Customer retention strategies
• Scaling business finance management`
    };

    return fallbackData;
  }

  // Helper function to determine revenue stream
  function getRevenueStreamType(title: string): string {
    if (!title) return "Service-based billing";
    const titleLower = title.toLowerCase();
    if (titleLower.includes('pickle') || titleLower.includes('food') || titleLower.includes('product')) {
      return "Unit sales model";
    } else if (titleLower.includes('coaching') || titleLower.includes('consulting') || titleLower.includes('service')) {
      return "Hourly/project billing";
    } else if (titleLower.includes('subscription') || titleLower.includes('membership')) {
      return "Subscription model";
    }
    return "Service-based billing";
  }

  // Helper function to calculate startup cost
  function calculateStartupCost(investmentCapacity: string): string {
    const capacity = parseInt(investmentCapacity?.replace(/[^\d]/g, '') || '25000');
    if (capacity < 10000) return "15,000";
    if (capacity < 25000) return "35,000";
    if (capacity < 50000) return "65,000";
    return "1,00,000";
  }
}

export async function generateMarketingPlan(profileData: any, businessPlan: any, financialPlan?: any): Promise<MarketingPlan> {
  console.log("Starting Gemini API call for marketing plan generation");
  console.log("Profile data available:", !!profileData);
  console.log("Business plan available:", !!businessPlan);
  console.log("Financial plan available:", !!financialPlan);

  const prompt = `
Create a comprehensive marketing plan for this Indian side hustle business:

Business: ${businessPlan.title}
Summary: ${businessPlan.businessSummary || 'Not provided'}
Target Customer: ${businessPlan.targetCustomer || 'Not provided'}
Value Proposition: ${businessPlan.valueProposition || 'Not provided'}
Demographics: ${profileData.age} year old ${profileData.gender}, ${profileData.currentProfession}
Location: ${profileData.location}, ${profileData.city}, ${profileData.country} (${profileData.locationType})
Business Location: ${profileData.businessLocation}
Available Hours: ${profileData.availableHours}/week
Age Group: ${profileData.ageGroup}
Skills: ${JSON.stringify(profileData.topSkills)}
Investment Capacity: ${profileData.investmentCapacity}
Income Goal: ${profileData.incomeGoal}
Social Media Knowledge: ${profileData.socialMediaKnowledge}
Digital Tools Comfort: ${profileData.digitalToolsComfort}

Generate specific marketing recommendations with realistic Indian market strategies. All content should be culturally relevant and use Indian context, examples, and references.

Respond with JSON format:
{
  "brandVoiceMessaging": "🎯 BRAND VOICE & MESSAGING:

📢 RECOMMENDED TONE:
[Tone description based on business type and target audience]

💬 BRAND VOICE CHARACTERISTICS:
• Primary Voice: [e.g., Friendly Expert, Trustworthy Guide, Enthusiastic Helper]
• Communication Style: [e.g., Simple Hindi-English mix, Professional but approachable]
• Personality Traits: [3-4 key traits]

🗣️ KEY MESSAGE PILLARS:

Pillar 1: [Core message theme]
• Example: "[Sample message]"
• Use when: [When to use this message]

Pillar 2: [Second message theme]
• Example: "[Sample message]"
• Use when: [When to use this message]

Pillar 3: [Third message theme]
• Example: "[Sample message]"
• Use when: [When to use this message]

🏷️ TAGLINE SUGGESTIONS:
• Option 1: "[Hindi/English tagline]"
• Option 2: "[Hindi/English tagline]"
• Option 3: "[Hindi/English tagline]"

📝 SAMPLE BRAND STATEMENTS:
• About Us: "[2-3 line about statement]"
• Why Choose Us: "[Key differentiator statement]"
• Customer Promise: "[What you guarantee customers]"",

  "recommendedChannels": "🚀 RECOMMENDED MARKETING CHANNELS:

1️⃣ PRIMARY CHANNEL: [Most important channel]
📱 Platform: [Specific platform name]
🎯 Why Perfect for You:
• [Reason 1 specific to their business]
• [Reason 2 specific to their demographics]
• [Reason 3 specific to their goals]
📊 Expected Results: [Realistic expectations]
💰 Cost: [Free/Low cost details]

2️⃣ SECONDARY CHANNEL: [Second most important]
📱 Platform: [Specific platform name]
🎯 Why It Works:
• [Reason 1]
• [Reason 2]
• [Reason 3]
📊 Expected Results: [Realistic expectations]
💰 Cost: [Cost breakdown]

3️⃣ SUPPORTING CHANNEL: [Third channel]
📱 Platform: [Specific platform name]
🎯 Strategic Use:
• [How to use this channel]
• [Integration with other channels]
📊 Expected Results: [What to expect]
💰 Cost: [Investment needed]

4️⃣ LOCAL OUTREACH: [Offline/community channel]
📍 Method: [Specific local approach]
🎯 Why Effective:
• [Local market advantage]
• [Community building aspect]
📊 Expected Results: [Local impact]
💰 Cost: [Minimal investment details]

5️⃣ WORD-OF-MOUTH: [Referral strategy]
👥 Approach: [How to encourage referrals]
🎯 Implementation:
• [Specific referral tactics]
• [Incentive structures]
📊 Expected Results: [Organic growth potential]
💰 Cost: [Referral costs if any]",

  "contentPlanIdeas": "📱 CONTENT PLAN & POST IDEAS:

🎬 INSTAGRAM/FACEBOOK POSTS:

Post Idea 1: [Content type - e.g., Behind-the-scenes]
📝 Caption: "[Complete caption in Hindi-English mix with relevant hashtags]"
📸 Visual: [Description of image/video needed]
🎯 Goal: [What this post achieves]

Post Idea 2: [Content type - e.g., Customer testimonial]
📝 Caption: "[Complete caption with local references]"
📸 Visual: [Visual description]
🎯 Goal: [Post objective]

Post Idea 3: [Content type - e.g., Educational tip]
📝 Caption: "[Helpful caption with actionable advice]"
📸 Visual: [Visual requirements]
🎯 Goal: [Educational value]

Post Idea 4: [Content type - e.g., Festival/seasonal]
📝 Caption: "[Festival-themed caption relevant to Indian festivals]"
📸 Visual: [Festive visual ideas]
🎯 Goal: [Seasonal engagement]

Post Idea 5: [Content type - e.g., Process video]
📝 Caption: "[Process explanation with local language mix]"
📸 Visual: [Video/carousel description]
🎯 Goal: [Trust building]

📱 WHATSAPP STATUS IDEAS:

Status 1: [Quick tip format]
Status 2: [Customer highlight]
Status 3: [Behind-the-scenes moment]
Status 4: [Motivational quote related to business]
Status 5: [Special offer announcement]

📄 LOCAL FLYER/POSTER IDEAS:

Flyer 1: [Service introduction]
• Headline: "[Catchy Hindi/English headline]"
• Key points: [3-4 bullet points]
• Contact: [How to reach]

Flyer 2: [Special offer]
• Headline: "[Offer headline]"
• Details: [Offer specifics]
• Call-to-action: [What customer should do]

📞 GOOGLE MY BUSINESS POSTS:

Update 1: [Business milestone]
Update 2: [Customer feature]
Update 3: [Service highlight]
Update 4: [Seasonal special]
Update 5: [Educational content]",

  "first50CustomersStrategy": "👥 FIRST 50 CUSTOMERS ACQUISITION STRATEGY:

🎯 GOAL: Get 50 paying customers in [realistic timeframe based on business]

📅 PHASE 1: Foundation (Days 1-14)
🎯 Target: 5-8 customers

Week 1 Actions:
• Day 1-2: Set up WhatsApp Business with professional profile
• Day 3-4: Create basic social media profiles (Instagram/Facebook)
• Day 5-7: Reach out to immediate network (family/friends) - Target: 3 customers

Week 2 Actions:
• Day 8-10: Post daily content showcasing your service/product
• Day 11-12: Contact extended network (neighbors, colleagues) - Target: 2-3 customers
• Day 13-14: Ask first customers for reviews and referrals

📅 PHASE 2: Local Expansion (Days 15-35)
🎯 Target: 15-20 customers

Week 3-4 Actions:
• Join local WhatsApp groups relevant to your service
• Distribute flyers in your neighborhood (if applicable)
• Partner with local shops for cross-referrals
• Target: 8-10 new customers

Week 5 Actions:
• Launch referral program (offer discount for referrals)
• Create Google My Business listing
• Post customer testimonials
• Target: 5-7 new customers

📅 PHASE 3: Digital Growth (Days 36-60)
🎯 Target: 20-25 customers

Week 6-7 Actions:
• Increase social media posting frequency
• Run small paid ads (₹500-1000 budget)
• Collaborate with local influencers/bloggers
• Target: 12-15 new customers

Week 8-9 Actions:
• Optimize based on what's working best
• Expand to additional platforms if needed
• Launch customer loyalty program
• Target: 8-10 new customers

📊 WEEKLY TRACKING:
• New customers acquired: ____
• Conversion rate: ____% 
• Customer acquisition cost: ₹____
• Revenue generated: ₹____
• Next week's target: ____

🎯 SUCCESS ACCELERATORS:
• Always ask satisfied customers for referrals
• Respond to all inquiries within 2 hours
• Maintain consistent posting schedule
• Collect and showcase customer testimonials
• Follow up with prospects who didn't convert initially",

  "outreachScripts": "💬 OUTREACH SCRIPTS & TEMPLATES:

📱 INITIAL DM SCRIPTS:

Script 1: Personal Network
\"Hi [Name]! Hope you're doing well! 😊
I've recently started [business description] and thought you might find it useful. [Brief value proposition].
Would love to help you with [specific benefit]. 
Can I share some details? No pressure at all! 🙏\"

Script 2: Local Community Groups
\"Hello everyone! 👋
I'm [Your name] from [Location]. I've started [business] to help [target audience] with [problem you solve].
[Brief credibility/experience statement]
If anyone needs [service/product], feel free to DM me. Happy to help! 😊
[Contact details]\"

Script 3: Potential Customers (Cold Outreach)
\"Hi [Name]!
I noticed you [relevant observation about their need/business].
I help [target audience] with [specific solution]. 
For example, [quick success story or benefit].
Would you be interested in learning how this could help you too?
No obligation - just sharing in case it's useful! 🙂\"

📞 PHONE SCRIPT:
\"Hello [Name], this is [Your name]. 
I'm calling because [reason - referral/saw their business/etc.]
I help [target audience] with [main benefit] in just [timeframe].
For instance, [quick example or result].
Would you have 2 minutes for me to explain how this could help you?\"

💌 FOLLOW-UP SCRIPTS:

Follow-up 1 (After 3 days):
\"Hi [Name]! 😊
Just wanted to follow up on my previous message about [service/product].
I understand you're probably busy! 
If you're still interested, I'm happy to answer any questions.
Otherwise, no worries at all! 🙏\"

Follow-up 2 (After 1 week):
\"Hi [Name]!
I hope you're having a great week! 
I wanted to share a quick success story: [brief customer result]
This reminded me of our earlier conversation.
If you'd like to explore how this could work for you, I'm here to help!
Otherwise, I'll stop following up. Thanks for your time! 😊\"

Follow-up 3 (Final - After 2 weeks):
\"Hi [Name],
I don't want to be a bother, so this will be my last message about [service/product].
The offer stands if you ever need [main benefit].
Wishing you all the best with [their business/goals]! 🙏
Feel free to reach out anytime.\"

🙏 THANK YOU SCRIPTS:

After Purchase:
\"Thank you so much for choosing [business name]! 🙏😊
I'm excited to [deliver service/product] for you.
Your trust means everything to me.
I'll make sure you get the best results possible!
If you have any questions, I'm just a message away. 📱\"

After Positive Review:
\"Wow! Thank you for that amazing review! 🤩
It truly made my day and means so much for my small business.
Customers like you inspire me to keep giving my best.
If you know anyone else who might benefit from [service], I'd be grateful for the referral! 🙏\"

After Referral:
\"Hi [Name]!
I just wanted to say a huge THANK YOU for referring [referred person's name] to me! 🙏
Your trust in recommending my [service/product] means the world.
As a small token of appreciation, [mention any referral benefit].
You're amazing! 😊\"",

  "toolsResources": "🛠️ MARKETING TOOLS & RESOURCES:

📱 FREE DESIGN TOOLS:

1️⃣ CANVA (Design Graphics)
🔗 Website: canva.com
💡 Use For: Social media posts, flyers, logos, banners
📚 Tutorial: \"Canva for Beginners in Hindi\" on YouTube
💰 Cost: Free (Pro: ₹500/month)
⭐ Why Perfect: Templates in Hindi, Indian festival designs

2️⃣ INSHOT (Video Editing)
🔗 App: InShot Video Editor (Android/iOS)
💡 Use For: Instagram Reels, story videos, promotional videos
📚 Tutorial: Search \"InShot tutorial Hindi\" on YouTube
💰 Cost: Free with watermark (Pro: ₹200/month)
⭐ Why Perfect: Easy mobile editing, trending effects

3️⃣ REMOVE.BG (Background Removal)
🔗 Website: remove.bg
💡 Use For: Product photos, professional headshots
📚 Tutorial: Built-in, very simple
💰 Cost: Free for low-resolution (HD: ₹900/month)
⭐ Why Perfect: One-click background removal

📊 SOCIAL MEDIA MANAGEMENT:

4️⃣ BUFFER (Post Scheduling)
🔗 Website: buffer.com
💡 Use For: Schedule posts across platforms
📚 Tutorial: \"Buffer tutorial for small business\"
💰 Cost: Free for 3 platforms (Paid: ₹500/month)
⭐ Why Perfect: Plan content in advance

5️⃣ HOOTSUITE (Free Plan)
🔗 Website: hootsuite.com
💡 Use For: Manage multiple social accounts
📚 Tutorial: Hootsuite Academy (free courses)
💰 Cost: Free for 3 profiles (Pro: ₹2,000/month)
⭐ Why Perfect: All-in-one social media management

📈 ANALYTICS & TRACKING:

6️⃣ GOOGLE ANALYTICS (Website Traffic)
🔗 Website: analytics.google.com
💡 Use For: Track website visitors, behavior
📚 Tutorial: \"Google Analytics Hindi tutorial\"
💰 Cost: Completely Free
⭐ Why Perfect: Understand your audience

7️⃣ FACEBOOK INSIGHTS (Social Analytics)
🔗 Built into Facebook Business Suite
💡 Use For: Track post performance, audience insights
📚 Tutorial: Facebook Blueprint (free courses)
💰 Cost: Free with Facebook page
⭐ Why Perfect: Detailed social media analytics

💻 WEBSITE & LANDING PAGES:

8️⃣ GOOGLE SITES (Simple Websites)
🔗 Website: sites.google.com
💡 Use For: Basic business website, portfolio
📚 Tutorial: \"Google Sites tutorial Hindi\"
💰 Cost: Free (Custom domain: ₹1,000/year)
⭐ Why Perfect: Extremely simple, mobile-friendly

9️⃣ INSTAMOJO (Payment & Store)
🔗 Website: instamojo.com
💡 Use For: Online payments, simple store
📚 Tutorial: Instamojo help center
💰 Cost: Free signup (2% transaction fee)
⭐ Why Perfect: Indian payment gateway, easy setup

📱 WHATSAPP BUSINESS TOOLS:

1️⃣1️⃣ WHATSAPP BUSINESS API
💡 Use For: Automated messages, catalog, business profile
📚 Tutorial: WhatsApp Business official guide
💰 Cost: Free
⭐ Why Perfect: Most Indians use WhatsApp

1️⃣1️⃣ YELLOW.AI (ChatBot)
🔗 Website: yellow.ai
💡 Use For: Automated customer service
📚 Tutorial: Yellow.ai academy
💰 Cost: Free tier available
⭐ Why Perfect: Handle multiple customers simultaneously

📚 LEARNING RESOURCES:

• YouTube Channels: \"Digital Marketing Hindi\", \"WsCube Tech\"
• Free Courses: Google Digital Garage, Facebook Blueprint
• Blogs: Neil Patel Hindi blog, Social Media Examiner
• Communities: Indian Digital Marketing Facebook groups",

  "kpisMetrics": "📊 KEY PERFORMANCE INDICATORS & METRICS:

🎯 PRIMARY KPIs (Track Weekly):

1️⃣ CUSTOMER ACQUISITION:
📈 New Customers: _____ per week (Target: [realistic number])
💰 Customer Acquisition Cost (CAC): ₹_____ per customer
📊 Conversion Rate: _____% (inquiries to customers)
🎯 Monthly Target: [number] new customers

2️⃣ REVENUE METRICS:
💵 Weekly Revenue: ₹_____ (Target: ₹[amount])
💳 Average Order Value: ₹_____ per customer
🔄 Customer Lifetime Value: ₹_____ (estimated)
📈 Revenue Growth: _____% month-over-month

3️⃣ SOCIAL MEDIA ENGAGEMENT:
👥 Followers Growth: _____ new followers/week
❤️ Engagement Rate: _____% (likes, comments, shares)
👁️ Post Reach: _____ people per post
📱 Story Views: _____ views per story

📱 PLATFORM-SPECIFIC METRICS:

🟢 WHATSAPP BUSINESS:
• Message Response Time: _____ minutes (Target: <30 min)
• Daily Active Chats: _____ conversations
• Catalog Views: _____ views per week
• Broadcast Message Opens: _____%\n• Customer Inquiries from Status: _____

📸 INSTAGRAM/FACEBOOK:
• Profile Visits: _____ per week
• Website Clicks: _____ per week  
• DM Inquiries: _____ per week
• Hashtag Reach: _____ impressions

🔍 GOOGLE MY BUSINESS:
• Profile Views: _____ per week
• Search Appearances: _____ per week
• Direction Requests: _____ per week
• Phone Calls: _____ per week

💰 FINANCIAL TRACKING:

📊 WEEKLY DASHBOARD:
• Total Inquiries: _____\n• Qualified Leads: _____\n• Customers Acquired: _____\n• Revenue Generated: ₹_____\n• Marketing Spend: ₹_____\n• Profit Margin: _____%\n\n📈 MONTHLY REVIEW METRICS:
• Customer Retention Rate: _____%\n• Referral Rate: _____ referrals per 10 customers\n• Review/Rating Average: _____ stars\n• Market Share (local): Estimated _____%\n\n🎯 SUCCESS BENCHMARKS:

🟢 EXCELLENT PERFORMANCE:
• >90% message response rate within 1 hour
• >15% engagement rate on social media
• >20% conversion rate (inquiries to sales)
• 4.5+ star average rating
• >₹[amount] weekly revenue

🟡 GOOD PERFORMANCE:
• 70-90% quick response rate
• 8-15% engagement rate
• 10-20% conversion rate
• 4.0-4.5 star rating
• ₹[amount] weekly revenue

🔴 NEEDS IMPROVEMENT:
• <70% response rate
• <8% engagement
• <10% conversion
• <4.0 star rating
• <₹[amount] weekly revenue

📋 SIMPLE TRACKING SYSTEM:

📱 DAILY 5-MINUTE CHECK:
• Messages responded: ___/___
• New inquiries: _____
• Posts engagement: _____%
• Customer satisfaction: Any complaints?
• Revenue today: ₹_____

📊 WEEKLY REVIEW (15 minutes):
Week of: _____
✅ Customers acquired: _____ (vs target: _____)
✅ Revenue generated: ₹_____ (vs target: ₹_____)
✅ Social media growth: _____ followers
✅ Customer satisfaction: _____ stars average
✅ Best performing content: _____
✅ Biggest challenge: _____
✅ Next week's focus: _____

📈 MONTHLY BUSINESS REVIEW:
• Customer growth rate: _____%
• Revenue vs target: ₹_____ vs ₹_____
• Market position: Estimated _____ rank in local area
• Customer feedback themes: _____
• Strategy adjustments needed: _____",

  "estimatedBudget": "💰 MARKETING BUDGET BREAKDOWN:

🎯 TOTAL MONTHLY BUDGET RECOMMENDATION: ₹[amount based on their investment capacity]

📊 BUDGET ALLOCATION:

1️⃣ ORGANIC MARKETING (FREE - ₹500/month):

🆓 COMPLETELY FREE:
• WhatsApp Business setup and usage: ₹0
• Instagram/Facebook business profiles: ₹0
• Google My Business listing: ₹0
• Content creation using phone camera: ₹0
• Networking and word-of-mouth: ₹0

💸 MINIMAL COSTS:
• Canva Pro subscription: ₹500/month
• Professional phone photography props: ₹300 one-time
• Business cards printing: ₹200 one-time
• Flyers/pamphlets: ₹300/month

2️⃣ PAID ADVERTISING (₹1,000 - ₹5,000/month):

📱 SOCIAL MEDIA ADS:
• Facebook/Instagram Ads: ₹1,500-3,000/month
  - Daily budget: ₹50-100
  - Expected reach: 1,000-3,000 people/day
  - Estimated clicks: 50-150/day
  - Cost per click: ₹1-3

🔍 GOOGLE ADS (If applicable):
• Google Ads: ₹2,000-4,000/month
  - Daily budget: ₹65-130
  - Keywords: [relevant local keywords]
  - Expected clicks: 30-80/day
  - Cost per click: ₹3-8

📍 LOCAL PROMOTION:
• WhatsApp group promotions: ₹200-500/month
• Local influencer collaboration: ₹500-2,000/month
• Community event sponsorship: ₹1,000-3,000/month

3️⃣ TOOLS & SUBSCRIPTIONS (₹500 - ₹2,000/month):

🛠️ ESSENTIAL TOOLS:
• Canva Pro: ₹500/month
• InShot Pro: ₹200/month
• Buffer/Hootsuite: ₹500/month
• Domain + Basic hosting: ₹300/month
• WhatsApp Business API: ₹0-800/month

📊 BUDGET BY BUSINESS STAGE:

🌱 STARTUP PHASE (Month 1-3):
Total Budget: ₹1,000-2,000/month
• Focus: Organic growth
• Allocation: 70% organic, 30% minimal paid ads
• Priority: Building foundation and first customers

🚀 GROWTH PHASE (Month 4-6):
Total Budget: ₹2,500-4,000/month
• Focus: Scaling what works
• Allocation: 50% organic, 50% paid advertising
• Priority: Expanding reach and customer base

💪 EXPANSION PHASE (Month 7+):
Total Budget: ₹4,000-6,000/month
• Focus: Market dominance
• Allocation: 30% organic, 70% paid strategies
• Priority: Dominating local market

🎯 BUDGET OPTIMIZATION TIPS:

💡 START SMALL STRATEGY:
• Week 1-2: ₹0 budget (purely organic)
• Week 3-4: ₹500 budget (test small ads)
• Month 2: ₹1,000 budget (scale what works)
• Month 3+: ₹2,000+ budget (aggressive growth)

📈 ROI EXPECTATIONS:
• Month 1: Break-even on marketing spend
• Month 2: 2:1 return (₹2 revenue per ₹1 spent)
• Month 3+: 3:1 return (₹3 revenue per ₹1 spent)

⚠️ BUDGET ALERTS:
• If CAC > 30% of customer value, reduce paid ads
• If organic reach drops, increase content quality
• If conversion rate <10%, improve messaging
• Always keep 20% budget for emergency opportunities

💳 PAYMENT METHODS FOR ADS:
• UPI payments for Facebook/Instagram ads
• Prepaid cards for Google Ads
• Net banking for tool subscriptions
• Local cash payments for offline promotions

🎁 FREE BUDGET BOOSTERS:
• Customer referral program
• User-generated content campaigns
• Partnership with complementary businesses
• Seasonal festival-themed content
• Local media coverage and PR"
}
`;

  try {
    console.log("Calling Gemini API with prompt length:", prompt.length);
    const response = await retryWithBackoff(async () => {
      console.log("Making API call to Gemini for marketing plan...");
      return await ai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              brandVoiceMessaging: { type: "string" },
              recommendedChannels: { type: "string" },
              contentPlanIdeas: { type: "string" },
              first50CustomersStrategy: { type: "string" },
              outreachScripts: { type: "string" },
              toolsResources: { type: "string" },
              kpisMetrics: { type: "string" },
              estimatedBudget: { type: "string" }
            },
            required: ["brandVoiceMessaging", "recommendedChannels", "contentPlanIdeas", "first50CustomersStrategy", "outreachScripts", "toolsResources", "kpisMetrics", "estimatedBudget"]
          }
        },
        contents: prompt,
      });
    });

    const rawJson = response.text;
    console.log("Gemini API response received for marketing plan, length:", rawJson?.length || 0);
    if (rawJson) {
      const data = JSON.parse(rawJson);
      console.log("Generated marketing plan data keys:", Object.keys(data));
      return data;
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Failed to generate marketing plan, using fallback:", error);

    // Provide comprehensive fallback data
    const fallbackData: MarketingPlan = {
      brandVoiceMessaging: `🎯 BRAND VOICE & MESSAGING FOR ${businessPlan.title?.toUpperCase() || 'YOUR BUSINESS'}:

📢 RECOMMENDED TONE: Friendly Expert
Your brand should speak like a knowledgeable friend who genuinely cares about helping customers succeed.

💬 BRAND VOICE CHARACTERISTICS:
• Primary Voice: Trustworthy Guide with local expertise
• Communication Style: Simple Hindi-English mix, professional but approachable
• Personality Traits: Helpful, Reliable, Understanding, Results-focused

🗣️ KEY MESSAGE PILLARS:

Pillar 1: Local Expertise & Trust
• Example: "Hamara experience aur aapka trust - perfect combination for success!"
• Use when: Introducing yourself or building credibility

Pillar 2: Affordable Quality Solutions
• Example: "Best quality at prices that make sense for Indian families"
• Use when: Discussing pricing or value proposition

Pillar 3: Personalized Care & Support
• Example: "Har customer ka journey unique hai - hum samajhte hain aapki needs"
• Use when: Addressing individual customer concerns

🏷️ TAGLINE SUGGESTIONS:
• Option 1: "Aapka sapna, humara passion"
• Option 2: "Quality you trust, prices you love"
• Option 3: "Local expertise, global standards"`,

      recommendedChannels: `🚀 RECOMMENDED MARKETING CHANNELS FOR ${businessPlan.title}:

1️⃣ PRIMARY CHANNEL: WhatsApp Business
📱 Platform: WhatsApp Business + Status updates
🎯 Why Perfect for You:
• 99% of Indians use WhatsApp daily
• Personal communication builds trust quickly
• Free to use with catalog features
• Easy to share testimonials and work samples
📊 Expected Results: 60-70% of your customers will come through WhatsApp
💰 Cost: Completely FREE

2️⃣ SECONDARY CHANNEL: Instagram
📱 Platform: Instagram Business Account
🎯 Why It Works:
• Visual platform perfect for showcasing work
• Young audience with disposable income
• Story features for daily engagement
• Reels for viral content potential
📊 Expected Results: 20-25% customer acquisition
💰 Cost: Free organic, ₹50-100/day for ads

3️⃣ SUPPORTING CHANNEL: Facebook
📱 Platform: Facebook Business Page
🎯 Strategic Use:
• Older demographic (30+ age group)
• Great for detailed posts and customer reviews
• Event promotion and community building
📊 Expected Results: 10-15% customer base
💰 Cost: Free organic, similar ad costs to Instagram

4️⃣ LOCAL OUTREACH: Google My Business + Word of Mouth
📍 Method: Optimized Google listing + referral program
🎯 Why Effective:
• Local search dominance
• Customer reviews build credibility
• Direct phone calls and directions
📊 Expected Results: 15-20% local discovery
💰 Cost: Free setup, ₹200-500 for professional photos

5️⃣ WORD-OF-MOUTH: Customer Referrals
👥 Approach: Systematic referral requests and incentives
🎯 Implementation:
• Ask every satisfied customer for 2 referrals
• Offer 10% discount for successful referrals
• Create shareable content for easy referrals
📊 Expected Results: 30-40% growth through referrals
💰 Cost: Referral discounts (₹100-300 per referral)`,

      contentPlanIdeas: `📱 CONTENT PLAN & POST IDEAS FOR ${businessPlan.title}:

🎬 INSTAGRAM/FACEBOOK POSTS:

Post Idea 1: Behind-the-scenes Process
📝 Caption: "Dekho kaise banata hun main [product/service]! 😊 Har step mein quality aur care dikhta hai. Quality compromise nahi karte! 💪 #handmade #quality #${profileData.location} #smallbusiness"
📸 Visual: Time-lapse video of your work process
🎯 Goal: Build trust through transparency

Post Idea 2: Customer Success Story
📝 Caption: "Meet Mrs. Sharma from ${profileData.location}! 🌟 Unki khushi dekh kar mera din ban gaya! ✨ 'Bilkul wahi chahiye tha jo maine socha tha' - yahi meri khushi hai! 😊 #happycustomer #testimonial #trustworthy"
📸 Visual: Customer photo with product/after service (with permission)
🎯 Goal: Social proof and credibility building

Post Idea 3: Educational Tip
📝 Caption: "Pro tip Tuesday! 💡 Aapko pata hai [relevant tip for your service]? Yeh choti baat bada difference laati hai! 🎯 Save this post for future reference! #tips #education #helpful #didyouknow"
📸 Visual: Infographic or carousel with tip explanation
🎯 Goal: Position yourself as an expert

Post Idea 4: Festival Special
📝 Caption: "Diwali special offer! ✨ Is bar festival ko banayiye extra special mere [product/service] ke saath! 🪔 Special discount sirf 3 din ke liye! DM karo abhi! 🎉 #diwali #festivespecial #limitedtime #${profileData.location}"
📸 Visual: Festival-themed product styling or service showcase
🎯 Goal: Seasonal engagement and sales boost

Post Idea 5: Quick FAQ
📝 Caption: "Frequently Asked Questions answered! ❓➡️✅ 1. Kitna time lagta hai? 2. Price kya hai? 3. Quality kaisi hai? Swipe karo answers ke liye! 👉 #faq #transparent #honest #customercare"
📸 Visual: Carousel post with Q&A format
🎯 Goal: Address common objections

📱 WHATSAPP STATUS IDEAS:

Status 1: "Aaj ka kaam ✅ [Brief work update] #productive #${businessPlan.title}"
Status 2: "Customer review: 'Excellent service!' ⭐⭐⭐⭐⭐ DM for bookings!"
Status 3: "Work in progress... 🔨 Quality takes time! #craftsmanship"
Status 4: "Monday motivation: 'Sapne dekho, kaam karo, success pao!' 💪"
Status 5: "Special offer alert! 🚨 DM now for details! Valid today only!"

📄 LOCAL FLYER IDEAS:

Flyer 1: Service Introduction
• Headline: "Nayi Service Launch! ${businessPlan.title} ab ${profileData.location} mein!"
• Key points: 
  - Professional quality guaranteed
  - Affordable rates for local families  
  - Quick service, on-time delivery
  - Customer satisfaction guarantee
• Contact: WhatsApp [number] ya call karo!

Flyer 2: Special Opening Offer
• Headline: "Grand Opening Special - 50% OFF!"
• Details: First 20 customers get mega discount
• Call-to-action: "Abhi call karo, slot book karo!"`,

      first50CustomersStrategy: `👥 FIRST 50 CUSTOMERS ACQUISITION STRATEGY:

🎯 GOAL: Get 50 paying customers in 8-10 weeks

📅 PHASE 1: Foundation (Days 1-14)
🎯 Target: 8-10 customers

Week 1 Actions:
• Day 1-2: Setup WhatsApp Business with professional profile and catalog
• Day 3-4: Create Instagram business account with 5-7 posts
• Day 5-7: Personal network outreach (family, friends, neighbors) - Target: 5-6 customers

Week 2 Actions:
• Day 8-10: Post daily content showing your work/service
• Day 11-12: Extended network (colleagues, acquaintances) - Target: 2-3 customers  
• Day 13-14: Ask first customers for honest reviews and referrals

📅 PHASE 2: Local Community Expansion (Days 15-35)
🎯 Target: 20-25 customers

Week 3-4 Actions:
• Join 5-10 relevant local WhatsApp groups
• Create and distribute 100 flyers in your area
• Partner with 2-3 local shops for referrals
• Target: 12-15 new customers

Week 5 Actions:
• Launch referral program (₹100 off for each referral)
• Set up Google My Business with photos
• Collect and post customer testimonials
• Target: 5-8 new customers

📅 PHASE 3: Digital Growth (Days 36-60)
🎯 Target: 15-17 customers

Week 6-7 Actions:
• Increase social media posting to twice daily
• Run first paid ads (₹500-1000 budget)
• Connect with local bloggers/micro-influencers
• Target: 10-12 new customers

Week 8-9 Actions:
• Optimize successful strategies
• Launch customer loyalty program
• Expand to additional neighborhoods
• Target: 5-7 new customers

📊 WEEKLY SUCCESS METRICS:
• New customer target: 6-8 per week
• Conversion rate goal: 25% (inquiries to sales)
• Customer satisfaction: 4.5+ stars
• Referral rate: 2 referrals per 10 customers

🎯 DAILY ACTION CHECKLIST:
✅ Respond to all messages within 2 hours
✅ Post 1 piece of content on social media
✅ Follow up with 3 prospects
✅ Ask 1 customer for review/referral
✅ Update WhatsApp status with work update`,

      outreachScripts: `💬 OUTREACH SCRIPTS & TEMPLATES:

📱 INITIAL DM SCRIPTS:

Script 1: Personal Network (Hindi-English Mix)
"Hi [Name]! Kaise ho? 😊
Maine recently [business description] start kiya hai aur socha tumhe batau!
[Brief value proposition in simple terms]
Agar kabhi zarurat ho to bolo, khushi se help karunga! 
Bilkul bhi pressure nahi hai! 🙏
WhatsApp karo: [number]"

Script 2: Local Community Groups
"Namaste everyone! 🙏
Main [Your name] hun, ${profileData.location} se. 
[Business description] ka kaam start kiya hai to help [target audience].
[Brief experience/credential]
Agar kisi ko [service/product] chahiye, DM kar sakte hain.
Quality aur affordable rates guarantee! 😊
Contact: [WhatsApp number]"

Script 3: Cold Outreach (Potential Customers)
"Hi [Name]!
Aapko [relevant service] ki zarurat hai?
Main [business] mein specialize karta hun aur [location] mein service deta hun.
Example: [quick success story]
Agar interested hain to details share kar sakta hun.
No obligation - bas helpful rehna chahta hun! 🙂"

📞 PHONE SCRIPT:
"Hello [Name], [Your name] bol raha hun.
Main [reason for calling - referral/saw their need]
Main [target audience] ki help karta hun [main benefit] mein.
Jaise, [quick example]
Kya aap 2 minute sun sakte hain ki yeh aapke kaam aa sakta hai?"

💌 FOLLOW-UP SCRIPTS:

Follow-up 1 (After 3 days):
"Hi [Name]! 😊
[Service/product] ke baare mein message kiya tha.
Pata hai busy honge!
Agar abhi bhi interested hain to pooch sakte hain.
Otherwise no problem! 🙏"

Follow-up 2 (After 1 week):
"Hi [Name]!
Hope aap theek hain!
Ek success story share karna chahta tha: [brief customer result]
Yaad aaya hamari baat ka.
Agar explore karna chahte hain to batayiye!
Warna main disturb nahi karunga! 😊"

🙏 THANK YOU SCRIPTS:

After Purchase:
"Thank you so much [business name] choose karne ke liye! 🙏😊
Main excited hun aapke liye [service/product deliver] karne ke liye.
Aapka trust sabse important hai mere liye.
Best results definitely milengy!
Koi question ho to message kar dena! 📱"

After Positive Review:
"Wow! Itna awesome review! 🤩
Seriously, mera din ban gaya!
Aap jaise customers inspire karte hain best work karne ke liye.
Agar koi aur friend ho jisko help chahiye, refer kar dena! 🙏"`,

      toolsResources: `🛠️ ESSENTIAL MARKETING TOOLS & RESOURCES:

📱 FREE DESIGN TOOLS:

1️⃣ CANVA (Graphics & Posts)
🔗 Website: canva.com
💡 Perfect For: Social media posts, flyers, logos, banners
📚 Learn: "Canva tutorial Hindi" on YouTube by Tech Yatra
💰 Cost: Free (Pro: ₹500/month for advanced features)
⭐ Indian Features: Hindi fonts, Indian festival templates

2️⃣ INSHOT (Video Editing)
🔗 App: InShot Video Editor (Play Store/App Store)
💡 Perfect For: Instagram Reels, promotional videos, testimonials
📚 Learn: "InShot tutorial Hindi" by Technical Guruji
💰 Cost: Free with watermark (Pro: ₹200/month)
⭐ Best For: Quick mobile video editing with trending effects

3️⃣ PIXELLAB (Text on Images)
🔗 App: PixelLab (Android/iOS)
💡 Perfect For: Adding Hindi text, quotes, offers on images
📚 Learn: Built-in tutorials, very user-friendly
💰 Cost: Free with ads (Pro: ₹150 one-time)
⭐ Advantage: Supports Devanagari fonts perfectly

📊 SOCIAL MEDIA MANAGEMENT:

4️⃣ CREATOR STUDIO (Meta's Free Tool)
🔗 Access: business.facebook.com
💡 Perfect For: Schedule posts, analyze performance, manage Instagram + Facebook
📚 Learn: Facebook Blueprint free courses
💰 Cost: Completely FREE
⭐ Best Feature: Official tool with all insights

5️⃣ LATER (Post Scheduling)
🔗 Website: later.com
💡 Perfect For: Visual content calendar, auto-posting
📚 Learn: Later Academy (free courses)
💰 Cost: Free for 1 social set (Paid: ₹800/month)
⭐ Perfect For: Planning content in advance

📈 FREE ANALYTICS:

6️⃣ GOOGLE MY BUSINESS INSIGHTS
🔗 Built into Google My Business app
💡 Track: Customer calls, direction requests, photo views
📚 Learn: Google My Business Help Center
💰 Cost: Completely FREE
⭐ Essential: Shows how locals find your business

7️⃣ WHATSAPP BUSINESS INSIGHTS
🔗 Built into WhatsApp Business app
💡 Track: Message delivery, read rates, customer interactions
📚 Learn: WhatsApp Business guide (in-app)
💰 Cost: FREE
⭐ Must-Have: Most important tool for Indian businesses

🎯 CUSTOMER MANAGEMENT:

8️⃣ GOOGLE SHEETS (Customer Database)
🔗 sheets.google.com
💡 Perfect For: Customer details, order tracking, payment records
📚 Learn: "Google Sheets Hindi tutorial" by Learn More
💰 Cost: FREE with Google account
⭐ Simple Solution: Easy to use, accessible anywhere

9️⃣ TYPEFORM (Feedback Collection)
🔗 typeform.com
💡 Perfect For: Customer satisfaction surveys, service feedback
📚 Learn: Typeform Academy
💰 Cost: Free for 100 responses/month
⭐ Professional: Beautiful forms that customers love filling

📱 WHATSAPP TOOLS:

1️⃣0️⃣ WHATSAPP BUSINESS API TOOLS:
• WATI.io: Advanced WhatsApp automation (₹2000/month)
• Gupshup: Bulk messaging and chatbots (₹1500/month)
• Yellow Messenger: AI chatbots (₹3000/month)
💡 Use When: You get 100+ daily messages

1️⃣1️⃣ BULK MESSAGE TOOLS:
• WhatsApp Bulk Sender (Free Android apps)
• Multiple WhatsApp (GB WhatsApp alternatives)
⚠️ Warning: Use carefully to avoid account bans

📚 FREE LEARNING RESOURCES:

🎓 YOUTUBE CHANNELS (Hindi):
• Digital Marketing Hindi by Umar Tazkeer
• WsCube Tech Marketing Tutorials  
• Technical Guruji Business Tips
• Deepak Kanakaraju Marketing Courses

📖 FREE COURSES:
• Google Digital Garage (Hindi available)
• Facebook Blueprint (Free certification)
• HubSpot Academy (Marketing basics)
• YouTube Creator Academy

🌐 USEFUL WEBSITES:
• Unsplash.com: Free stock photos
• Pexels.com: Free videos and images  
• Remove.bg: Remove photo backgrounds
• TinyPNG.com: Compress images for faster loading

💡 PRODUCTIVITY APPS:
• Todoist: Task management (Free)
• Google Calendar: Schedule posts and follow-ups
• Google Drive: Store all marketing materials
• Grammarly: Improve English writing (Free version)`,

      kpisMetrics: `📊 KEY PERFORMANCE INDICATORS & METRICS TO TRACK:

🎯 PRIMARY SUCCESS METRICS (Track Weekly):

1️⃣ CUSTOMER GROWTH:
📈 New Customers Per Week: _____ (Target: 6-8)
📊 Total Active Customers: _____
🔄 Customer Retention Rate: _____% (Target: 80%+)
💰 Customer Lifetime Value: ₹_____ (Track average spending)

2️⃣ REVENUE TRACKING:
💵 Weekly Revenue: ₹_____ (Target: ₹${Math.round(parseInt(profileData.incomeGoal || '25000') / 4)})
💳 Average Order Value: ₹_____ per customer
📈 Monthly Revenue Growth: _____% 
🎯 Revenue Per Customer: ₹_____

3️⃣ LEAD GENERATION:
📱 Daily Inquiries: _____ messages/calls
📊 Conversion Rate: _____% (inquiries to customers)
🎯 Lead Quality Score: _____ (qualified vs total leads)
⏰ Response Time: _____ minutes (Target: <30 minutes)

📱 SOCIAL MEDIA METRICS:

🟢 WHATSAPP BUSINESS:
• Active Chats Per Day: _____ 
• Message Response Rate: _____% (Target: 95%+)
• Catalog Views Per Week: _____
• Status Views Per Post: _____
• Customer Inquiries from Status: _____

📸 INSTAGRAM PERFORMANCE:
• Followers Growth: _____ per week
• Engagement Rate: _____% (Target: 8%+)
• Story Views: _____ per story
• Profile Visits: _____ per week  
• DM Inquiries: _____ per week

📘 FACEBOOK METRICS:
• Page Likes Growth: _____ per week
• Post Reach: _____ people per post
• Page Views: _____ per week
• Click-through Rate: _____%

🔍 LOCAL DISCOVERY:

📍 GOOGLE MY BUSINESS:
• Profile Views: _____ per week
• Search Appearances: _____ per week
• Direction Requests: _____ per week  
• Phone Calls from Listing: _____ per week
• Customer Reviews: _____ stars average

👥 WORD-OF-MOUTH TRACKING:
• Referrals Received: _____ per week
• Referral Conversion Rate: _____%
• Customer Satisfaction Score: _____ /5
• Repeat Customer Rate: _____%

💰 FINANCIAL HEALTH METRICS:

📊 PROFITABILITY:
• Weekly Profit: ₹_____ (Revenue - Expenses)
• Profit Margin: _____% (Target: 40%+)
• Customer Acquisition Cost: ₹_____ per customer
• Marketing ROI: ₹_____ return per ₹1 spent

💸 COST TRACKING:
• Weekly Marketing Spend: ₹_____
• Cost Per Lead: ₹_____ per inquiry
• Cost Per Customer: ₹_____ per conversion
• Operating Expenses: ₹_____ per week

🎯 SUCCESS BENCHMARKS:

🟢 EXCELLENT PERFORMANCE:
• 90%+ message response within 1 hour
• 15%+ social media engagement rate
• 25%+ conversion rate (inquiries to sales)
• 4.8+ star average rating
• ₹${Math.round(parseInt(profileData.incomeGoal || '25000') / 4)}+ weekly revenue

🟡 GOOD PERFORMANCE:
• 70-89% quick response rate
• 8-14% engagement rate
• 15-24% conversion rate
• 4.3-4.7 star rating
• ₹${Math.round(parseInt(profileData.incomeGoal || '25000') / 6)}+ weekly revenue

🔴 NEEDS IMPROVEMENT:
• <70% response rate
• <8% engagement
• <15% conversion
• <4.3 star rating
• <₹${Math.round(parseInt(profileData.incomeGoal || '25000') / 8)} weekly revenue

📋 SIMPLE TRACKING SYSTEM:

📱 DAILY 5-MINUTE CHECK:
• Messages responded: ___/___
• New inquiries: _____
• Posts engagement: _____%
• Customer satisfaction: Any complaints?
• Revenue today: ₹_____

📊 WEEKLY REVIEW (15 minutes):
Week of: _____
✅ Customers acquired: _____ (vs target: _____)
✅ Revenue generated: ₹_____ (vs target: ₹_____)
✅ Social media growth: _____ followers
✅ Customer satisfaction: _____ stars average
✅ Best performing content: _____
✅ Biggest challenge: _____
✅ Next week's focus: _____

📈 MONTHLY BUSINESS REVIEW:
• Customer growth rate: _____%
• Revenue vs target: ₹_____ vs ₹_____
• Market position: Estimated _____ rank in local area
• Customer feedback themes: _____
• Strategy adjustments needed: _____`,

      estimatedBudget: `💰 MARKETING BUDGET BREAKDOWN FOR ${businessPlan.title}:

🎯 RECOMMENDED MONTHLY BUDGET: ₹2,000-4,000
(Based on your investment capacity: ${profileData.investmentCapacity})

📊 SMART BUDGET ALLOCATION:

1️⃣ ZERO-COST MARKETING (₹0/month):
🆓 COMPLETELY FREE STRATEGIES:
• WhatsApp Business setup and daily usage: ₹0
• Instagram business profile: ₹0
• Facebook business page: ₹0
• Google My Business listing: ₹0
• Organic content creation with phone: ₹0
• Customer referral requests: ₹0
• Word-of-mouth networking: ₹0

💡 Expected Results: 40-50% of customers through free methods

2️⃣ MINIMAL INVESTMENT TOOLS (₹500-1,000/month):

🛠️ ESSENTIAL SUBSCRIPTIONS:
• Canva Pro: ₹500/month (professional designs)
• InShot Pro: ₹200/month (video editing without watermark)
• Domain + basic website: ₹300/month
• WhatsApp Business features: ₹0-500/month

📄 PHYSICAL MARKETING:
• Business cards (500 pieces): ₹300 one-time
• Flyers/pamphlets: ₹400/month (200 pieces)
• Professional photos: ₹1,000 one-time investment

3️⃣ PAID ADVERTISING (₹1,500-3,000/month):

📱 SOCIAL MEDIA ADS:
• Facebook/Instagram Ads: ₹1,200-2,400/month
  - Daily budget: ₹40-80
  - Expected reach: 800-2,000 people/day
  - Estimated clicks: 40-100/day
  - Cost per customer: ₹80-150

🔍 GOOGLE ADS (If Applicable):
• Local Google Ads: ₹1,500-3,000/month
  - Daily budget: ₹50-100
  - Local keywords: "[service] ${profileData.location}"
  - Expected clicks: 25-60/day
  - Cost per lead: ₹50-120

📍 LOCAL PROMOTIONS:
• WhatsApp group paid promotions: ₹300-600/month
• Local influencer collaboration: ₹800-2,000/month
• Community event participation: ₹500-1,500/month

📊 BUDGET BY GROWTH PHASE:

🌱 STARTUP PHASE (Month 1-2):
Total Budget: ₹800-1,500/month
• Focus: Organic growth + basic tools
• Allocation: 80% organic, 20% paid
• Priority: Building foundation and first customers
• Expected customers: 15-25

🚀 GROWTH PHASE (Month 3-6):
Total Budget: ₹2,000-3,500/month  
• Focus: Scaling successful strategies
• Allocation: 60% organic, 40% paid advertising
• Priority: Expanding reach and market presence
• Expected customers: 30-50

💪 EXPANSION PHASE (Month 7+):
Total Budget: ₹3,000-5,000/month
• Focus: Market leadership and brand building
• Allocation: 40% organic, 60% strategic paid ads
• Priority: Dominating local market
• Expected customers: 50-80

🎯 ROI EXPECTATIONS BY BUDGET LEVEL:

💰 ₹1,000/MONTH BUDGET:
• Expected monthly customers: 20-25
• Revenue target: ₹15,000-20,000
• ROI: 15:1 to 20:1 return
• Break-even timeline: Month 2

💰 ₹2,500/MONTH BUDGET:
• Expected monthly customers: 35-45
• Revenue target: ₹25,000-35,000
• ROI: 10:1 to 14:1 return  
• Break-even timeline: Month 1

💰 ₹4,000/MONTH BUDGET:
• Expected monthly customers: 50-65
• Revenue target: ₹40,000-55,000
• ROI: 10:1 to 14:1 return
• Break-even timeline: Within 3 weeks

⚠️ BUDGET OPTIMIZATION RULES:

🚦 TRAFFIC LIGHT SYSTEM:
🟢 GREEN (Increase Budget):
• Customer acquisition cost <₹100
• Conversion rate >20%
• Customer satisfaction >4.5 stars
• Monthly revenue target achieved

🟡 YELLOW (Maintain Budget):
• Customer acquisition cost ₹100-150
• Conversion rate 15-20%
• Customer satisfaction 4.0-4.5 stars
• 80-100% of revenue target

🔴 RED (Reduce Budget):
• Customer acquisition cost >₹150
• Conversion rate <15%
• Customer satisfaction <4.0 stars
• <80% of revenue target

💡 EMERGENCY BUDGET STRATEGIES:

🆘 IF BUDGET IS VERY LIMITED (₹500/month):
• Focus 100% on WhatsApp and referrals
• Use free Canva version
• Create content with phone camera only
• Partner with other local businesses for cross-promotion
• Expected customers: 10-15/month

🚀 BUDGET BOOST OPPORTUNITIES:
• Reinvest 50% of profits into marketing
• Customer referral bonuses: ₹50-100 per referral
• Seasonal campaign increases during festivals
• Success-based budget scaling (increase when ROI is high)

💳 PAYMENT OPTIMIZATION:
• Use UPI for all digital payments (cashback benefits)
• Prepaid advertising credits for better rates
• Annual subscriptions for tool discounts
• Local cash payments for offline promotions`
    };

    return fallbackData;
  }
}

export async function chatWithIdea(
  message: string,
  idea: any,
  chatHistory: any[] = [],
  userProfile: any = null
): Promise<string> {
  // Handle undefined or null chatHistory
  const safeHistory = chatHistory || [];

  const historyText = safeHistory.length > 0
    ? safeHistory.map(msg =>
        `${msg.isFromUser ? 'User' : 'AI'}: ${msg.message}`
      ).join('\n')
    : 'No previous conversation';

  // Build comprehensive context
  const profileContext = userProfile ? `
User Profile Context:
- Age: ${userProfile.age || 'Not specified'} years old (${userProfile.ageGroup || 'Not specified'})
- Location: ${userProfile.location || 'Not specified'}, ${userProfile.city || 'Not specified'}, ${userProfile.country || 'Not specified'}
- Current Profession: ${userProfile.currentProfession || 'Not specified'}
- Available Hours: ${userProfile.availableHours || 'Not specified'} hours per week
- Investment Capacity: ₹${userProfile.investmentCapacity || 'Not specified'}
- Income Goal: ${userProfile.incomeGoal || 'Not specified'}
- Skills: ${JSON.stringify(userProfile.topSkills) || 'Not specified'}
- Languages: ${JSON.stringify(userProfile.languages) || 'Not specified'}
- Work Preference: ${userProfile.workPreference || 'Not specified'}
- Digital Comfort: ${userProfile.digitalToolsComfort || 'Not specified'}
` : '';

  const prompt = `
You are an expert business advisor helping an entrepreneur understand and develop their business idea. Provide practical, actionable advice tailored to the Indian market and the user's specific situation.

Business Idea: ${idea.title}
Description: ${idea.description}
Target Market: ${idea.targetPersona || 'Local community'}
Revenue Potential: ${idea.revenuePotential || 'To be determined'}
Startup Costs: ${idea.startupCosts || 'Minimal investment'}
Difficulty Level: ${idea.difficultyLevel || 'Beginner-friendly'}
Time to Launch: ${idea.timeCommitment || 'Few weeks'}

${profileContext}

Previous Chat History:
${historyText}

User's Current Question: ${message}

Instructions:
1. Provide helpful, specific answers about this business idea
2. Be encouraging but realistic about challenges and opportunities
3. Give practical advice relevant to Indian market conditions
4. Consider their profile (location, skills, investment capacity, etc.) when giving suggestions
5. If they ask about implementation, provide step-by-step guidance
6. Address any concerns about feasibility based on their constraints
7. Suggest specific actions they can take to validate or start this business

Keep your response conversational, practical, and tailored to their specific situation.
`;

  try {
    const response = await retryWithBackoff(async () => {
      return await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });
    });

    return response.text || "I'm here to help! Could you rephrase your question?";
  } catch (error) {
    console.error("Failed to chat with idea after retries:", error);
    throw new Error(`Failed to chat with idea: ${error}`);
  }
}