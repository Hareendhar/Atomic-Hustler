
import { useState } from "react";
import { useParams, Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FloatingElements } from "@/components/floating-elements";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { type BusinessPlan, type FinancialPlan } from "@shared/schema";
import { TrendingUp, DollarSign, PieChart, Calculator, BarChart3, AlertTriangle, ArrowLeft, RefreshCw, Calendar, Lock } from "lucide-react";

export default function FinancialPlan() {
  const { id } = useParams<{ id?: string }>();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const businessPlanId = id;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPlanId, setSelectedPlanId] = useState<string>("");

  // Get all business plans for selection
  const { data: businessPlans = [], isLoading: plansLoading } = useQuery<BusinessPlan[]>({
    queryKey: ["/api/business-plans"],
    enabled: isAuthenticated,
  });

  const { data: businessPlan, isLoading: planLoading } = useQuery<BusinessPlan>({
    queryKey: ["/api/business-plans", businessPlanId],
    enabled: !!businessPlanId && businessPlanId !== "undefined" && isAuthenticated,
  });

  const { data: financialPlan, isLoading: financialLoading, error: financialError } = useQuery<FinancialPlan>({
    queryKey: ["/api/business-plans", businessPlanId, "financial-plan"],
    enabled: !!businessPlanId && businessPlanId !== "undefined" && isAuthenticated,
    retry: 2,
    staleTime: 1 * 60 * 1000,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });

  const generateFinancialPlanMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/business-plans/${businessPlanId}/generate-financial-plan`, {
        method: "POST",
      });
    },
    onSuccess: (data) => {
      console.log("Financial plan generated successfully:", data);
      queryClient.setQueryData(["/api/business-plans", businessPlanId, "financial-plan"], data);
      queryClient.invalidateQueries({
        queryKey: ["/api/business-plans", businessPlanId, "financial-plan"],
      });
      toast({
        title: "Success! 💰",
        description: "Financial plan generated successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate financial plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  const lockPlanMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/business-plans/${businessPlanId}/lock`, {
        method: "PATCH",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/business-plans", businessPlanId],
      });
      toast({
        title: "Success! 🔒",
        description: "Business plan locked successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to lock business plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || plansLoading || (businessPlanId && planLoading)) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  // Show business plan selection if no specific plan ID
  if (!businessPlanId || businessPlanId === "new") {
    if (businessPlans.length === 0) {
      return (
        <div className="p-8">
          <div className="max-w-4xl mx-auto text-center">
            <AlertTriangle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">No Business Plans Found</h2>
            <p className="text-muted-foreground mb-6">
              Create a business plan first to access financial planning features.
            </p>
            <Link href="/business-plan">
              <Button size="lg">Create Business Plan</Button>
            </Link>
          </div>
        </div>
      );
    }

    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-2">Financial Plan</h1>
            <p className="text-muted-foreground">
              Select a business plan to view or create its financial projections
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Select Business Plan</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Choose a business plan:</label>
                <Select value={selectedPlanId} onValueChange={setSelectedPlanId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a business plan" />
                  </SelectTrigger>
                  <SelectContent>
                    {businessPlans.map((plan) => (
                      <SelectItem key={plan.id} value={plan.id.toString()}>
                        {plan.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {selectedPlanId && (
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">
                    {businessPlans.find((p) => p.id.toString() === selectedPlanId)?.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Generate comprehensive financial projections and analysis for this business plan.
                  </p>
                </div>
              )}

              <Button 
                onClick={() => window.location.href = `/financial-plan/${selectedPlanId}`}
                disabled={!selectedPlanId}
                className="w-full"
              >
                View Financial Plan
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Financial Plans</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {businessPlans.map((plan) => (
                  <div key={plan.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">{plan.title}</h3>
                      <p className="text-sm text-muted-foreground">Financial analysis and projections</p>
                    </div>
                    <Button onClick={() => window.location.href = `/financial-plan/${plan.id}`}>
                      View Plan
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!businessPlanId) {
    return (
      <div className="p-8">
        <div className="max-w-4xl mx-auto text-center">
          <AlertTriangle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">No Business Plan Selected</h2>
          <p className="text-muted-foreground mb-6">
            Create a business plan first to access financial planning features.
          </p>
          <Link href="/">
            <Button size="lg">Go to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <FloatingElements />

      <div className="max-w-7xl mx-auto space-y-6">
        {financialLoading ? (
          <div className="text-center py-12">
            <div className="bg-white border border-[#e5e7eb] rounded-lg p-12 max-w-2xl mx-auto shadow-lg">
              <div className="w-16 h-16 border-4 border-[#e5e7eb] border-t-[#f59e0b] animate-spin mx-auto mb-6 rounded-full"></div>
              <h2 className="text-3xl font-bold mb-4 text-[#262626]">Loading Financial Plan...</h2>
              <p className="text-lg text-[#6b7280]">
                Please wait while we fetch your financial data.
              </p>
            </div>
          </div>
        ) : !financialPlan || !financialPlan.revenueModel ? (
          <div className="text-center py-12">
            <div className="bg-[#fffbeb] border border-[#f59e0b] rounded-lg p-12 max-w-2xl mx-auto shadow-lg">
              <TrendingUp className="w-16 h-16 mx-auto mb-6 text-[#f59e0b]" />
              <h2 className="text-3xl font-bold mb-4 text-[#262626]">Financial Plan Not Ready</h2>
              <p className="text-lg mb-6 text-[#6b7280]">
                Your financial plan hasn't been created yet. Generate a comprehensive financial analysis including revenue projections, cost breakdown, and profitability forecasts.
              </p>
              <button
                onClick={() => generateFinancialPlanMutation.mutate()}
                disabled={generateFinancialPlanMutation.isPending}
                className="bg-[#f59e0b] hover:bg-[#d97706] text-white font-bold py-4 px-8 text-lg rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {generateFinancialPlanMutation.isPending ? "Creating Financial Plan..." : "Create Financial Plan"}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Page Title */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-primary/10">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <h1 className="text-3xl font-bold text-foreground">Financial Plan</h1>
              </div>
              <p className="text-xl text-muted-foreground">
                {businessPlan?.title ? `For ${businessPlan.title}` : "Comprehensive financial analysis and projections"}
              </p>
            </div>

            {/* Financial Overview */}
            <Card className="bg-white border border-[#e5e7eb] rounded-lg shadow-lg">
              <CardHeader className="bg-[#fffbeb] border-b border-[#e5e7eb] rounded-t-lg">
                <CardTitle className="text-2xl font-bold text-[#262626] flex items-center">
                  <DollarSign className="w-8 h-8 mr-3 text-[#f59e0b]" />
                  Financial Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-[#f0f9ff] border border-[#0ea5e9] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#0ea5e9] rounded inline-block mr-2"></span>
                      Revenue Model
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.revenueModel || "Revenue model data is being loaded..."}
                    </div>
                  </div>
                  <div className="bg-[#fffbeb] border border-[#f59e0b] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#f59e0b] rounded inline-block mr-2"></span>
                      Startup Costs
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.startupCosts || "Startup costs data is being loaded..."}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Revenue Analysis */}
            <Card className="bg-white border border-[#e5e7eb] rounded-lg shadow-lg">
              <CardHeader className="bg-[#f0f9ff] border-b border-[#e5e7eb] rounded-t-lg">
                <CardTitle className="text-2xl font-bold text-[#262626] flex items-center">
                  <BarChart3 className="w-8 h-8 mr-3 text-[#0ea5e9]" />
                  Revenue Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div className="bg-[#f9fafb] border border-[#d1d5db] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#6b7280] rounded inline-block mr-2"></span>
                      Revenue Assumptions
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.revenueAssumptions || "No revenue assumptions available"}
                    </div>
                  </div>
                  <div className="bg-[#f0fdf4] border border-[#10b981] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#10b981] rounded inline-block mr-2"></span>
                      Profit & Loss Forecast
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.profitLossForecast || "No profit loss forecast available"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Cost Structure */}
            <Card className="bg-white border border-[#e5e7eb] rounded-lg shadow-lg">
              <CardHeader className="bg-[#fffbeb] border-b border-[#e5e7eb] rounded-t-lg">
                <CardTitle className="text-2xl font-bold text-[#262626] flex items-center">
                  <PieChart className="w-8 h-8 mr-3 text-[#f59e0b]" />
                  Cost Structure
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-[#fef2f2] border border-[#ef4444] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#ef4444] rounded inline-block mr-2"></span>
                      Fixed Monthly Expenses
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.fixedMonthlyExpenses || "No fixed monthly expenses data available"}
                    </div>
                  </div>
                  <div className="bg-[#fff7ed] border border-[#ea580c] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#ea580c] rounded inline-block mr-2"></span>
                      Variable Costs
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.variableCosts || "No variable costs data available"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Financial Analysis */}
            <Card className="bg-white border border-[#e5e7eb] rounded-lg shadow-lg">
              <CardHeader className="bg-[#f3f4f6] border-b border-[#e5e7eb] rounded-t-lg">
                <CardTitle className="text-2xl font-bold text-[#262626] flex items-center">
                  <Calculator className="w-8 h-8 mr-3 text-[#92400e]" />
                  Financial Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div className="bg-[#f0f9ff] border border-[#0ea5e9] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#0ea5e9] rounded inline-block mr-2"></span>
                      Cash Flow Analysis
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.cashFlow || "No cash flow analysis available"}
                    </div>
                  </div>
                  <div className="bg-[#fffbeb] border border-[#f59e0b] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#f59e0b] rounded inline-block mr-2"></span>
                      Break-Even Analysis
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.breakEvenAnalysis || "No break-even analysis available"}
                    </div>
                  </div>
                  <div className="bg-[#f0fdf4] border border-[#10b981] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#10b981] rounded inline-block mr-2"></span>
                      Loans & Capital
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.loansCapital || "No loans & capital data available"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Insights & Warnings */}
            <Card className="bg-white border border-[#e5e7eb] rounded-lg shadow-lg">
              <CardHeader className="bg-[#fef2f2] border-b border-[#e5e7eb] rounded-t-lg">
                <CardTitle className="text-2xl font-bold text-[#262626] flex items-center">
                  <AlertTriangle className="w-8 h-8 mr-3 text-[#ef4444]" />
                  Insights & Warnings
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="bg-[#fef2f2] border border-[#ef4444] rounded-lg p-6 shadow-sm">
                  <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                    {financialPlan?.insightsWarnings || "No insights & warnings available"}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Financial Reports */}
            <Card className="bg-white border border-[#e5e7eb] rounded-lg shadow-lg">
              <CardHeader className="bg-[#f8fafc] border-b border-[#e5e7eb] rounded-t-lg">
                <CardTitle className="text-2xl font-bold text-[#262626] flex items-center">
                  <BarChart3 className="w-8 h-8 mr-3 text-[#475569]" />
                  Financial Reports & Tracking
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-6">
                  <div className="bg-[#f9fafb] border border-[#d1d5db] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#6b7280] rounded inline-block mr-2"></span>
                      Reporting Tools
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.financialReports || "No financial reports data available"}
                    </div>
                  </div>
                  <div className="bg-[#fdf2f8] border border-[#ec4899] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#ec4899] rounded inline-block mr-2"></span>
                      Plan vs Reality
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.comparePlanReality || "No plan vs reality data available"}
                    </div>
                  </div>
                  <div className="bg-[#f0fdfa] border border-[#14b8a6] rounded-lg p-6 shadow-sm">
                    <h3 className="font-bold mb-4 text-xl text-[#262626] flex items-center">
                      <span className="w-6 h-6 bg-[#14b8a6] rounded inline-block mr-2"></span>
                      Export & Save
                    </h3>
                    <div className="whitespace-pre-wrap text-sm text-[#374151] leading-relaxed bg-white border border-[#e5e7eb] rounded-lg p-4">
                      {financialPlan?.exportSave || "No export & save data available"}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-wrap justify-center gap-4 pt-8">
              <button
                onClick={() => window.location.href = `/business-plan/${businessPlanId}`}
                className="bg-[#f3f4f6] hover:bg-[#e5e7eb] text-[#262626] font-medium py-3 px-6 rounded-lg border border-[#e5e7eb] transition-colors flex items-center"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Business Plan
              </button>
              <button
                onClick={() => window.location.href = `/calendar/${businessPlanId}`}
                className="bg-[#b45309] hover:bg-[#92400e] text-white font-medium py-3 px-6 rounded-lg transition-colors flex items-center"
              >
                <Calendar className="w-5 h-5 mr-2" />
                View Execution Calendar
              </button>
              {!businessPlan?.isLocked && (
                <button
                  onClick={() => lockPlanMutation.mutate()}
                  disabled={lockPlanMutation.isPending}
                  className="bg-[#dc2626] hover:bg-[#b91c1c] text-white font-medium py-3 px-6 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  <Lock className={`w-5 h-5 mr-2 ${lockPlanMutation.isPending ? 'animate-pulse' : ''}`} />
                  {lockPlanMutation.isPending ? "Locking..." : "Lock Plan"}
                </button>
              )}
              <button
                onClick={() => generateFinancialPlanMutation.mutate()}
                disabled={generateFinancialPlanMutation.isPending}
                className="bg-[#f59e0b] hover:bg-[#d97706] text-white font-medium py-3 px-6 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              >
                <RefreshCw className={`w-5 h-5 mr-2 ${generateFinancialPlanMutation.isPending ? 'animate-spin' : ''}`} />
                {generateFinancialPlanMutation.isPending ? "Regenerating..." : "Regenerate Plan"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
