import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles with comprehensive questionnaire data
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),

  // Demographics
  age: integer("age").notNull(), // Add missing age field
  ageGroup: varchar("age_group").notNull(),
  gender: text("gender").notNull(),
  location: text("location").notNull(),
  country: text("country").notNull(),
  city: text("city").notNull(),
  businessLocation: text("business_location").notNull(),
  locationType: varchar("location_type").notNull(), // Urban/Tier 2/Rural
  languages: jsonb("languages").notNull(), // array of strings
  isWorking: boolean("is_working").notNull(),
  currentProfession: text("current_profession").notNull(),
  availableHours: integer("available_hours").notNull(),

  // Personality traits
  comfortWithSelling: varchar("comfort_with_selling").default(''),
  comfortOnCamera: boolean("comfort_on_camera").default(false),
  comfortWithWriting: boolean("comfort_with_writing").default(false),
  organizationSkills: boolean("organization_skills").default(false),
  workPreference: varchar("work_preference").default(''), // Alone/With others/No preference

  // Skills and tools
  topSkills: jsonb("top_skills").default([]), // array of strings
  digitalToolsComfort: varchar("digital_tools_comfort").default(''),
  socialMediaKnowledge: boolean("social_media_knowledge").default(false),
  deviceType: varchar("device_type").default(''),

  // Financial readiness
  investmentCapacity: varchar("investment_capacity").default(''),
  hasStorageSpace: boolean("has_storage_space").default(false),
  okWithDeliveries: boolean("ok_with_deliveries").default(false),

  // Aspirations
  mainReason: jsonb("main_reason").default([]), // array of strings
  incomeGoal: varchar("income_goal").default(''),
  fullTimeGoal: varchar("full_time_goal").default(''),

  // Optional fields
  healthRestrictions: text("health_restrictions"),
  supportSystem: varchar("support_system"),
  additionalInfo: text("additional_info"),

  isCompleted: boolean("is_completed").default(false),
  hasCreatedBusinessPlan: boolean("has_created_business_plan").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Business ideas generated for users
export const businessIdeas = pgTable("business_ideas", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  profileId: integer("profile_id").notNull().references(() => userProfiles.id),

  title: varchar("title").notNull(),
  description: text("description").notNull(),
  targetMarket: text("target_market").notNull(),
  profitPotential: text("profit_potential").notNull(),
  startupCost: text("startup_cost").notNull(),
  difficulty: varchar("difficulty").notNull(), // Low/Medium/High
  timeToLaunch: text("time_to_launch").notNull(),

  // AI generated data
  aiData: jsonb("ai_data"), // full AI response
  isSelected: boolean("is_selected").default(false),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Business plans generated for users
export const businessPlans = pgTable("business_plans", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  profileId: integer("profile_id").notNull().references(() => userProfiles.id),
  title: varchar("title").notNull(),
  selectedIdeaIndex: integer("selected_idea_index"), // Keep for backward compatibility
  aiGeneratedIdeas: jsonb("ai_generated_ideas"), // Keep for backward compatibility

  // 19-point business plan data
  businessSummary: text("business_summary"),
  targetCustomer: text("target_customer"),
  problemSolving: text("problem_solving"),
  valueProposition: text("value_proposition"),
  revenueModel: text("revenue_model"),
  keyActivities: text("key_activities"),
  productService: text("product_service"),
  channels: text("channels"),
  customerRelationships: text("customer_relationships"),
  keyPartnerships: text("key_partnerships"),
  costStructure: text("cost_structure"),
  successMetrics: text("success_metrics"),
  legalCompliance: text("legal_compliance"),
  executionCalendar: jsonb("execution_calendar"), // array of calendar entries
  toolsResources: text("tools_resources"),
  risks: text("risks"),
  exportOptions: text("export_options"),
  successStories: jsonb("success_stories"),
  failureAnalysis: jsonb("failure_analysis"),

  status: varchar("status").notNull().default("draft"), // draft/completed/locked
  daysPlanned: integer("days_planned").notNull(), // 30/60/90
  isLocked: boolean("is_locked").default(false),
  lockedAt: timestamp("locked_at"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Calendar tasks for business plan execution
export const calendarTasks = pgTable("calendar_tasks", {
  id: serial("id").primaryKey(),
  businessPlanId: integer("business_plan_id").notNull().references(() => businessPlans.id),

  taskDate: date("task_date").notNull(),
  dayNumber: integer("day_number").notNull(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  resourceLinks: jsonb("resource_links"), // array of {title, url, type}
  isCompleted: boolean("is_completed").default(false),
  userNotes: text("user_notes"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Chat messages for business idea discussions
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  businessPlanId: integer("business_plan_id").references(() => businessPlans.id),
  ideaIndex: integer("idea_index"), // which of the 3 ideas this chat is about
  ideaId: integer("idea_id").references(() => businessIdeas.id), // direct reference to business idea

  message: text("message").notNull(),
  isFromUser: boolean("is_from_user").notNull(),

  createdAt: timestamp("created_at").defaultNow(),
});

export const financialPlans = pgTable("financial_plans", {
  id: serial("id").primaryKey(),
  businessPlanId: integer("business_plan_id").references(() => businessPlans.id).notNull(),
  revenueModel: text("revenue_model"),
  revenueAssumptions: text("revenue_assumptions"),
  fixedMonthlyExpenses: text("fixed_monthly_expenses"),
  variableCosts: text("variable_costs"),
  startupCosts: text("startup_costs"),
  loansCapital: text("loans_capital"),
  profitLossForecast: text("profit_loss_forecast"),
  cashFlow: text("cash_flow"),
  breakEvenAnalysis: text("break_even_analysis"),
  insightsWarnings: text("insights_warnings"),
  financialReports: text("financial_reports"),
  comparePlanReality: text("compare_plan_reality"),
  exportSave: text("export_save"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marketingPlans = pgTable("marketing_plans", {
  id: serial("id").primaryKey(),
  businessPlanId: integer("business_plan_id").notNull().references(() => businessPlans.id),
  brandVoiceMessaging: text("brand_voice_messaging"),
  recommendedChannels: text("recommended_channels"),
  contentPlanIdeas: text("content_plan_ideas"),
  first50CustomersStrategy: text("first_50_customers_strategy"),
  outreachScripts: text("outreach_scripts"),
  toolsResources: text("tools_resources"),
  kpisMetrics: text("kpis_metrics"),
  estimatedBudget: text("estimated_budget"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  businessPlanId: integer("business_plan_id").notNull().references(() => businessPlans.id),
  customerName: text("customer_name").notNull(),
  contactInfo: text("contact_info"),
  channelSource: text("channel_source").notNull(),
  status: text("status").notNull(),
  nextAction: text("next_action"),
  nextActionDate: timestamp("next_action_date"),
  notes: text("notes"),
  lastActivity: timestamp("last_activity").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Add relations for contacts
export const contactsRelations = relations(contacts, ({ one }) => ({
  businessPlan: one(businessPlans, { fields: [contacts.businessPlanId], references: [businessPlans.id] }),
}));

// Add contact types
export type Contact = typeof contacts.$inferSelect;
export type InsertContact = typeof contacts.$inferInsert;
// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  profiles: many(userProfiles),
  businessPlans: many(businessPlans),
  chatMessages: many(chatMessages),
}));

export const userProfilesRelations = relations(userProfiles, ({ one, many }) => ({
  user: one(users, { fields: [userProfiles.userId], references: [users.id] }),
  businessPlans: many(businessPlans),
}));

export const businessPlansRelations = relations(businessPlans, ({ one, many }) => ({
  user: one(users, { fields: [businessPlans.userId], references: [users.id] }),
  profile: one(userProfiles, { fields: [businessPlans.profileId], references: [userProfiles.id] }),
  calendarTasks: many(calendarTasks),
}));

export const calendarTasksRelations = relations(calendarTasks, ({ one }) => ({
  businessPlan: one(businessPlans, { fields: [calendarTasks.businessPlanId], references: [businessPlans.id] }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, { fields: [chatMessages.userId], references: [users.id] }),
  businessPlan: one(businessPlans, { fields: [chatMessages.businessPlanId], references: [businessPlans.id] }),
}));

export const financialPlansRelations = relations(financialPlans, ({ one }) => ({
  businessPlan: one(businessPlans, { fields: [financialPlans.businessPlanId], references: [businessPlans.id] }),
}));

// Insert schemas
export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  age: z.number().min(16).max(80),
  ageGroup: z.string().min(1),
  gender: z.string().min(1),
  country: z.string().min(1),
  city: z.string().min(1),
  businessLocation: z.string().min(1),
  currentProfession: z.string().min(1),
});

export const insertBusinessPlanSchema = createInsertSchema(businessPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCalendarTaskSchema = createInsertSchema(calendarTasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertBusinessIdeaSchema = createInsertSchema(businessIdeas).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFinancialPlanSchema = createInsertSchema(financialPlans);
export const selectFinancialPlanSchema = createSelectSchema(financialPlans);

export const insertMarketingPlanSchema = createInsertSchema(marketingPlans);
export const selectMarketingPlanSchema = createSelectSchema(marketingPlans);

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type BusinessPlan = typeof businessPlans.$inferSelect;
export type InsertBusinessPlan = z.infer<typeof insertBusinessPlanSchema>;
export type CalendarTask = typeof calendarTasks.$inferSelect;
export type InsertCalendarTask = z.infer<typeof insertCalendarTaskSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type BusinessIdea = typeof businessIdeas.$inferSelect;
export type InsertBusinessIdea = z.infer<typeof insertBusinessIdeaSchema>;
export type FinancialPlan = typeof financialPlans.$inferSelect;
export type InsertFinancialPlan = z.infer<typeof insertFinancialPlanSchema>;
export type MarketingPlan = typeof marketingPlans.$inferSelect;
export type InsertMarketingPlan = z.infer<typeof insertMarketingPlanSchema>;