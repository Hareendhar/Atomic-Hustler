
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Download } from "lucide-react";

interface FinancialPlanCardProps {
  title: string;
  icon: string;
  content: string;
  type: "ai" | "user" | "hybrid";
  onRegenerate?: () => void;
  onEdit?: () => void;
}

export function FinancialPlanCard({ 
  title, 
  icon, 
  content, 
  type, 
  onRegenerate, 
  onEdit 
}: FinancialPlanCardProps) {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "ai":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "user":
        return "bg-green-100 text-green-800 border-green-200";
      case "hybrid":
        return "bg-purple-100 text-purple-800 border-purple-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getTypeText = (type: string) => {
    switch (type) {
      case "ai":
        return "AI Generated";
      case "user":
        return "User Input";
      case "hybrid":
        return "Hybrid";
      default:
        return "Unknown";
    }
  };

  return (
    <Card className="neo-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">{icon}</div>
            <div>
              <CardTitle className="neo-heading text-lg">{title}</CardTitle>
              <Badge className={`text-xs mt-1 ${getTypeColor(type)}`}>
                {getTypeText(type)}
              </Badge>
            </div>
          </div>
          <div className="flex space-x-2">
            {type === "ai" && onRegenerate && (
              <Button
                size="sm"
                variant="outline"
                onClick={onRegenerate}
                className="neo-btn-sm"
              >
                <RefreshCw className="w-3 h-3" />
              </Button>
            )}
            {type === "user" && onEdit && (
              <Button
                size="sm"
                variant="outline"
                onClick={onEdit}
                className="neo-btn-sm"
              >
                ✏️
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="text-sm text-gray-700 leading-relaxed">
          {content.split('\n').map((line, index) => (
            <p key={index} className="mb-2 last:mb-0">
              {line}
            </p>
          ))}
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-200">
          <div className="flex items-center text-xs text-green-600">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
            Included in Download
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
