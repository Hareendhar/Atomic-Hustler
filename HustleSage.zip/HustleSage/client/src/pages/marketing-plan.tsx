import { useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Megaphone, 
  Users, 
  MessageSquare, 
  Target, 
  Settings, 
  TrendingUp, 
  IndianRupee,
  Lightbulb,
  Copy,
  CheckCircle,
  Calendar
} from "lucide-react";

interface MarketingPlan {
  id: number;
  businessPlanId: number;
  brandVoiceMessaging: string;
  recommendedChannels: string;
  contentPlanIdeas: string;
  first50CustomersStrategy: string;
  outreachScripts: string;
  toolsResources: string;
  kpisMetrics: string;
  estimatedBudget: string;
  createdAt: string;
  updatedAt: string;
}

// Section Component for better content display
function MarketingSection({ title, icon: Icon, content, colorClass = "text-primary" }: {
  title: string;
  icon: any;
  content: string;
  colorClass?: string;
}) {
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      // You could add a toast notification here
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <Card className="border-2 border-gray-200 hover:border-primary/20 transition-colors">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-3 text-xl">
          <div className={`p-2 rounded-lg bg-gray-100`}>
            <Icon className={`w-5 h-5 ${colorClass}`} />
          </div>
          {title}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => copyToClipboard(content)}
            className="ml-auto"
          >
            <Copy className="w-4 h-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="prose prose-sm max-w-none">
          <div className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
            {content}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function MarketingPlan() {
  const params = useParams();
  const businessPlanId = params.id;
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: businessPlan, isLoading: planLoading } = useQuery({
    queryKey: [`/api/business-plans/${businessPlanId}`],
    enabled: !!businessPlanId && businessPlanId !== "undefined",
  });

  const { data: marketingPlan, isLoading: marketingLoading, error } = useQuery<MarketingPlan>({
    queryKey: [`/api/business-plans/${businessPlanId}/marketing-plan`],
    enabled: !!businessPlanId && businessPlanId !== "undefined",
    retry: 1,
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Error Loading Marketing Plan",
        description: "Failed to load marketing plan. Please try again.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  if (planLoading || marketingLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent animate-spin mx-auto mb-4 rounded-full"></div>
          <p className="text-muted-foreground">Loading marketing plan...</p>
        </div>
      </div>
    );
  }

  if (!marketingPlan) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Link href={`/business-plan/${businessPlanId}`}>
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Business Plan
            </Button>
          </Link>

          <Card className="border-2 border-dashed">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full mx-auto mb-6 flex items-center justify-center">
                <Megaphone className="w-10 h-10 text-purple-600" />
              </div>
              <h3 className="text-2xl font-semibold mb-3 text-foreground">Marketing Plan Not Generated Yet</h3>
              <p className="text-muted-foreground text-lg mb-6 max-w-md mx-auto">
                Create a comprehensive marketing strategy with AI-powered insights tailored to your business and target market.
              </p>
              <div className="space-y-3">
                <Link href={`/business-plan/${businessPlanId}`}>
                  <Button size="lg" className="w-full max-w-xs">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Generate Marketing Plan
                  </Button>
                </Link>
                <p className="text-sm text-muted-foreground">
                  Go to your business plan and navigate to the Marketing section to generate your personalized marketing strategy.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                Marketing Strategy
              </Badge>
            </div>

            <div className="flex items-center gap-4">
              <Link href={`/business-plan/${businessPlanId}`}>
                <Button variant="ghost">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Business Plan
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Megaphone className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">Marketing Plan</h1>
          </div>
          <p className="text-xl text-muted-foreground">
            Complete marketing strategy for {businessPlan?.title || 'your business'}
          </p>
        </div>

        {/* Tabs for Different Sections */}
        <Tabs defaultValue="brand" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 h-auto p-1">
            <TabsTrigger value="brand" className="text-xs py-2">
              <Megaphone className="w-3 h-3 mr-1" />
              Brand
            </TabsTrigger>
            <TabsTrigger value="channels" className="text-xs py-2">
              <Target className="w-3 h-3 mr-1" />
              Channels
            </TabsTrigger>
            <TabsTrigger value="content" className="text-xs py-2">
              <Lightbulb className="w-3 h-3 mr-1" />
              Content
            </TabsTrigger>
            <TabsTrigger value="customers" className="text-xs py-2">
              <Users className="w-3 h-3 mr-1" />
              Customers
            </TabsTrigger>
            <TabsTrigger value="outreach" className="text-xs py-2">
              <MessageSquare className="w-3 h-3 mr-1" />
              Scripts
            </TabsTrigger>
            <TabsTrigger value="tools" className="text-xs py-2">
              <Settings className="w-3 h-3 mr-1" />
              Tools
            </TabsTrigger>
            <TabsTrigger value="metrics" className="text-xs py-2">
              <TrendingUp className="w-3 h-3 mr-1" />
              Metrics
            </TabsTrigger>
            <TabsTrigger value="budget" className="text-xs py-2">
              <IndianRupee className="w-3 h-3 mr-1" />
              Budget
            </TabsTrigger>
          </TabsList>

          <TabsContent value="brand" className="space-y-6">
            <MarketingSection
              title="Brand Voice & Messaging"
              icon={Megaphone}
              content={marketingPlan.brandVoiceMessaging}
              colorClass="text-purple-600"
            />
          </TabsContent>

          <TabsContent value="channels" className="space-y-6">
            <MarketingSection
              title="Recommended Marketing Channels"
              icon={Target}
              content={marketingPlan.recommendedChannels}
              colorClass="text-blue-600"
            />
          </TabsContent>

          <TabsContent value="content" className="space-y-6">
            <MarketingSection
              title="Content Plan & Post Ideas"
              icon={Lightbulb}
              content={marketingPlan.contentPlanIdeas}
              colorClass="text-green-600"
            />
          </TabsContent>

          <TabsContent value="customers" className="space-y-6">
            <MarketingSection
              title="First 50 Customers Strategy"
              icon={Users}
              content={marketingPlan.first50CustomersStrategy}
              colorClass="text-orange-600"
            />
          </TabsContent>

          <TabsContent value="outreach" className="space-y-6">
            <MarketingSection
              title="Outreach Scripts & Templates"
              icon={MessageSquare}
              content={marketingPlan.outreachScripts}
              colorClass="text-pink-600"
            />
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <MarketingSection
              title="Marketing Tools & Resources"
              icon={Settings}
              content={marketingPlan.toolsResources}
              colorClass="text-gray-600"
            />
          </TabsContent>

          <TabsContent value="metrics" className="space-y-6">
            <MarketingSection
              title="KPIs & Success Metrics"
              icon={TrendingUp}
              content={marketingPlan.kpisMetrics}
              colorClass="text-emerald-600"
            />
          </TabsContent>

          <TabsContent value="budget" className="space-y-6">
            <MarketingSection
              title="Marketing Budget & ROI"
              icon={IndianRupee}
              content={marketingPlan.estimatedBudget}
              colorClass="text-amber-600"
            />
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex gap-4 mt-8 pt-6 border-t">
          <Link href={`/business-plan/${businessPlanId}`}>
            <Button variant="outline">
              View Business Plan
            </Button>
          </Link>
          <Link href={`/financial-plan/${businessPlanId}`}>
            <Button variant="outline">
              View Financial Plan
            </Button>
          </Link>
          <Link href={`/calendar/${businessPlanId}`}>
            <Button variant="outline" className="bg-[#78350f] hover:bg-[#92400e] text-white border-[#78350f]">
              <Calendar className="w-4 h-4 mr-2" />
              View Execution Calendar
            </Button>
          </Link>
        </div>

        {/* Footer Note */}
        <div className="mt-8 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
            <div className="text-sm text-muted-foreground">
              <p className="font-medium mb-1">Your Personalized Marketing Plan is Ready!</p>
              <p>
                This plan is tailored specifically for your business, location, and target market. 
                Use the copy buttons to easily share content ideas with your team or save them for reference.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}