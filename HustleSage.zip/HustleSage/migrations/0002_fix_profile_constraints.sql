
-- Fix not-null constraints by setting default values for existing records and updating schema
BEGIN;

-- Update existing records with empty values for fields that can't be null
UPDATE user_profiles SET 
  comfort_with_selling = '' WHERE comfort_with_selling IS NULL;
UPDATE user_profiles SET 
  work_preference = '' WHERE work_preference IS NULL;
UPDATE user_profiles SET 
  digital_tools_comfort = '' WHERE digital_tools_comfort IS NULL;
UPDATE user_profiles SET 
  device_type = '' WHERE device_type IS NULL;
UPDATE user_profiles SET 
  investment_capacity = '' WHERE investment_capacity IS NULL;
UPDATE user_profiles SET 
  income_goal = '' WHERE income_goal IS NULL;
UPDATE user_profiles SET 
  full_time_goal = '' WHERE full_time_goal IS NULL;

-- Set default values for boolean fields
UPDATE user_profiles SET 
  comfort_on_camera = false WHERE comfort_on_camera IS NULL;
UPDATE user_profiles SET 
  comfort_with_writing = false WHERE comfort_with_writing IS NULL;
UPDATE user_profiles SET 
  organization_skills = false WHERE organization_skills IS NULL;
UPDATE user_profiles SET 
  social_media_knowledge = false WHERE social_media_knowledge IS NULL;
UPDATE user_profiles SET 
  has_storage_space = false WHERE has_storage_space IS NULL;
UPDATE user_profiles SET 
  ok_with_deliveries = false WHERE ok_with_deliveries IS NULL;

-- Set default values for array fields
UPDATE user_profiles SET 
  top_skills = '[]'::jsonb WHERE top_skills IS NULL;
UPDATE user_profiles SET 
  main_reason = '[]'::jsonb WHERE main_reason IS NULL;

-- Now alter the columns to have default values (for future inserts)
ALTER TABLE user_profiles ALTER COLUMN comfort_with_selling SET DEFAULT '';
ALTER TABLE user_profiles ALTER COLUMN work_preference SET DEFAULT '';
ALTER TABLE user_profiles ALTER COLUMN digital_tools_comfort SET DEFAULT '';
ALTER TABLE user_profiles ALTER COLUMN device_type SET DEFAULT '';
ALTER TABLE user_profiles ALTER COLUMN investment_capacity SET DEFAULT '';
ALTER TABLE user_profiles ALTER COLUMN income_goal SET DEFAULT '';
ALTER TABLE user_profiles ALTER COLUMN full_time_goal SET DEFAULT '';

ALTER TABLE user_profiles ALTER COLUMN comfort_on_camera SET DEFAULT false;
ALTER TABLE user_profiles ALTER COLUMN comfort_with_writing SET DEFAULT false;
ALTER TABLE user_profiles ALTER COLUMN organization_skills SET DEFAULT false;
ALTER TABLE user_profiles ALTER COLUMN social_media_knowledge SET DEFAULT false;
ALTER TABLE user_profiles ALTER COLUMN has_storage_space SET DEFAULT false;
ALTER TABLE user_profiles ALTER COLUMN ok_with_deliveries SET DEFAULT false;

ALTER TABLE user_profiles ALTER COLUMN top_skills SET DEFAULT '[]'::jsonb;
ALTER TABLE user_profiles ALTER COLUMN main_reason SET DEFAULT '[]'::jsonb;

COMMIT;
