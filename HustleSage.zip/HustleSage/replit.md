# Hustle Mover - Business Plan Generator

## Overview

Hustle Mover is a full-stack web application designed to help Indians of all ages discover and develop personalized side hustle business opportunities. The platform leverages AI (Google's Gemini) to generate customized business ideas based on comprehensive user profiles, then provides detailed business plans with step-by-step execution calendars and financial planning tools.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with a neo-brutalist design system
- **UI Components**: Radix UI primitives with custom shadcn/ui components
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth with OpenID Connect
- **AI Integration**: Google Gemini API for business idea generation
- **Session Management**: Connect-pg-simple for PostgreSQL session storage

### Build System
- **Development**: Vite for fast development server and HMR
- **Production**: ESBuild for server bundling, Vite for client bundling
- **TypeScript**: Full TypeScript support across client and server

## Key Components

### Authentication System
- Replit Auth integration with OpenID Connect
- PostgreSQL session storage for secure session management
- User profile management with comprehensive questionnaire data
- Protected routes with automatic login redirects

### AI-Powered Business Generation
- Google Gemini integration for personalized business idea generation
- Multi-step business plan creation with detailed sections
- Interactive chat system for idea refinement
- Financial planning with AI-generated projections

### Database Schema
- **Users**: Basic user information from Replit Auth
- **User Profiles**: Comprehensive questionnaire data including demographics, skills, preferences
- **Business Plans**: Generated business plans with status tracking
- **Calendar Tasks**: Step-by-step execution tasks with resource links
- **Chat Messages**: Conversation history for idea refinement
- **Financial Plans**: AI-generated financial projections and planning

### UI/UX Design
- Neo-brutalist design system with bold colors and typography
- Responsive design for mobile and desktop
- Interactive components with floating elements and animations
- Comprehensive form system for profile setup
- Dashboard for managing multiple business plans

## Data Flow

1. **User Registration**: Users authenticate via Replit Auth
2. **Profile Setup**: Comprehensive questionnaire covering demographics, skills, preferences
3. **Idea Generation**: AI analyzes profile to generate 3 personalized business ideas
4. **Plan Development**: Selected idea is expanded into detailed business plan
5. **Execution Planning**: Step-by-step calendar with daily tasks and resources
6. **Financial Planning**: AI-generated financial projections and planning tools
7. **Progress Tracking**: Task completion tracking and note-taking

## External Dependencies

### Core Dependencies
- **@google/genai**: Google Gemini AI integration
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **react-hook-form**: Form state management
- **zod**: Schema validation

### Authentication
- **openid-client**: OpenID Connect client
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **vite**: Build tool and dev server
- **tailwindcss**: Utility-first CSS framework
- **typescript**: Type checking
- **tsx**: TypeScript execution

## Deployment Strategy

### Environment Setup
- **Database**: PostgreSQL (configured for Neon serverless)
- **Environment Variables**: 
  - `DATABASE_URL`: PostgreSQL connection string
  - `GEMINI_API_KEY`: Google Gemini API key
  - `SESSION_SECRET`: Session encryption secret
  - `REPL_ID`: Replit environment identifier

### Build Process
1. Client build: Vite bundles React app to `dist/public`
2. Server build: ESBuild bundles Express server to `dist/index.js`
3. Database migration: Drizzle pushes schema changes

### Production Configuration
- **Port**: 5000 (configurable via environment)
- **Static Files**: Served from `dist/public`
- **Session Storage**: PostgreSQL with 7-day TTL
- **Security**: HTTPS-only cookies, CSRF protection

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- June 25, 2025: **CRITICAL ISSUE IDENTIFIED** - Financial plan data transmission problem between backend and frontend
- June 25, 2025: Root cause analysis completed - TanStack Query key inconsistencies causing cache mismatches
- June 25, 2025: Created comprehensive fix plan in Instructions.md with step-by-step solution
- June 25, 2025: Backend confirmed working correctly (data exists, API returns 200)
- June 25, 2025: Frontend receives empty data despite successful API calls
- June 25, 2025: Issue isolated to query key standardization and response parsing

## Changelog

Changelog:
- June 25, 2025. Initial setup