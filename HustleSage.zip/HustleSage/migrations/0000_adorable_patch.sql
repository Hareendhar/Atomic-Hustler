CREATE TABLE "business_plans" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" varchar NOT NULL,
	"profile_id" integer NOT NULL,
	"title" varchar NOT NULL,
	"selected_idea_index" integer NOT NULL,
	"ai_generated_ideas" jsonb NOT NULL,
	"business_summary" text,
	"target_customer" text,
	"problem_solving" text,
	"value_proposition" text,
	"revenue_model" text,
	"key_activities" text,
	"product_service" text,
	"channels" text,
	"customer_relationships" text,
	"key_partnerships" text,
	"cost_structure" text,
	"success_metrics" text,
	"legal_compliance" text,
	"execution_calendar" jsonb,
	"tools_resources" text,
	"risks" text,
	"export_options" text,
	"success_stories" jsonb,
	"failure_analysis" jsonb,
	"status" varchar DEFAULT 'draft' NOT NULL,
	"days_planned" integer NOT NULL,
	"is_locked" boolean DEFAULT false,
	"locked_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "calendar_tasks" (
	"id" serial PRIMARY KEY NOT NULL,
	"business_plan_id" integer NOT NULL,
	"task_date" date NOT NULL,
	"day_number" integer NOT NULL,
	"title" varchar NOT NULL,
	"description" text NOT NULL,
	"resource_links" jsonb,
	"is_completed" boolean DEFAULT false,
	"user_notes" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "chat_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" varchar NOT NULL,
	"business_plan_id" integer,
	"idea_index" integer,
	"message" text NOT NULL,
	"is_from_user" boolean NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "financial_plans" (
	"id" serial PRIMARY KEY NOT NULL,
	"business_plan_id" integer NOT NULL,
	"revenue_model" text,
	"revenue_assumptions" text,
	"fixed_monthly_expenses" text,
	"variable_costs" text,
	"startup_costs" text,
	"loans_capital" text,
	"profit_loss_forecast" text,
	"cash_flow" text,
	"break_even_analysis" text,
	"insights_warnings" text,
	"financial_reports" text,
	"compare_plan_reality" text,
	"export_save" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "marketing_plans" (
	"id" serial PRIMARY KEY NOT NULL,
	"business_plan_id" integer NOT NULL,
	"brand_voice_messaging" text,
	"recommended_channels" text,
	"content_plan_ideas" text,
	"first_50_customers_strategy" text,
	"outreach_scripts" text,
	"tools_resources" text,
	"kpis_metrics" text,
	"estimated_budget" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"sid" varchar PRIMARY KEY NOT NULL,
	"sess" jsonb NOT NULL,
	"expire" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_profiles" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" varchar NOT NULL,
	"age_group" varchar NOT NULL,
	"location" varchar NOT NULL,
	"location_type" varchar NOT NULL,
	"languages" jsonb NOT NULL,
	"is_working" boolean NOT NULL,
	"available_hours" integer NOT NULL,
	"comfort_with_selling" varchar NOT NULL,
	"comfort_on_camera" boolean NOT NULL,
	"comfort_with_writing" boolean NOT NULL,
	"organization_skills" boolean NOT NULL,
	"work_preference" varchar NOT NULL,
	"top_skills" jsonb NOT NULL,
	"digital_tools_comfort" varchar NOT NULL,
	"social_media_knowledge" boolean NOT NULL,
	"device_type" varchar NOT NULL,
	"investment_capacity" varchar NOT NULL,
	"has_storage_space" boolean NOT NULL,
	"ok_with_deliveries" boolean NOT NULL,
	"main_reason" jsonb NOT NULL,
	"income_goal" varchar NOT NULL,
	"full_time_goal" varchar NOT NULL,
	"health_restrictions" text,
	"support_system" varchar,
	"additional_info" text,
	"is_completed" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" varchar PRIMARY KEY NOT NULL,
	"email" varchar,
	"first_name" varchar,
	"last_name" varchar,
	"profile_image_url" varchar,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
ALTER TABLE "business_plans" ADD CONSTRAINT "business_plans_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "business_plans" ADD CONSTRAINT "business_plans_profile_id_user_profiles_id_fk" FOREIGN KEY ("profile_id") REFERENCES "public"."user_profiles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "calendar_tasks" ADD CONSTRAINT "calendar_tasks_business_plan_id_business_plans_id_fk" FOREIGN KEY ("business_plan_id") REFERENCES "public"."business_plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_business_plan_id_business_plans_id_fk" FOREIGN KEY ("business_plan_id") REFERENCES "public"."business_plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "financial_plans" ADD CONSTRAINT "financial_plans_business_plan_id_business_plans_id_fk" FOREIGN KEY ("business_plan_id") REFERENCES "public"."business_plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "marketing_plans" ADD CONSTRAINT "marketing_plans_business_plan_id_business_plans_id_fk" FOREIGN KEY ("business_plan_id") REFERENCES "public"."business_plans"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_profiles" ADD CONSTRAINT "user_profiles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "IDX_session_expire" ON "sessions" USING btree ("expire");