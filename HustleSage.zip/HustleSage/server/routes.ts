import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { generateBusinessIdeas, generateBusinessPlan, chatWithIdea, generateFinancialPlan, generateMarketingPlan } from "./gemini";
import { insertUserProfileSchema, insertBusinessPlanSchema, insertChatMessageSchema } from "@shared/schema";
import nodemailer from 'nodemailer';

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;

      if (!userId) {
        console.error("No user ID found in request:", req.user);
        return res.status(400).json({ message: "Invalid user session" });
      }

      let user = await storage.getUser(userId);

      // If user doesn't exist, create one from the session data
      if (!user && req.user) {
        console.log("Creating new user from session:", req.user.id);
        user = await storage.upsertUser({
          id: req.user.id,
          email: req.user.email,
          firstName: req.user.firstName || req.user.first_name,
          lastName: req.user.lastName || req.user.last_name,
          profileImageUrl: req.user.image || req.user.profileImageUrl,
        });
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Profile routes
  app.get('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const profile = await storage.getUserProfile(userId);
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      console.log("Profile save request for user:", userId);
      console.log("Profile data received:", req.body);

      const existingProfile = await storage.getUserProfile(userId);

      // Define default values for all required fields
      const defaultValues = {
        ageGroup: '',
        age: 25,
        gender: '',
        location: '',
        country: '',
        city: '',
        businessLocation: '',
        locationType: '',
        languages: [],
        isWorking: false,
        currentProfession: '',
        availableHours: 10,
        comfortWithSelling: '',
        comfortOnCamera: false,
        comfortWithWriting: false,
        organizationSkills: false,
        workPreference: '',
        topSkills: [],
        digitalToolsComfort: '',
        socialMediaKnowledge: false,
        deviceType: '',
        investmentCapacity: '',
        hasStorageSpace: false,
        okWithDeliveries: false,
        mainReason: [],
        incomeGoal: '',
        fullTimeGoal: '',
        healthRestrictions: '',
        supportSystem: '',
        additionalInfo: '',
        isCompleted: false
      };

      // Clean the request body to remove any fields that shouldn't be updated
      const { id, createdAt, updatedAt, ...cleanRequestData } = req.body;

      let profileData;

      if (existingProfile) {
        // Update existing profile - merge new data with existing, excluding timestamp fields
        profileData = {
          ...cleanRequestData,
          userId
        };
        console.log("Updating existing profile");
      } else {
        // Create new profile - merge with defaults to ensure no null values
        profileData = {
          ...defaultValues,
          ...cleanRequestData,
          userId
        };
        console.log("Creating new profile with defaults");
      }

      // Only validate if it's a completed profile
      if (cleanRequestData.isCompleted) {
        try {
          // Create a complete validation object
          const validationData = existingProfile 
            ? { ...existingProfile, ...profileData }
            : { ...defaultValues, ...profileData };

          insertUserProfileSchema.parse(validationData);
          console.log("Full validation passed for completed profile");
        } catch (validationError) {
          console.error("Validation error for completed profile:", validationError);
          throw validationError;
        }
      }

      console.log("Profile data after processing:", profileData);

      let profile;
      if (existingProfile) {
        profile = await storage.updateUserProfile(userId, profileData);
      } else {
        profile = await storage.createUserProfile(profileData);
      }

      console.log("Profile saved successfully:", profile.id);
      res.json(profile);
    } catch (error) {
      console.error("Error creating/updating profile:", error);
      if (error instanceof Error) {
        console.error("Error message:", error.message);
        console.error("Error stack:", error.stack);
      }

      // Send more specific error message
      const errorMessage = error instanceof Error ? error.message : "Failed to save profile";
      res.status(500).json({ 
        message: errorMessage,
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Ideas routes
  app.get('/api/business-ideas', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const ideas = await storage.getUserBusinessIdeas(userId);
      res.json(ideas);
    } catch (error) {
      console.error("Error fetching business ideas:", error);
      res.status(500).json({ message: "Failed to fetch business ideas" });
    }
  });

  app.post('/api/generate-ideas', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;

      // Check if user already has a locked business plan
      const hasLockedPlan = await storage.hasLockedBusinessPlan(userId);
      if (hasLockedPlan) {
        return res.status(403).json({ 
          message: "You already have a locked business plan. Only one business plan per user is allowed." 
        });
      }

      const profile = await storage.getUserProfile(userId);

      if (!profile) {
        return res.status(400).json({ message: "Please complete your profile first" });
      }

      const generatedIdeas = await generateBusinessIdeas(profile);

      // Map AI response to database format
      const ideaInserts = generatedIdeas.map((idea, index) => ({
        userId,
        profileId: profile.id,
        title: idea.title,
        description: idea.description,
        targetMarket: idea.targetPersona, // Use correct field mapping
        profitPotential: idea.revenuePotential,
        startupCost: idea.startupCosts,
        difficulty: idea.difficultyLevel, // Use correct field mapping
        timeToLaunch: idea.timeCommitment,
        aiData: idea,
        isSelected: index === 0, // First idea selected by default
      }));

      const savedIdeas = await storage.createBusinessIdeas(ideaInserts);
      res.json({ ideas: savedIdeas });
    } catch (error) {
      console.error("Error generating ideas:", error);
      res.status(500).json({ message: "Failed to generate ideas" });
    }
  });

  // Get chat messages for a specific idea
  app.get('/api/ideas/:ideaId/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const ideaId = parseInt(req.params.ideaId);

      if (isNaN(ideaId)) {
        return res.status(400).json({ message: "Invalid idea ID" });
      }

      // Verify user owns this idea
      const businessIdeas = await storage.getUserBusinessIdeas(userId);
      const selectedIdea = businessIdeas.find(idea => idea.id === ideaId);

      if (!selectedIdea) {
        return res.status(404).json({ message: "Business idea not found" });
      }

      const messages = await storage.getIdeaChatMessages(userId, ideaId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching idea chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post('/api/chat-with-idea', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const { message, ideaId } = req.body;

      console.log("Chat with idea request:", { userId, ideaId, messageLength: message?.length });

      if (!message || !ideaId) {
        return res.status(400).json({ message: "Message and idea ID are required" });
      }

      // Get the business idea from database
      const businessIdeas = await storage.getUserBusinessIdeas(userId);
      const selectedIdea = businessIdeas.find(idea => idea.id === parseInt(ideaId));

      if (!selectedIdea) {
        return res.status(404).json({ message: "Business idea not found" });
      }

      // Save user message first
      const userMessage = await storage.createIdeaChatMessage({
        userId,
        ideaId: parseInt(ideaId),
        message,
        isFromUser: true,
      });

      // Get existing chat history for context
      const chatHistory = await storage.getIdeaChatMessages(userId, parseInt(ideaId));

      // Convert database idea to AI format
      const ideaForAI = {
        title: selectedIdea.title,
        description: selectedIdea.description,
        targetPersona: selectedIdea.targetMarket,
        revenuePotential: selectedIdea.profitPotential,
        startupCosts: selectedIdea.startupCost,
        difficultyLevel: selectedIdea.difficulty,
        timeCommitment: selectedIdea.timeToLaunch
      };

      // Get user profile for context
      const profile = await storage.getUserProfile(userId);

      // Generate AI response with proper context
      const aiResponse = await chatWithIdea(message, ideaForAI, chatHistory, profile);

      // Save AI response
      const aiMessage = await storage.createIdeaChatMessage({
        userId,
        ideaId: parseInt(ideaId),
        message: aiResponse,
        isFromUser: false,
      });

      console.log("Chat response generated successfully");

      res.json({ 
        userMessage,
        aiMessage,
        response: aiResponse 
      });
    } catch (error) {
      console.error("Error chatting with idea:", error);
      res.status(500).json({ 
        message: "Failed to process chat",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post('/api/create-business-plan', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const { ideaId } = req.body;

      const profile = await storage.getUserProfile(userId);
      if (!profile) {
        return res.status(400).json({ message: "Please complete your profile first" });
      }

      // Get the selected idea from the database
      const userIdeas = await storage.getUserBusinessIdeas(userId);
      const selectedIdea = userIdeas.find(idea => idea.id === parseInt(ideaId));

      if (!selectedIdea) {
        return res.status(404).json({ message: "Business idea not found" });
      }

      // Convert stored idea to AI format for business plan generation
      const ideaForAI = {
        title: selectedIdea.title,
        description: selectedIdea.description,
        difficultyLevel: selectedIdea.difficulty,
        targetPersona: selectedIdea.targetMarket,
        revenuePotential: selectedIdea.profitPotential,
        startupCosts: selectedIdea.startupCost,
        timeCommitment: selectedIdea.timeToLaunch,
        opportunityTiming: "Good timing based on market analysis",
        marketGap: "Market gap identified through user profile analysis", 
        founderFit: "Strong fit based on user skills and preferences"
      };

      const planContent = await generateBusinessPlan(profile, ideaForAI);

      const businessPlan = await storage.createBusinessPlan({
        userId,
        profileId: profile.id,
        title: selectedIdea.title,
        status: 'draft',
        selectedIdeaIndex: 0,
        aiGeneratedIdeas: [ideaForAI],
        ...planContent,
      });

      res.json(businessPlan);
    } catch (error) {
      console.error("Error creating business plan:", error);
      res.status(500).json({ message: "Failed to create business plan" });
    }
  });

  // Business plan routes
  app.get('/api/business-plans', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const plans = await storage.getUserBusinessPlans(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching business plans:", error);
      res.status(500).json({ message: "Failed to fetch business plans" });
    }
  });

  app.get('/api/business-plans/:id', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);

      if (isNaN(planId)) {
        return res.status(400).json({ message: "Invalid business plan ID" });
      }

      const plan = await storage.getBusinessPlan(planId);

      if (!plan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (plan.userId !== userId) {
        console.log("Access denied - user mismatch");
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(plan);
    } catch (error) {
      console.error("Error fetching business plan:", error);
      res.status(500).json({ message: "Failed to fetch business plan" });
    }
  });

  app.post('/api/generate-ideas', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const profile = await storage.getUserProfile(userId);

      if (!profile || !profile.isCompleted) {
        return res.status(400).json({ message: "Please complete your profile first" });
      }

      const ideas = await generateBusinessIdeas(profile);
      res.json({ ideas });
    } catch (error) {
      console.error("Error generating ideas:", error);
      res.status(500).json({ message: "Failed to generate business ideas" });
    }
  });

  app.post('/api/create-business-plan', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;

      // Check if user already has a locked business plan
      const hasLockedPlan = await storage.hasLockedBusinessPlan(userId);
      if (hasLockedPlan) {
        return res.status(403).json({ 
          message: "You already have a locked business plan. Only one business plan per user is allowed." 
        });
      }

      const { ideas, selectedIdeaIndex } = req.body;

      const profile = await storage.getUserProfile(userId);
      if (!profile) {
        return res.status(400).json({ message: "Profile not found" });
      }

      const selectedIdea = ideas[selectedIdeaIndex];
      const planContent = await generateBusinessPlan(profile, selectedIdea);

      const businessPlan = await storage.createBusinessPlan({
        userId,
        profileId: profile.id,
        title: selectedIdea.title,
        selectedIdeaIndex,
        aiGeneratedIdeas: ideas,
        ...planContent,
      });

      // Create calendar tasks with proper date formatting
      console.log("Creating calendar tasks for plan:", businessPlan.id);
      console.log("Execution calendar entries:", planContent.executionCalendar.length);

      for (const entry of planContent.executionCalendar) {
        try {
          await storage.createCalendarTask({
            businessPlanId: businessPlan.id,
            taskDate: entry.date,
            dayNumber: entry.day,
            title: entry.title,
            description: entry.description,
            resourceLinks: entry.resourceLinks || [],
          });
          console.log(`Created task for day ${entry.day}: ${entry.title}`);
        } catch (taskError) {
          console.error(`Error creating task for day ${entry.day}:`, taskError);
        }
      }

      res.json(businessPlan);
    } catch (error) {
      console.error("Error creating business plan:", error);
      res.status(500).json({ message: "Failed to create business plan" });
    }
  });

  app.patch('/api/business-plans/:id/lock', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      const plan = await storage.getBusinessPlan(planId);

      if (!plan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (plan.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const lockedPlan = await storage.lockBusinessPlan(planId);
      res.json(lockedPlan);
    } catch (error) {
      console.error("Error locking business plan:", error);
      res.status(500).json({ message: "Failed to lock business plan" });
    }
  });

  // Calendar routes
  app.get('/api/business-plans/:id/calendar', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);

      if (isNaN(planId)) {
        return res.status(400).json({ message: "Invalid business plan ID" });
      }

      const plan = await storage.getBusinessPlan(planId);

      if (!plan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (plan.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const tasks = await storage.getCalendarTasks(planId);
      console.log(`Fetching calendar tasks for plan ${planId}: found ${tasks.length} tasks`);

      // If no tasks found, check if they exist in the business plan's execution calendar JSON
      if (tasks.length === 0 && plan.executionCalendar) {
        console.log("No tasks in database, but execution calendar exists in plan:", plan.executionCalendar);

        // Regenerate tasks from the stored execution calendar
        const executionCalendar = plan.executionCalendar as any[];
        for (const entry of executionCalendar) {
          try {
            await storage.createCalendarTask({
              businessPlanId: planId,
              taskDate: entry.date,
              dayNumber: entry.day,
              title: entry.title,
              description: entry.description,
              resourceLinks: entry.resourceLinks || [],
            });
          } catch (taskError) {
            console.error(`Error creating missing task for day ${entry.day}:`, taskError);
          }
        }

        // Fetch tasks again
        const newTasks = await storage.getCalendarTasks(planId);
        console.log(`After regenerating tasks: found ${newTasks.length} tasks`);
        return res.json(newTasks);
      }

      res.json(tasks);
    } catch (error) {
      console.error("Error fetching calendar tasks:", error);
      res.status(500).json({ message: "Failed to fetch calendar tasks" });
    }
  });

  // Update calendar task
  app.patch('/api/calendar-tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const { isCompleted, userNotes } = req.body;

      console.log(`Updating task ${taskId} - isCompleted: ${isCompleted}, userNotes: ${userNotes}`);

      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }

      const updatedTask = await storage.updateCalendarTask(taskId, {
        isCompleted,
        userNotes,
      });

      console.log("Updated task result:", updatedTask);

      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json(updatedTask);
    } catch (error) {
      console.error("Error updating calendar task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  // Financial plan routes
  app.get('/api/business-plans/:id/financial-plan', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`Fetching financial plan for business plan ID: ${planId}`);
      const userId = req.user.claims?.sub || req.user.id;
      console.log(`User ID: ${userId}`);

      if (isNaN(planId)) {
        console.log("Invalid plan ID provided");
        return res.status(400).json({ message: "Invalid business plan ID" });
      }

      const businessPlan = await storage.getBusinessPlan(planId);
      console.log(`Business plan found: ${!!businessPlan}`);

      if (!businessPlan) {
        console.log("Business plan not found");
        return res.status(404).json({ message: "Business plan not found" });
      }

      if (businessPlan.userId !== userId) {
        console.log("Access denied - user mismatch");
        return res.status(403).json({ message: "Access denied" });
      }

      console.log("Attempting to fetch financial plan from database...");
      const financialPlan = await storage.getFinancialPlan(planId);
      console.log(`Financial plan found: ${!!financialPlan}`);

      if (financialPlan) {
        console.log("Returning existing financial plan");
        // Data should already be correctly mapped by Drizzle
        console.log("Sample data check - revenue model length:", financialPlan.revenueModel?.length || 0);
        console.log("Available properties:", Object.keys(financialPlan));
        console.log("Revenue model first 100 chars:", financialPlan.revenueModel?.substring(0, 100) || "EMPTY");
        res.json(financialPlan);
      } else {
        console.log("No financial plan found - returning null");
        res.json(null);
      }
    } catch (error) {
      console.error("Error fetching financial plan:", error);
      console.error("Error stack:", error instanceof Error ? error.stack : 'No stack trace');
      res.status(500).json({ 
        message: "Failed to fetch financial plan",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post('/api/business-plans/:id/generate-financial-plan', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`\n=== FINANCIAL PLAN GENERATION REQUEST ===`);
      console.log(`Plan ID: ${planId}`);
      const userId = req.user.claims?.sub || req.user.id;
      console.log(`User ID: ${userId}`);
      console.log(`Request timestamp: ${new Date().toISOString()}`);

      const businessPlan = await storage.getBusinessPlan(planId);

      if (!businessPlan) {
        console.log("❌ Business plan not found");
        return res.status(404).json({ message: "Business plan not found" });
      }

      console.log(`✅ Business plan found: ${businessPlan.title}`);
      console.log(`Business plan user ID: ${businessPlan.userId}`);
      console.log(`Request user ID: ${userId}`);

      if (businessPlan.userId !== userId) {
        console.log("❌ Access denied - user mismatch");
        return res.status(403).json({ message: "Access denied" });
      }

      // Allow financial plan generation for both draft and completed business plans

      const profile = await storage.getUserProfile(businessPlan.userId);
      if (!profile) {
        console.log("Profile not found");
        return res.status(400).json({ message: "Profile not found" });
      }

      console.log(`Generating financial plan for business: ${businessPlan.title}`);
      console.log(`Profile data:`, { location: profile.location, incomeGoal: profile.incomeGoal, investmentCapacity: profile.investmentCapacity });

      let financialPlanData;

      try {
        console.log("Attempting AI generation with Gemini...");
        financialPlanData = await generateFinancialPlan(profile, businessPlan);
        console.log("AI generation successful, received data keys:", Object.keys(financialPlanData));
      } catch (aiError: any) {
        console.error("AI generation failed, using fallback:", aiError);

        // Create comprehensive fallback financial plan with actual data
        financialPlanData = {
          revenueModel: `REVENUE MODEL FOR ${businessPlan.title?.toUpperCase() || 'YOUR BUSINESS'}:

• Primary Revenue Stream: Service-based billing model
• Pricing Structure: ₹500-2,000 per unit/service (market competitive)
• Payment Methods: UPI (60%), Cash (25%), Bank Transfer (15%)
• Revenue Frequency: Daily sales with weekly collections
• Seasonal Variations: Festival seasons (+30%), Monsoon impact (-10%)
• Market Size: Local market ₹50,000-2,00,000 monthly potential
• GST Impact: 18% for services, 5-12% for products

TARGET MONTHLY REVENUE: ₹${profile.incomeGoal || '25,000'}`,

          revenueAssumptions: `REVENUE PROJECTIONS FOR ${profile.location}:

📊 PRICING ASSUMPTIONS:
• Base Price: ₹750 per unit/service
• Market Research: Based on local competitor rates
• Price Growth: 10% annual increase

📈 VOLUME PROJECTIONS:
Month 1-3: 20 units per month (startup phase)
Month 4-6: 35 units per month (growth rate: 25%)
Month 7-12: 50+ units per month (growth rate: 15%)

🎯 CUSTOMER ASSUMPTIONS:
• New customers per month: 8-12
• Customer retention rate: 65%
• Average order value: ₹750
• Repeat customer rate: 40%

TOTAL YEAR 1 REVENUE: ₹${parseInt(profile.incomeGoal || '25000') * 12 || '3,00,000'}`,

          fixedMonthlyExpenses: `FIXED MONTHLY EXPENSES FOR ${profile.location}:

🏢 INFRASTRUCTURE COSTS:
• Rent/Space: ₹3,000-8,000/month
• Utilities (electricity): ₹800-1,500/month
• Internet/Phone: ₹500-800/month
• Storage/Tools: ₹500-1,000/month

💼 BUSINESS OPERATIONS:
• Software subscriptions: ₹200-500/month
• Insurance: ₹300-600/month
• Banking charges: ₹100-300/month
• Accounting fees: ₹500-1,000/month

TOTAL FIXED COSTS: ₹6,000-12,000/month`,

          variableCosts: `VARIABLE COSTS PER UNIT/SERVICE:

🛍️ DIRECT COSTS:
• Raw materials: ₹150-250 per unit (20-35% of selling price)
• Packaging: ₹25-50 per unit
• Labor (if applicable): ₹50-100 per unit

🚚 DELIVERY & LOGISTICS:
• Local delivery: ₹30-60 per order
• Courier charges: ₹40-100 per shipment

TOTAL VARIABLE COST: ₹300-500 per unit
Gross Margin: 35-60% per unit`,

          startupCosts: `ONE-TIME STARTUP INVESTMENT:

🏗️ SETUP COSTS:
• Equipment/Tools: ₹5,000-25,000
• Initial inventory: ₹3,000-15,000
• Technology setup: ₹3,000-12,000

📋 LEGAL & COMPLIANCE:
• Business registration: ₹1,000-3,000
• GST registration: ₹500-1,000
• Trade license: ₹500-2,000

🎨 BRANDING & MARKETING:
• Logo & branding: ₹2,000-8,000
• Website development: ₹5,000-20,000
• Initial marketing: ₹3,000-10,000

TOTAL STARTUP COST: ₹25,000-75,000
Your Budget: ₹${profile.investmentCapacity}`,

          loansCapital: `FUNDING OPTIONS FOR INDIAN ENTREPRENEURS:

🏦 GOVERNMENT SCHEME OPTIONS:

1️⃣ MUDRA LOANS:
• Shishu (up to ₹50,000): 8-10% interest, No collateral
• Kishore (₹50K-₹5L): 9-11% interest
• Tarun (₹5L-₹10L): 10-12% interest

2️⃣ DIGITAL LENDING:
• Fintech platforms: 12-24% interest
• Bank personal loans: 11-16% interest

📊 RECOMMENDED STRUCTURE:
• Self-funding: ₹${profile.investmentCapacity}
• MUDRA loan if needed: Up to ₹50,000`,

          profitLossForecast: `12-MONTH PROFIT & LOSS FORECAST:

📊 MONTHLY BREAKDOWN (Year 1):
Month 1: Revenue ₹8,000 | Expenses ₹12,000 | Loss (₹4,000)
Month 2: Revenue ₹12,000 | Expenses ₹11,000 | Profit ₹1,000
Month 3: Revenue ₹15,000 | Expenses ₹11,500 | Profit ₹3,500
Month 4-6: Revenue ₹18,000-25,000 | Profit ₹6,000-12,000
Month 7-12: Revenue ₹25,000-35,000 | Profit ₹12,000-20,000

YEAR 1 TOTALS:
• Total Revenue: ₹2,75,000
• Total Expenses: ₹1,48,500
• Net Profit: ₹1,26,500 (46% margin)

Break-even month: Month 2`,

          cashFlow: `24-MONTH CASH FLOW ANALYSIS:

💰 CRITICAL FIRST 6 MONTHS:
Month 1: Cash flow negative ₹7,000
Month 2: Cash flow positive ₹1,000
Month 3: Cash flow positive ₹3,500

🔴 CRITICAL MONTHS:
• Lowest cash point: Month 1
• Cash positive month: Month 2
• Peak funding requirement: ₹25,000

✅ MILESTONES:
• Break-even month: Month 2
• Consistent positive: Month 3`,

          breakEvenAnalysis: `BREAK-EVEN ANALYSIS:

🎯 UNIT ECONOMICS:
• Selling price per unit: ₹750
• Variable cost per unit: ₹350
• Contribution margin: ₹400 (53%)

⚖️ BREAK-EVEN CALCULATIONS:
• Units needed per month: 20 units
• Revenue needed per month: ₹15,000
• Break-even month: Month 2

📈 SCALING TARGETS:
• To earn ₹10,000/month: 25 units
• To earn ₹25,000/month: 45 units
• To earn ₹50,000/month: 70 units

Success metric: Sell 1 unit per day consistently for profitability!`,

          insightsWarnings: `FINANCIAL INSIGHTS & WARNINGS:

🚨 KEY RISKS TO MONITOR:

1️⃣ CASH FLOW RISKS:
• Month 1 will be challenging - have ₹15,000 buffer ready
• Seasonal dips during monsoon (Jun-Sep)
• Customer payment delays during festivals

2️⃣ MARKET RISKS:
• Price sensitivity in Indian market
• Competition pricing pressure
• Economic slowdown impact

💡 SUCCESS INDICATORS:
• Break-even by Month 2 (achievable)
• Healthy 53% gross margins
• Strong repeat customer potential

📊 WEEKLY TRACKING:
• Daily sales target: 1-2 units
• Weekly revenue target: ₹5,000-8,000
• Customer acquisition: 2-3 new customers/week

⚠️ ACTION TRIGGERS:
• If weekly sales < 3 units for 2 weeks
• If monthly costs exceed ₹12,000
• If cash balance falls below ₹5,000`,

          financialReports: `FINANCIAL REPORTING & KPI DASHBOARD:

📊 KEY PERFORMANCE INDICATORS:

💰 PROFITABILITY METRICS:
• Gross Profit Margin: 53% (Target: 50%+)
• Net Profit Margin: 46% (Industry: 35-40%)
• Return on Investment: 180% annually

🔄 OPERATIONAL EFFICIENCY:
• Customer Acquisition Cost: ₹150-250
• Customer Lifetime Value: ₹2,500-4,000
• Order fulfillment time: 2-3 days

📈 GROWTH METRICS:
• Monthly Revenue Growth: 15-25%
• Customer Base Growth: 10-15% monthly
• Average Order Value: ₹750

📋 MONTHLY TRACKING TEMPLATE:
✅ Revenue Achievement: ___% of ₹${profile.incomeGoal || '25,000'} target
✅ Cost Control: ₹___ vs ₹8,000 budget
✅ New Customers: ___ (Target: 8-12)
✅ Cash Position: ₹___ available

📱 RECOMMENDED TOOLS:
• Accounting: Zoho Books/TallyPrime
• Inventory: Excel/Google Sheets
• Customer tracking: WhatsApp Business
• Payment tracking: UPI transaction history`,

          comparePlanReality: `PLAN vs REALITY TRACKING SYSTEM:

📋 WEEKLY REVIEW CHECKLIST:

💰 REVENUE TRACKING:
Planned Weekly Revenue: ₹${Math.round((parseInt(profile.incomeGoal || '25000')) / 4.33)}
Actual Weekly Revenue: ₹_____ (Fill each week)
Variance: ____% (Acceptable: ±20%)

📊 Key Metrics:
• Units Sold: Plan 5-7/week vs Actual ____
• New Customers: Plan 2-3/week vs Actual ____
• Average Order Value: Plan ₹750 vs Actual ₹____

💸 COST MONITORING:
• Weekly Fixed Costs: Plan ₹2,000 vs Actual ₹____
• Weekly Variable Costs: Plan ₹1,750 vs Actual ₹____
• Total Weekly Costs: Plan ₹4,250 vs Actual ₹____

🔧 COURSE CORRECTION TRIGGERS:
RED FLAGS - Take action if:
• Revenue <75% of target for 2 weeks
• Costs >125% of plan for any month
• No new customers for 1+ weeks

📋 ACTION PLAN TEMPLATE:
When actual differs from plan by >25%:
1. Identify root cause
2. Adjust pricing/costs/strategy
3. Update forecasts
4. Monitor weekly until back on track

💡 SUCCESS INDICATORS:
🟢 GREEN: 90%+ of targets met
🟡 YELLOW: 75-89% of targets
🔴 RED: <75% of targets (immediate action)`,

          exportSave: `COMPREHENSIVE FINANCIAL TOOLKIT:

📥 DOWNLOADABLE PACKAGE INCLUDES:

📊 EXCEL FINANCIAL MODEL:
• 12-Month P&L Projections
• 24-Month Cash Flow Analysis
• Break-even Calculator
• Cost Tracking Templates
• Revenue Forecasting Tools
• KPI Dashboard with benchmarks
• GST Calculation Templates
• Loan EMI Calculator

📄 PROFESSIONAL REPORTS:
• Executive Summary (investor-ready)
• Detailed Financial Plan (15-page)
• Visual Charts & Graphs
• Monthly Review Templates
• Key Ratios & Benchmarks
• Risk Analysis & Mitigation

🎯 HOW TO USE:

1️⃣ DAILY OPERATIONS:
• Set daily sales targets (1-2 units)
• Track actual vs planned performance
• Monitor cost control
• Manage cash flow needs

2️⃣ BUSINESS PLANNING:
• Monthly revenue target setting
• Inventory planning
• Hiring decisions
• Expansion planning

3️⃣ FUNDING APPLICATIONS:
• Bank loan presentations
• Investor pitch decks
• Government scheme applications

📱 MOBILE-FRIENDLY:
• WhatsApp Business integration
• Google Sheets mobile tracking
• UPI payment reconciliation

✅ COMPLIANCE READY:
• GST return preparation
• GST return preparation
• Income Tax calculation
• Audit trail maintenance
• Statutory compliance checklist

All templates designed for Indian market conditions with local currency, regulations, and business practices.`
        };
      }

      console.log("Saving financial plan to database...");
      console.log("Financial plan data keys before saving:", Object.keys(financialPlanData));

      // Validate that we have the required data
      if (!financialPlanData || typeof financialPlanData !== 'object') {
        throw new Error("Invalid financial plan data structure");
      }

      // Check if financial plan already exists
      const existingPlan = await storage.getFinancialPlan(planId);

      let financialPlan;
      if (existingPlan) {
        console.log("Updating existing financial plan");
        financialPlan = await storage.updateFinancialPlan(planId, financialPlanData);
      } else {
        console.log("Creating new financial plan");
        financialPlan = await storage.createFinancialPlan({
          ...financialPlanData,
          businessPlanId: planId,
        });
      }

      console.log("Financial plan saved successfully:", !!financialPlan);
      console.log("Saved financial plan data keys:", financialPlan ? Object.keys(financialPlan) : 'null');

      // Validate data before sending
      if (!financialPlan) {
        throw new Error("Failed to save financial plan - no data returned");
      }

      // Ensure all critical fields are present
      const requiredFields = ['revenueModel', 'startupCosts', 'profitLossForecast'];
      for (const field of requiredFields) {
        if (!financialPlan[field]) {
          console.warn(`Missing or empty field: ${field}`);
        }
      }

      console.log("Sending financial plan response with data lengths:", {
        revenueModel: financialPlan.revenueModel?.length || 0,
        startupCosts: financialPlan.startupCosts?.length || 0,
        total_fields: Object.keys(financialPlan).length
      });

      // Ensure proper response format
      res.json({
        ...financialPlan,
        id: financialPlan.id || null,
        businessPlanId: planId,
        createdAt: financialPlan.createdAt || new Date().toISOString(),
        updatedAt: financialPlan.updatedAt || new Date().toISOString()
      });

    } catch (error) {
      console.error("Fatal error in financial plan generation:", error);
      res.status(500).json({ 
        message: "Failed to generate financial plan. Please try again.", 
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get('/api/business-plans/:id/export-financial-plan', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      const businessPlan = await storage.getBusinessPlan(planId);

      if (!businessPlan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (businessPlan.userId !== userId) {
        console.log("Access denied - user mismatch");
        return res.status(403).json({ message: "Access denied" });
      }

      const financialPlan = await storage.getFinancialPlan(planId);
      if (!financialPlan) {
        return res.status(404).json({ message: "Financial plan not found. Please generate one first." });
      }

      // Create a simple CSV content instead of Excel for now
      let csvContent = `Financial Plan for ${businessPlan.title}\n\n`;
      csvContent += `Section,Content\n`;
      csvContent += `Revenue Model,"${financialPlan.revenueModel?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Revenue Assumptions,"${financialPlan.revenueAssumptions?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Fixed Monthly Expenses,"${financialPlan.fixedMonthlyExpenses?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Variable Costs,"${financialPlan.variableCosts?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Startup Costs,"${financialPlan.startupCosts?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Loans or Capital,"${financialPlan.loansCapital?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `P&L Forecast,"${financialPlan.profitLossForecast?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Cash Flow,"${financialPlan.cashFlow?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Break-even Analysis,"${financialPlan.breakEvenAnalysis?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Insights & Warnings,"${financialPlan.insightsWarnings?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Financial Reports,"${financialPlan.financialReports?.replace(/"/g, '""') || 'Not available'}"\n`;
      csvContent += `Plan vs Reality,"${financialPlan.comparePlanReality?.replace(/"/g, '""') || 'Not available'}"\n`;

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${businessPlan.title}-Financial-Plan.csv"`);
      res.send(csvContent);
    } catch (error) {
      console.error("Error exporting financial plan:", error);
      res.status(500).json({ message: "Failed to export financial plan" });
    }
  });

  // Contacts routes
  app.get('/api/business-plans/:id/contacts', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`Fetching contacts for business plan ID: ${planId}`);
      const userId = req.user.claims?.sub || req.user.id;
      console.log(`User ID: ${userId}`);

      const businessPlan = await storage.getBusinessPlan(planId);
      if (!businessPlan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      if (businessPlan.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const contactList = await storage.getContacts(planId);
      res.json(contactList);
    } catch (error) {
      console.error("Error fetching contacts:", error);
      res.status(500).json({ 
        message: "Failed to fetch contacts",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post('/api/business-plans/:id/contacts', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`Creating contact for business plan ID: ${planId}`);

      const businessPlan = await storage.getBusinessPlan(planId);
      if (!businessPlan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (businessPlan.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const contact = await storage.createContact({
        ...req.body,
        businessPlanId: planId,
        lastActivity: new Date()
      });

      res.json(contact);
    } catch (error) {
      console.error("Error creating contact:", error);
      res.status(500).json({ 
        message: "Failed to create contact",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.put('/api/business-plans/:id/contacts/:contactId', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      const contactId = parseInt(req.params.contactId);
      console.log(`Updating contact ${contactId} for business plan ID: ${planId}`);

      const businessPlan = await storage.getBusinessPlan(planId);
      if (!businessPlan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (businessPlan.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const contact = await storage.updateContact(contactId, {
        ...req.body,
        lastActivity: new Date()
      });

      res.json(contact);
    } catch (error) {
      console.error("Error updating contact:", error);
      res.status(500).json({ 
        message: "Failed to update contact",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get('/api/business-plans/:id/sales-stats', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`Fetching sales stats for business plan ID: ${planId}`);

      const businessPlan = await storage.getBusinessPlan(planId);
      if (!businessPlan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const userId = req.user.claims?.sub || req.user.id;
      if (businessPlan.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const stats = await storage.getSalesStats(planId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching sales stats:", error);
      res.status(500).json({ 
        message: "Failed to fetch sales stats",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Marketing plan routes
  app.get('/api/business-plans/:id/marketing-plan', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`Fetching marketing plan for business plan ID: ${planId}`);
      const userId = req.user.claims?.sub || req.user.id;
      console.log(`User ID: ${userId}`);

      if (isNaN(planId)) {
        console.log("Invalid plan ID provided");
        return res.status(400).json({ message: "Invalid business plan ID" });
      }

      const businessPlan = await storage.getBusinessPlan(planId);
      console.log(`Business plan found: ${!!businessPlan}`);

      if (!businessPlan) {
        console.log("Business plan not found");
        return res.status(404).json({ message: "Business plan not found" });
      }

      if (businessPlan.userId !== userId) {
        console.log("Access denied - user mismatch");
        return res.status(403).json({ message: "Access denied" });
      }

      console.log("Attempting to fetch marketing plan from database...");
      const marketingPlan = await storage.getMarketingPlan(planId);
      console.log(`Marketing plan found: ${!!marketingPlan}`);

      if (marketingPlan) {
        console.log("Returning existing marketing plan");
        console.log("Sample data check - brand voice length:", marketingPlan.brandVoiceMessaging?.length || 0);
        console.log("Available properties:", Object.keys(marketingPlan));
        res.json(marketingPlan);
      } else {
        console.log("No marketing plan found - returning null");
        res.json(null);
      }
    } catch (error) {
      console.error("Error fetching marketing plan:", error);
      console.error("Error stack:", error instanceof Error ? error.stack : 'No stack trace');
      res.status(500).json({ 
        message: "Failed to fetch marketing plan",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post('/api/business-plans/:id/generate-marketing-plan', isAuthenticated, async (req: any, res) => {
    try {
      const planId = parseInt(req.params.id);
      console.log(`\n=== MARKETING PLAN GENERATION REQUEST ===`);
      console.log(`Plan ID: ${planId}`);
      const userId = req.user.claims?.sub || req.user.id;
      console.log(`User ID: ${userId}`);
      console.log(`Request timestamp: ${new Date().toISOString()}`);

      const businessPlan = await storage.getBusinessPlan(planId);

      if (!businessPlan) {
        console.log("❌ Business plan not found");
        return res.status(404).json({ message: "Business plan not found" });
      }

      console.log(`✅ Business plan found: ${businessPlan.title}`);

      if (businessPlan.userId !== userId) {
        console.log("❌ Access denied - user mismatch");
        return res.status(403).json({ message: "Access denied" });
      }

      // Allow marketing plan generation for both draft and completed business plans

      const profile = await storage.getUserProfile(businessPlan.userId);
      if (!profile) {
        console.log("Profile not found");
        return res.status(400).json({ message: "Profile not found" });
      }

      // Try to get financial plan for context
      const financialPlan = await storage.getFinancialPlan(planId);

      console.log(`Generating marketing plan for business: ${businessPlan.title}`);
      console.log(`Profile data:`, { location: profile.location, ageGroup: profile.ageGroup, skills: profile.topSkills });

      let marketingPlanData;

      try {
        console.log("Attempting AI generation with Gemini...");
        marketingPlanData = await generateMarketingPlan(profile, businessPlan, financialPlan);
        console.log("AI generation successful, received data keys:", Object.keys(marketingPlanData));
      } catch (aiError: any) {
        console.error("AI generation failed:", aiError);
        throw aiError; // Let it fail if AI generation fails
      }

      console.log("Saving marketing plan to database...");
      console.log("Marketing plan data keys before saving:", Object.keys(marketingPlanData));

      // Check if marketing plan already exists
      const existingPlan = await storage.getMarketingPlan(planId);

      let marketingPlan;
      if (existingPlan) {
        console.log("Updating existing marketing plan");
        marketingPlan = await storage.updateMarketingPlan(planId, marketingPlanData);
      } else {
        console.log("Creating new marketing plan");
        marketingPlan = await storage.createMarketingPlan({
          ...marketingPlanData,
          businessPlanId: planId,
        });
      }

      console.log("Marketing plan saved successfully:", !!marketingPlan);
      console.log("Saved marketing plan data keys:", marketingPlan ? Object.keys(marketingPlan) : 'null');

      if (!marketingPlan) {
        throw new Error("Failed to save marketing plan - no data returned");
      }

      console.log("Sending marketing plan response");
      res.json(marketingPlan);

    } catch (error) {
      console.error("Fatal error in marketing plan generation:", error);
      res.status(500).json({ 
        message: "Failed to generate marketing plan. Please try again.", 
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Chat routes
  app.get('/api/chat/:businessPlanId/:ideaIndex', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const businessPlanId = parseInt(req.params.businessPlanId);
      const ideaIndex = parseInt(req.params.ideaIndex);

      const messages = await storage.getChatMessages(userId, businessPlanId, ideaIndex);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Temporary chat for ideas without business plan
  app.post('/api/chat-idea', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const { message, idea, chatHistory = [] } = req.body;

      console.log("Chat idea request:", { userId, ideaTitle: idea?.title, messageLength: message?.length });

      if (!message || !idea) {
        return res.status(400).json({ message: "Message and idea are required" });
      }

      // Get user profile for context
      const profile = await storage.getUserProfile(userId);

      // Generate AI response without saving to database
      const aiResponse = await chatWithIdea(message, idea, chatHistory, profile);

      console.log("Chat response generated successfully");

      res.json({ 
        userMessage: { message, isFromUser: true, createdAt: new Date().toISOString() },
        aiMessage: { message: aiResponse, isFromUser: false, createdAt: new Date().toISOString() }
      });
    } catch (error) {
      console.error("Error in temporary chat:", error);
      res.status(500).json({ 
        message: "Failed to process chat message",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims?.sub || req.user.id;
      const { message, businessPlanId, ideaIndex } = req.body;

      // Save user message
      const userMessage = await storage.createChatMessage({
        userId,
        businessPlanId,
        ideaIndex,
        message,
        isFromUser: true,
      });

      // Get business plan to access ideas
      const plan = await storage.getBusinessPlan(businessPlanId);
      if (!plan) {
        return res.status(404).json({ message: "Business plan not found" });
      }

      const ideas = plan.aiGeneratedIdeas as any[];
      const selectedIdea = ideas[ideaIndex];

      // Get chat history
      const chatHistory = await storage.getChatMessages(userId, businessPlanId, ideaIndex);

      // Get user profile for context
      const profile = await storage.getUserProfile(userId);

      // Generate AI response
      const aiResponse = await chatWithIdea(message, selectedIdea, chatHistory, profile);

      // Save AI response
      const aiMessage = await storage.createChatMessage({
        userId,
        businessPlanId,
        ideaIndex,
        message: aiResponse,
        isFromUser: false,
      });

      res.json({ userMessage, aiMessage });
    } catch (error) {
      console.error("Error in chat:", error);
       res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // Waitlist endpoint
  app.post('/api/waitlist', async (req: any, res) => {
    try {
      const { name, email } = req.body;

      if (!name || !email) {
        return res.status(400).json({ error: 'Name and email are required' });
      }

      // Create transporter for sending email
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.SMTP_USER || 'your-email@gmail.com',
          pass: process.env.SMTP_PASSWORD || 'your-app-password'
        }
      });

      // Email content
      const mailOptions = {
        from: process.env.SMTP_USER || 'your-email@gmail.com',
        to: 'hareendhar@gmail.com',
        subject: 'New Waitlist Signup - Side Hustle DNA',
        html: `
          <h2>New Waitlist Signup</h2>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Timestamp:</strong> ${new Date().toLocaleString()}</p>
        `
      };

      // Send email notification
      await transporter.sendMail(mailOptions);

      res.json({ success: true, message: 'Thank you for joining our waitlist!' });
    } catch (error) {
      console.error('Waitlist signup error:', error);
      res.status(500).json({ error: 'Failed to process waitlist signup' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}