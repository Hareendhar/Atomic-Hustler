import * as client from "openid-client";
import { Strategy, type VerifyFunction } from "openid-client/passport";

import passport from "passport";
import session from "express-session";
import type { Express, RequestHandler, Request, Response, NextFunction } from "express";
import memoize from "memoizee";
import connectPg from "connect-pg-simple";
import { storage } from "./storage";

if (!process.env.REPLIT_DOMAINS) {
  throw new Error("Environment variable REPLIT_DOMAINS not provided");
}

const getOidcConfig = memoize(
  async () => {
    return await client.discovery(
      new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc"),
      process.env.REPL_ID!
    );
  },
  { maxAge: 3600 * 1000 }
);

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);

  let sessionStore;
  try {
    sessionStore = new pgStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true,
      ttl: sessionTtl,
      tableName: "sessions",
      pool: undefined, // Use connection string instead of pool
    });
  } catch (error) {
    console.error('Failed to create session store:', error);
    // Fallback to memory store for development
    console.log('Using memory store as fallback');
    sessionStore = undefined;
  }

  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: sessionTtl,
      sameSite: 'lax'
    },
  });
}

function updateUserSession(
  user: any,
  tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers
) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}

async function upsertUser(
  claims: any,
) {
  await storage.upsertUser({
    id: claims["sub"],
    email: claims["email"],
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"],
  });
}

export async function setupAuth(app: Express) {
  // Temporary mock authentication for development
  console.log("Setting up mock authentication for development");
  
  // Mock user data
  const mockUser = {
    id: "mock-user-123",
    email: "user@example.com", 
    firstName: "Test",
    lastName: "User",
    profileImageUrl: "https://via.placeholder.com/150",
    claims: {
      sub: "mock-user-123",
      email: "user@example.com",
      first_name: "Test", 
      last_name: "User",
      profile_image_url: "https://via.placeholder.com/150"
    }
  };

  passport.serializeUser((user, done) => done(null, user));
  passport.deserializeUser((user, done) => done(null, user as any));

  app.use(passport.initialize());
  app.use(passport.session());

  app.get("/api/login", async (req, res) => {
    console.log("Mock login initiated");
    // Auto-login with mock user
    req.logIn(mockUser, async (err) => {
      if (err) {
        console.error('Mock login error:', err);
        return res.status(500).json({ message: "Login failed" });
      }
      
      // Create mock user in database
      try {
        await upsertUser(mockUser.claims);
        console.log("Mock user created/updated in database");
      } catch (error) {
        console.error("Error creating mock user:", error);
      }
      
      res.redirect("/");
    });
  });

  app.get("/api/logout", (req, res) => {
    console.log("Logout requested");
    req.logout((err) => {
      if (err) {
        console.error("Error during logout:", err);
      }
      res.redirect("/");
    });
  });
}

export const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  console.log("Auth check - User:", req.user ? "Present" : "Missing");
  console.log("Auth check - Session ID:", req.sessionID);

  if (req.user) {
    // Convert to standard format if needed
    if (!req.user.claims && req.user.id) {
      req.user.claims = { sub: req.user.id };
    }
    next();
  } else {
    console.log("Authentication failed - no user in session");
    res.status(401).json({ message: "Unauthorized" });
  }
};